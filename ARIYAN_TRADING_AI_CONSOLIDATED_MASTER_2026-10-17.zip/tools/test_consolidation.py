"""Evidence checks for consolidation; no source-authority or production approval."""
import hashlib,json,pathlib,sys,unittest,zipfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
def sha(raw):return hashlib.sha256(raw).hexdigest()
def load(path):return json.loads((ROOT/path).read_text())

class ConsolidationTests(unittest.TestCase):
    def test_main_payloads_unchanged(self):
        manifest=load('checkpoint85/SHA256_MANIFEST.json')['files'];self.assertEqual(len(manifest),319)
        for name,digest in manifest.items():
            with self.subTest(name=name):self.assertEqual(sha((ROOT/'checkpoint85'/name).read_bytes()),digest)
    def test_branch_payloads_unchanged(self):
        manifest=load('branch74/MANIFEST.json')['files'];self.assertEqual(len(manifest),56)
        for name,digest in manifest.items():
            with self.subTest(name=name):self.assertEqual(sha((ROOT/'branch74'/name).read_bytes()),digest)
    def test_original_master_identity(self):
        original=(ROOT/'checkpoint85/MASTER/ARIYAN_TRADING_AI_COMPLETE_MASTER_ARCHIVE_THROUGH_15200.txt').read_bytes()
        self.assertEqual(sha(original),'bec33dd3116fa509849ea97873dbfa54d0be38b2585119f074eefe6ed5ae418c')
        self.assertEqual(original,(ROOT/'branch74/master.txt').read_bytes())
    def test_same_phase72_input(self):
        self.assertEqual((ROOT/'checkpoint85/provenance/phase72_input.zip').read_bytes(),(ROOT/'branch74/prior/phase72.zip').read_bytes())
    def test_27_exact_source_recoveries(self):
        entries=load('branch74/sources/index.json');self.assertEqual(len(entries),27)
        for source in entries:
            b=(ROOT/'branch74/sources'/source['file']).read_bytes()
            self.assertEqual(len(b),source['bytes']);self.assertEqual(sha(b),source['sha256'])
    def test_alternate_retained(self):
        b=(ROOT/'checkpoint85/phase81/supplementary/6101_6200_alternate.txt').read_bytes()
        self.assertEqual(sha(b),'f3c66aa7833e724df63b4e02bf5e0fa58f0831659554aa0451681928e52c2d58')
        self.assertTrue(b in (ROOT/'FINAL_MASTER_HANDOFF.txt').read_bytes(),'Exact alternate bytes must appear in readable master handoff')
    def test_recovered_legacy_archive_matches_historical_pin(self):
        expected='67537ddd0e4836562fb87ec97fe2ab43d4bb5fcfd82c8fb85e5544d570dcea68'
        b=(ROOT/'provenance/recovered_legacy.zip').read_bytes();self.assertEqual(sha(b),expected)
        with zipfile.ZipFile(ROOT/'branch74/prior/phase72.zip') as p72:
            p71=next(n for n in p72.namelist() if 'PHASE71' in n)
            import io
            with zipfile.ZipFile(io.BytesIO(p72.read(p71))) as p71zip:
                with zipfile.ZipFile(io.BytesIO(p71zip.read('prior/PHASE70_COMPLETE_PACKAGE.zip'))) as p70:
                    manifest=json.loads(p70.read('PHASE69_MANIFEST.json'))
                    self.assertEqual(manifest['inherited_archive_sha256'],sha(b))
    def test_exact_checkpoint_archives_preserved(self):
        for path,digest in [('phase85.zip','c863061c8ccb90ffc9a8b6d9a3a62ee8f927ff054f06eb0aeadc897db5da2f63'),('branch74.zip','562e5b9137b7cf05f7f93d48977a3ccafa0a5362625927abbc029ff454fa2ad8')]:
            self.assertEqual(sha((ROOT/'provenance'/path).read_bytes()),digest)
    def test_final_handoff_preserves_master_prefix(self):
        master=(ROOT/'checkpoint85/MASTER/ARIYAN_TRADING_AI_COMPLETE_MASTER_ARCHIVE_THROUGH_15200.txt').read_bytes()
        self.assertTrue((ROOT/'FINAL_MASTER_HANDOFF.txt').read_bytes().startswith(master))
    def test_record_does_not_claim_full_completion(self):
        record=load('CONSOLIDATION.json');self.assertFalse(record['production_certified']);self.assertFalse(record['full_project_complete'])
        self.assertEqual(record['actual_source_owner_decisions'],0);self.assertEqual(record['actual_application_integrations_verified'],0)
    def test_five_legacy_path_moves_are_content_matches(self):
        audit=load('branch74/evidence/inherited_audit.json');relocated=[x for x in audit['manifest_checks'] if x.get('relocated_matches')]
        self.assertEqual(len(relocated),5)
        self.assertEqual(sum(x['matched'] for x in audit['manifest_checks']),46)
        self.assertEqual(sum(not x['matched'] and not x.get('relocated_matches') for x in audit['manifest_checks']),1)
        # One historically unavailable ZIP is separately recovered above; do not edit old reports.
    def test_rerun_inventory_matches_reported_methods(self):
        results=load('evidence/fresh_phase85_run/summary.json')
        self.assertEqual(len(results),20);self.assertEqual(sum(x['methods'] for x in results),306)
        self.assertTrue(all(x['returncode']==0 for x in results))

if __name__=='__main__':unittest.main(verbosity=2)
