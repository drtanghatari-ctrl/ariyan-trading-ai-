"""Run both preserved engineering branches without overlaying their imports."""
import argparse,json,os,pathlib,re,subprocess,sys
root=pathlib.Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser();p.add_argument('output');args=p.parse_args()
out=pathlib.Path(args.output).resolve()
if out==root or root in out.parents:raise SystemExit('Output must be outside the immutable consolidated checkpoint')
out.mkdir(parents=True,exist_ok=True)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1');env.pop('PYTHONPATH',None)
subprocess.run([sys.executable,'-B',str(root/'checkpoint85/phase80/reproduce.py'),str(out/'main85'),'--last-phase','85'],env=env,check=True)
records=json.loads((out/'main85/summary.json').read_text())
if len(records)!=20 or sum(r['methods'] for r in records)!=306:raise RuntimeError('Main branch method inventory changed')
for relative,expected in [('branch74/phase73/test_rotation.py',25),('branch74/phase74/test_acceptance.py',14),('tools/test_consolidation.py',12)]:
    test=root/relative
    r=subprocess.run([sys.executable,'-B',str(test)],env=env,capture_output=True,text=True,timeout=90)
    text=r.stdout+r.stderr;name=relative.replace('/','_')+'.txt';(out/name).write_text(text)
    match=re.search(r'Ran (\d+) tests?',text);count=int(match[1]) if match else None
    if r.returncode or count!=expected:raise RuntimeError('Suite failed or inventory changed: '+relative+'\n'+text)
    records.append({'suite':relative,'returncode':r.returncode,'methods':count})
summary={'main_branch_methods':306,'separate_branch_methods':39,'consolidation_checks':12,'total_methods':357,'suites':23,'all_passed':True,'not_semantic_coverage_or_certification':True,'suites_detail':records}
(out/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps({k:v for k,v in summary.items() if k!='suites_detail'},indent=2))
