import os
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from control_plane import GovernedAuthority
from rotation import Rejected

def worker(path,config,key_raw,policy,action,payload,barrier,queue,crash=None):
    a=None
    try:
        a=GovernedAuthority(path,config,Ed25519PrivateKey.from_private_bytes(key_raw),policy)
        if barrier is not None:barrier.wait(timeout=15)
        def hook(stage):
            if stage==crash:os._exit(78)
        result=a.submit(payload[0],payload[1],hook) if action=='checkpoint' else a.govern(payload,100,hook)
        if queue is not None:queue.put(('OK',action))
    except Rejected as exc:
        if queue is not None:queue.put(('REJECT',str(exc)))
        else:raise
    except BaseException as exc:
        if queue is not None:queue.put(('ERROR',repr(exc)))
        else:raise
    finally:
        if a is not None:a.close()
