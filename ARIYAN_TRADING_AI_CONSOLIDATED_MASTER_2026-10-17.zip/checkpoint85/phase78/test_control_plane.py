import copy,json,multiprocessing,pathlib,secrets,tempfile,unittest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.exceptions import InvalidSignature
from rotation import CustodianFixture,Witness,raw_public,Rejected,ZERO,canonical
from checkpoint import genesis,make_request
from governance import initial,proposal,approve
from control_plane import GovernedAuthority,assess_evidence,verify_control
from service_worker import worker

class ControlTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.p=pathlib.Path(self.tmp.name)
        self.c,self.root=CustodianFixture.create(self.p/'c');self.w=Witness.create(self.p/'w',self.c,self.root)
        self.client=Ed25519PrivateKey.generate();self.signer=Ed25519PrivateKey.generate()
        self.config={'tenant':'ariyan','witness':'w1','custody_root':self.root,'client_public':raw_public(self.client),'authority_public':raw_public(self.signer)}
        self.keys={n:Ed25519PrivateKey.generate() for n in ('one','two','three')}
        self.policy={'tenant':'ariyan','witness':'w1','approvers':{n:raw_public(k) for n,k in self.keys.items()},'quorum':2}
        self.a=GovernedAuthority.create_service(self.p/'a',self.config,self.signer,self.policy)
    def tearDown(self):self.a.close();self.w.close();self.c.close();self.tmp.cleanup()
    def gov_state(self):return self.a.query_control(secrets.token_hex(32))['body']['governance']
    def gov(self,action='freeze',params=None,names=('one','two')):
        if params is None:params={'reason_hash':'a'*64}
        return approve(proposal(self.policy,self.gov_state(),action,params,100,200),{n:self.keys[n] for n in names})
    def request(self):
        h=self.w.history();return make_request(self.client,self.config,self.a.snapshot()['generation'],self.gov_state()['epoch'],h),h
    def advance(self):
        self.w.issue(1,'a'*64);e,h=self.request();return self.a.submit(e,h)
    def assess(self,transport=None,cp=None,g=None,h=None):
        return assess_evidence(self.w.history() if h is None else h,transport or self.a.query_control,self.config,self.policy,cp or genesis(self.config),g or initial(self.policy))
    def test_integrated_current_evidence_never_financial_authority(self):
        self.advance();r=self.assess();self.assertTrue(r['evidence_current']);self.assertFalse(r['financial_authority'])
    def test_empty_evidence_blocked(self):self.assertFalse(self.assess()['evidence_current'])
    def test_unanchored_append_blocked(self):
        self.advance();self.w.rotate();self.assertFalse(self.assess()['evidence_current'])
    def test_partition_fail_closed(self):
        self.advance()
        def partition(_):raise TimeoutError('offline service unavailable')
        self.assertFalse(self.assess(partition)['evidence_current'])
    def test_replayed_response_blocked(self):
        self.advance();old=self.a.query_control('a'*64)
        self.assertFalse(self.assess(lambda _:old)['evidence_current'])
    def test_freeze_blocks_current_evidence_and_new_checkpoint(self):
        self.advance();self.a.govern(self.gov(),100);self.assertFalse(self.assess()['evidence_current'])
        self.w.rotate();e,h=self.request()
        with self.assertRaises(Rejected):self.a.submit(e,h)
    def test_stale_governance_epoch_rejected_after_resume(self):
        self.advance();self.w.rotate();e,h=self.request();self.a.govern(self.gov(),100)
        params={'reconciliation_hash':'b'*64,'checkpoint_head':self.a.snapshot()['head']}
        self.a.govern(self.gov('resume',params),100)
        with self.assertRaises(Rejected):self.a.submit(e,h)
        fresh,h=self.request();self.a.submit(fresh,h);self.assertTrue(self.assess()['evidence_current'])
    def test_resume_wrong_checkpoint_rejected(self):
        self.advance();self.a.govern(self.gov(),100)
        with self.assertRaises(Rejected):self.a.govern(self.gov('resume',{'reconciliation_hash':'b'*64,'checkpoint_head':ZERO}),100)
    def test_revocation_blocks_even_new_epoch(self):
        self.advance();self.a.govern(self.gov('revoke_client'),100);self.w.rotate();e,h=self.request()
        with self.assertRaises(Rejected):self.a.submit(e,h)
        self.assertFalse(self.assess()['evidence_current'])
    def test_historical_receipt_retry_after_freeze_is_not_current_permission(self):
        self.w.issue(1,'a'*64);e,h=self.request();old=self.a.submit(e,h);self.a.govern(self.gov(),100)
        self.assertEqual(old,self.a.submit(e,h));self.assertFalse(self.assess()['evidence_current'])
    def test_governance_accepted_time_tamper_detected(self):
        self.a.govern(self.gov(),100);self.a.db.execute('UPDATE governance_events SET accepted_at=101')
        with self.assertRaises(Rejected):self.a.snapshot()
    def test_governance_ack_signature_tamper_detected(self):
        self.a.govern(self.gov(),100);r=json.loads(self.a.db.execute('SELECT receipt FROM governance_ack').fetchone()[0]);r['signature']='0'*128
        self.a.db.execute('UPDATE governance_ack SET receipt=?',(canonical(r).decode(),))
        with self.assertRaises(InvalidSignature):self.a.snapshot()
    def test_governance_ack_missing_detected(self):
        self.a.govern(self.gov(),100);self.a.db.execute('DELETE FROM governance_ack')
        with self.assertRaises(Rejected):self.a.snapshot()
    def test_reopen_validates_combined_history(self):
        self.advance();self.a.govern(self.gov(),100);self.a.close();self.a=GovernedAuthority(self.p/'a',self.config,self.signer,self.policy)
        self.assertTrue(self.gov_state()['frozen'])
    def test_resume_then_later_freeze_verifies_historical_ack_binding(self):
        self.advance();self.a.govern(self.gov(),100)
        self.a.govern(self.gov('resume',{'reconciliation_hash':'b'*64,'checkpoint_head':self.a.snapshot()['head']}),100)
        self.w.rotate();e,h=self.request();self.a.submit(e,h);self.a.govern(self.gov(),100)
        self.assertEqual(self.a.snapshot()['generation'],2)
    def test_authority_storage_fault_no_partial_commit(self):
        self.w.issue(1,'a'*64);e,h=self.request()
        def fault(stage):
            if stage=='authority_before_commit':raise OSError('simulated disk full')
        with self.assertRaises(OSError):self.a.submit(e,h,fault)
        self.assertEqual(self.a.snapshot()['generation'],0)
    def test_governance_storage_fault_no_partial_commit(self):
        def fault(stage):
            if stage=='governance_before_commit':raise OSError('simulated disk full')
        with self.assertRaises(OSError):self.a.govern(self.gov(),100,fault)
        self.assertEqual(self.gov_state()['epoch'],1);self.assertEqual(self.a.db.execute('SELECT count(*) FROM governance_ack').fetchone()[0],0)
    def test_governance_lost_ack_retry(self):
        command=self.gov()
        def fault(stage):
            if stage=='governance_after_commit':raise TimeoutError()
        with self.assertRaises(TimeoutError):self.a.govern(command,100,fault)
        self.assertTrue(self.a.govern(command,100)['already_committed']);self.assertEqual(self.gov_state()['epoch'],2)
    def test_minimum_governance_rollback_rejected(self):
        nonce=secrets.token_hex(32);old=self.a.query_control(nonce);self.a.govern(self.gov(),100)
        with self.assertRaises(Rejected):verify_control(old,self.config,self.policy,nonce,genesis(self.config),self.gov_state())
    def test_root_nomination_stays_blocked(self):
        self.advance();self.a.govern(self.gov(),100);key=Ed25519PrivateKey.generate()
        b=proposal(self.policy,self.gov_state(),'nominate_root',{'new_root':raw_public(key),'recovery_evidence_hash':'b'*64},100,200)
        self.a.govern(approve(b,self.keys,key),100);self.assertFalse(self.assess()['evidence_current'])
    def test_spawn_freeze_checkpoint_race(self):
        self.w.issue(1,'a'*64);request=self.request();command=self.gov();ctx=multiprocessing.get_context('spawn');barrier=ctx.Barrier(2);q=ctx.Queue()
        jobs=[ctx.Process(target=worker,args=(self.p/'a',self.config,self.signer.private_bytes_raw(),self.policy,action,payload,barrier,q)) for action,payload in [('checkpoint',request),('governance',command)]]
        for job in jobs:job.start()
        try:
            for job in jobs:job.join(20);self.assertEqual(job.exitcode,0)
            results=[q.get(timeout=5) for _ in jobs]
            self.assertIn(('OK','governance'),results);self.assertNotIn('ERROR',[r[0] for r in results],results)
            self.assertTrue(self.gov_state()['frozen']);self.assertFalse(self.assess()['evidence_current'])
            self.assertIn(self.a.snapshot()['generation'],(0,1))
            for (raw,) in self.a.db.execute('SELECT receipt FROM commits'):
                self.assertEqual(json.loads(raw)['body']['governance_epoch'],1)
        finally:
            for job in jobs:
                if job.is_alive():job.terminate();job.join()
            q.close();q.join_thread()
    def test_spawn_crash_commit_matrix(self):
        ctx=multiprocessing.get_context('spawn')
        for action in ('checkpoint','governance'):
            for when in ('before','after'):
                with self.subTest(action=action,when=when):
                    path=self.p/(action+when);a=GovernedAuthority.create_service(path,self.config,self.signer,self.policy)
                    if not self.w.history():self.w.issue(1,'a'*64)
                    h=self.w.history()
                    payload=(make_request(self.client,self.config,0,1,h),h) if action=='checkpoint' else approve(proposal(self.policy,initial(self.policy),'freeze',{'reason_hash':'a'*64},100,200),self.keys)
                    a.close();stage=('authority' if action=='checkpoint' else 'governance')+'_'+when+'_commit'
                    job=ctx.Process(target=worker,args=(path,self.config,self.signer.private_bytes_raw(),self.policy,action,payload,None,None,stage));job.start();job.join(20)
                    if job.is_alive():job.terminate();job.join();self.fail('crash worker timed out')
                    self.assertEqual(job.exitcode,78)
                    a=GovernedAuthority(path,self.config,self.signer,self.policy)
                    try:
                        cp=a.snapshot();g=a.query_control('a'*64)['body']['governance']
                        expected=0 if when=='before' else 1
                        self.assertEqual(cp['generation'] if action=='checkpoint' else g['epoch']-1,expected)
                        self.assertEqual(a.db.execute('SELECT count(*) FROM governance_ack').fetchone()[0],g['epoch']-1)
                    finally:a.close()

if __name__=='__main__':unittest.main(verbosity=2)
