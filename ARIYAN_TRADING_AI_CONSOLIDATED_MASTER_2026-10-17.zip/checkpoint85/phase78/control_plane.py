"""Integrated OFFLINE reference evidence service. No execution or trading API.
Governance and checkpoint writes share one SQLite write lock. This is local
serializability, not distributed consensus, broker fencing or an execution lease.
"""
import json,secrets
from rotation import canonical,digest,Rejected,transaction,verify_history,ZERO,integer,hexfield
from checkpoint import Authority,genesis,exact,signed,verify_signature,verify_query
from governance import Governance,initial,transition,validate_policy
DOMAIN='ARIYAN-CONTROL-EVIDENCE-v1'

class GovernedAuthority(Authority):
    @classmethod
    def create_service(cls,path,config,signer,policy):
        if (config['tenant'],config['witness'])!=(policy['tenant'],policy['witness']):raise Rejected('policy scope')
        a=Authority.create(path,config,signer);a.close()
        g=Governance.provision(path,policy)
        try:g.db.execute('CREATE TABLE governance_ack(n INTEGER PRIMARY KEY,receipt TEXT NOT NULL)')
        finally:g.close()
        return cls(path,config,signer,policy)
    def __init__(self,path,config,signer,policy):
        validate_policy(policy)
        if (config['tenant'],config['witness'])!=(policy['tenant'],policy['witness']):raise Rejected('policy scope')
        self.gov_policy=policy
        super().__init__(path,config,signer,self._gate)
    def _governance(self):return Governance.read_from(self.db,self.gov_policy)
    def _read(self):
        state=super()._read();current=self._governance()
        # Authenticate actual accepted-at and checkpoint binding, beyond approver proposals.
        rows=self.db.execute('SELECT n,accepted_at,envelope FROM governance_events ORDER BY n').fetchall()
        acks=self.db.execute('SELECT n,receipt FROM governance_ack ORDER BY n').fetchall()
        if [n for n,_,_ in rows]!=[n for n,_ in acks]:raise Rejected('missing/extra governance acknowledgement')
        commits=[json.loads(r[0]) for r in self.db.execute('SELECT receipt FROM commits ORDER BY n')]
        epoch_states={1:initial(self.gov_policy)};previous=initial(self.gov_policy)
        for (n,accepted_at,raw),(_,ack_raw) in zip(rows,acks):
            e=json.loads(raw);ack=json.loads(ack_raw);exact(ack,('body','signature'));b=ack['body']
            exact(b,('domain','tenant','witness','epoch','proposal_hash','accepted_at','checkpoint_generation','checkpoint_head'))
            eligible=[r for r in commits if r['body']['governance_epoch']<=previous['epoch']]
            cp_generation=eligible[-1]['body']['generation'] if eligible else 0
            cp_head=digest(eligible[-1]) if eligible else ZERO
            expected={'domain':DOMAIN,'tenant':self.config['tenant'],'witness':self.config['witness'],'epoch':n+1,'proposal_hash':digest(e),'accepted_at':accepted_at,'checkpoint_generation':cp_generation,'checkpoint_head':cp_head}
            if b!=expected:raise Rejected('governance acknowledgement binding')
            # Reject bool/int aliasing in persisted signed time/generation fields.
            for field in ('epoch','accepted_at','checkpoint_generation'):integer(b[field])
            verify_signature(self.config['authority_public'],b,ack['signature'])
            if e['proposal']['action']=='resume' and e['proposal']['params']['checkpoint_head']!=cp_head:raise Rejected('resume checkpoint binding')
            previous=transition(self.gov_policy,previous,e,accepted_at);epoch_states[previous['epoch']]=previous
        for r in commits:
            b=r['body'];g=epoch_states.get(b['governance_epoch'])
            if g is None or g['frozen'] or g['revoked'] or g['candidate_root']:raise Rejected('checkpoint issued under blocked/unknown governance')
        return state
    def _gate(self,request,state):
        g=self._governance()
        if request['governance_epoch']!=g['epoch'] or g['frozen'] or g['revoked'] or g['candidate_root']:raise Rejected('governance blocks checkpoint')
    def govern(self,envelope,now,hook=lambda _:None):
        exact(envelope,('proposal','approvals','possession'));op=envelope['proposal']['op'];hexfield(op,32)
        with transaction(self.db):
            checkpoint=self._read();g=self._governance()
            prior=self.db.execute('SELECT envelope FROM governance_events WHERE op=?',(op,)).fetchone()
            if prior:
                if prior[0]!=canonical(envelope).decode():raise Rejected('governance operation substitution')
                return {'already_committed':True,'current':g}
            new=transition(self.gov_policy,g,envelope,now)
            if envelope['proposal']['action']=='resume' and envelope['proposal']['params']['checkpoint_head']!=checkpoint['head']:raise Rejected('resume requires current checkpoint')
            b={'domain':DOMAIN,'tenant':self.config['tenant'],'witness':self.config['witness'],'epoch':new['epoch'],'proposal_hash':digest(envelope),'accepted_at':now,'checkpoint_generation':checkpoint['generation'],'checkpoint_head':checkpoint['head']}
            ack=signed(self.signer,b)
            self.db.execute('INSERT INTO governance_events VALUES(?,?,?,?)',(g['epoch'],op,now,canonical(envelope).decode()))
            self.db.execute('INSERT INTO governance_ack VALUES(?,?)',(g['epoch'],canonical(ack).decode()))
            hook('governance_before_commit')
        hook('governance_after_commit')
        return {'already_committed':False,'current':new}
    def query_control(self,challenge):
        hexfield(challenge,64)
        with transaction(self.db):
            state=self._read();g=self._governance()
            return signed(self.signer,{'domain':DOMAIN,'tenant':self.config['tenant'],'witness':self.config['witness'],'challenge':challenge,'checkpoint':state,'governance':g})

def verify_control(packet,config,policy,challenge,minimum_checkpoint,minimum_governance):
    exact(packet,('body','signature'));b=packet['body']
    exact(b,('domain','tenant','witness','challenge','checkpoint','governance'))
    if (b['domain'],b['tenant'],b['witness'],b['challenge'])!=(DOMAIN,config['tenant'],config['witness'],challenge):raise Rejected('control response scope/challenge')
    verify_signature(config['authority_public'],b,packet['signature'])
    cp=b['checkpoint'];exact(cp,('generation','head','floor_index','floor_head','custody_root'))
    for item in (cp,minimum_checkpoint):
        exact(item,('generation','head','floor_index','floor_head','custody_root'))
        integer(item['generation']);integer(item['floor_index'])
        for name in ('head','floor_head','custody_root'):hexfield(item[name],64)
    if cp['custody_root']!=config['custody_root'] or minimum_checkpoint['custody_root']!=cp['custody_root']:raise Rejected('control root')
    if cp['generation']<minimum_checkpoint['generation'] or cp['floor_index']<minimum_checkpoint['floor_index']:raise Rejected('control checkpoint rollback')
    if cp['generation']==minimum_checkpoint['generation'] and cp!=minimum_checkpoint:raise Rejected('control checkpoint fork')
    if cp['floor_index']==minimum_checkpoint['floor_index'] and cp['floor_head']!=minimum_checkpoint['floor_head']:raise Rejected('control floor fork')
    g=b['governance'];exact(g,('epoch','head','frozen','revoked','candidate_root','last_time'))
    for item in (g,minimum_governance):
        exact(item,('epoch','head','frozen','revoked','candidate_root','last_time'));integer(item['epoch'],1);integer(item['last_time']);hexfield(item['head'],64)
        if type(item['frozen']) is not bool or type(item['revoked']) is not bool:raise Rejected('governance boolean')
        if item['candidate_root']!='':hexfield(item['candidate_root'],64)
    if g['epoch']<minimum_governance['epoch'] or g['last_time']<minimum_governance['last_time']:raise Rejected('governance rollback')
    if g['epoch']==minimum_governance['epoch'] and g!=minimum_governance:raise Rejected('governance fork')
    return cp,g

def assess_evidence(history,transport,config,policy,minimum_checkpoint,minimum_governance):
    """Point-in-time evidence assessment only; never permission for an external effect."""
    try:
        if type(history) is not list or len(history)>10000 or len(canonical(history))>8*1024*1024:raise Rejected('history limits')
        challenge=secrets.token_hex(32)
        cp,g=verify_control(transport(challenge),config,policy,challenge,minimum_checkpoint,minimum_governance)
        if g['frozen'] or g['revoked'] or g['candidate_root']:raise Rejected('governance blocked')
        h=verify_history(history,config['custody_root'],(cp['floor_index'],cp['floor_head']))
        if (h['index'],h['head'])!=(cp['floor_index'],cp['floor_head']) or h['index']==0:raise Rejected('evidence is unanchored or empty')
        return {'evidence_current':True,'financial_authority':False,'checkpoint_minimum':cp,'governance_minimum':g}
    except Exception as exc:
        return {'evidence_current':False,'financial_authority':False,'error_type':type(exc).__name__}
