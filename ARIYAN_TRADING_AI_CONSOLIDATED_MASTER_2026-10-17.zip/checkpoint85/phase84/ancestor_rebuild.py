"""Rebuild an exact deterministic ancestor ZIP from preserved payload bytes.
This avoids recursively embedding another full ZIP while proving continuity.
"""
import hashlib,json,pathlib,tempfile
from archive_integrity import package_directory,strict_object,MANIFEST,MAX_TOTAL
from recovery import portable

def rebuild_ancestor(root,manifest_path,relocations,expected_sha256,destination):
    root=pathlib.Path(root).resolve();manifest_path=pathlib.Path(manifest_path);destination=pathlib.Path(destination)
    if destination.exists() or destination.is_symlink():raise ValueError('ancestor output already exists')
    if manifest_path.stat().st_size>2*1024*1024:raise ValueError('ancestor manifest quota')
    obj=json.loads(manifest_path.read_bytes(),object_pairs_hook=strict_object)
    if set(obj)!={'version','files'} or type(obj['version']) is not int or obj['version']!=1 or type(obj['files']) is not dict or len(obj['files'])>1000:raise ValueError('ancestor manifest schema')
    if type(relocations) is not dict or set(relocations)-set(obj['files']):raise ValueError('unknown ancestor relocation')
    if type(expected_sha256) is not str or len(expected_sha256)!=64 or any(c not in '0123456789abcdef' for c in expected_sha256):raise ValueError('ancestor fingerprint required')
    with tempfile.TemporaryDirectory(dir=destination.parent) as tmp:
        stage=pathlib.Path(tmp)/'ancestor';stage.mkdir()
        total=0
        for name,expected in obj['files'].items():
            portable(name);relative=relocations.get(name,name);portable(relative);source=root/relative
            if source.is_symlink() or not source.resolve().is_relative_to(root) or not source.is_file():raise ValueError('unsafe or unavailable ancestor payload')
            if source.stat().st_size>16*1024*1024:raise ValueError('ancestor file quota')
            total+=source.stat().st_size
            if total>MAX_TOTAL:raise ValueError('ancestor total-byte quota')
            raw=source.read_bytes()
            if hashlib.sha256(raw).hexdigest()!=expected:raise ValueError('ancestor payload changed')
            target=stage/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
        rebuilt=pathlib.Path(tmp)/'ancestor.zip';result=package_directory(stage,rebuilt)
        if result['archive_sha256']!=expected_sha256:raise ValueError('ancestor ZIP fingerprint does not reproduce')
        with destination.open('xb') as f:f.write(rebuilt.read_bytes())
    return {'ancestor_sha256':expected_sha256,'payloads_preserved':len(obj['files']),'byte_identical_zip_rebuilt':True,'executed_code':False}

if __name__=='__main__':
    import sys
    print(json.dumps(rebuild_ancestor(sys.argv[1],sys.argv[2],json.loads(pathlib.Path(sys.argv[3]).read_text()),sys.argv[4],sys.argv[5]),indent=2))
