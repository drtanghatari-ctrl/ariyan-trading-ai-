import hashlib,pathlib,subprocess,sys,tempfile,unittest,zipfile
from archive_integrity import package_directory
from recovery import restore_checkpoint,exclusive_lock,install_no_replace

class RecoveryTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.p=pathlib.Path(self.tmp.name);self.src=self.p/'src';self.src.mkdir()
        (self.src/'nested').mkdir();(self.src/'nested/code.py').write_text('raise RuntimeError("must never execute")\n');(self.src/'history.txt').write_bytes(b'original\x00bytes\r\n')
        self.archive=self.p/'checkpoint.zip';package_directory(self.src,self.archive);self.fingerprint=hashlib.sha256(self.archive.read_bytes()).hexdigest();self.dest=self.p/'restored'
    def tearDown(self):self.tmp.cleanup()
    def restore(self,hook=lambda _:None):return restore_checkpoint(self.archive,self.fingerprint,self.dest,hook)
    def test_exact_restore_never_executes(self):
        r=self.restore();self.assertTrue(r['restored']);self.assertFalse(r['executed_code']);self.assertFalse(r['deployment']);self.assertEqual((self.dest/'history.txt').read_bytes(),b'original\x00bytes\r\n')
    def test_idempotent_complete_retry(self):
        self.restore();self.assertTrue(self.restore()['already_complete'])
    def test_wrong_fingerprint_writes_nothing(self):
        with self.assertRaises(ValueError):restore_checkpoint(self.archive,'0'*64,self.dest)
        self.assertFalse(self.dest.exists())
    def test_existing_unrelated_directory_preserved(self):
        self.dest.mkdir();(self.dest/'user.txt').write_text('keep')
        with self.assertRaises(ValueError):self.restore()
        self.assertEqual((self.dest/'user.txt').read_text(),'keep')
    def test_existing_empty_directory_is_not_clobbered(self):
        self.dest.mkdir()
        with self.assertRaises(ValueError):self.restore()
        self.assertEqual(list(self.dest.iterdir()),[])
    def test_destination_symlink_rejected(self):
        target=self.p/'other';target.mkdir();self.dest.symlink_to(target,target_is_directory=True)
        with self.assertRaises(ValueError):self.restore()
        self.assertEqual(list(target.iterdir()),[])
    def test_no_replace_install_protects_racing_directory(self):
        a=self.p/'a';b=self.p/'b';a.mkdir();b.mkdir()
        with self.assertRaises(OSError):install_no_replace(a,b)
        self.assertTrue(a.is_dir());self.assertTrue(b.is_dir())
    def test_lock_contention_fails_closed(self):
        lock=self.p/('.restored.restore-'+self.fingerprint[:16]+'.lock')
        with exclusive_lock(lock):
            with self.assertRaises((BlockingIOError,OSError)):self.restore()
        self.assertFalse(self.dest.exists())
    def test_hook_storage_failure_resumes_without_overwrite(self):
        def fail(stage):
            if stage=='file_committed':raise OSError('injected storage boundary failure')
        with self.assertRaises(OSError):self.restore(fail)
        self.assertFalse(self.dest.exists());self.assertTrue(self.restore()['restored'])
    def test_staging_tamper_preserved_and_rejected(self):
        def fail(stage):
            if stage=='file_committed':raise OSError()
        with self.assertRaises(OSError):self.restore(fail)
        stage=self.p/('.restored.restore-'+self.fingerprint[:16]);existing=next(p for p in (stage/'payload').rglob('*') if p.is_file());existing.write_text('tamper')
        with self.assertRaises(ValueError):self.restore()
        self.assertEqual(existing.read_text(),'tamper');self.assertFalse(self.dest.exists())
    def test_after_install_lost_ack_is_recoverable(self):
        def fail(stage):
            if stage=='after_install':raise TimeoutError()
        with self.assertRaises(TimeoutError):self.restore(fail)
        self.assertTrue(self.dest.is_dir());self.assertTrue(self.restore()['already_complete'])
    def test_unexpected_staging_content_not_deleted(self):
        stage=self.p/('.restored.restore-'+self.fingerprint[:16]);stage.mkdir();(stage/'unrelated').write_text('keep')
        with self.assertRaises(ValueError):self.restore()
        self.assertEqual((stage/'unrelated').read_text(),'keep')
    def test_abrupt_process_exit_matrix(self):
        for point in ('stage_initialized','file_committed','before_install','after_install'):
            with self.subTest(point=point):
                dest=self.p/('restore_'+point)
                r=subprocess.run([sys.executable,'-B',str(pathlib.Path(__file__).with_name('recovery_worker.py')),str(self.archive),self.fingerprint,str(dest),point],capture_output=True,text=True,timeout=15)
                self.assertEqual(r.returncode,84,r.stderr)
                result=restore_checkpoint(self.archive,self.fingerprint,dest);self.assertTrue(result['restored']);self.assertEqual((dest/'history.txt').read_bytes(),b'original\x00bytes\r\n')

if __name__=='__main__':unittest.main(verbosity=2)
