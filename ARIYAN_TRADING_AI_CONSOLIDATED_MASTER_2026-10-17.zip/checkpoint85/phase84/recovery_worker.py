import os,sys
from recovery import restore_checkpoint

def main():
    archive,fingerprint,destination,point=sys.argv[1:]
    def hook(stage):
        if stage==point:os._exit(84)
    restore_checkpoint(archive,fingerprint,destination,hook)

if __name__=='__main__':main()
