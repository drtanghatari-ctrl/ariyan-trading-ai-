import json,pathlib,tempfile,unittest,zipfile
from archive_integrity import package_directory,MANIFEST
from ancestor_rebuild import rebuild_ancestor

class AncestorTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.p=pathlib.Path(self.tmp.name);self.old=self.p/'old';self.old.mkdir();(self.old/'state.txt').write_text('old checkpoint')
        self.archive=self.p/'old.zip';self.sha=package_directory(self.old,self.archive)['archive_sha256']
        with zipfile.ZipFile(self.archive) as z:self.manifest=z.read(MANIFEST)
        self.new=self.p/'new';self.new.mkdir();(self.new/'history').mkdir();(self.new/'history/old-state.txt').write_text('old checkpoint');(self.new/'state.txt').write_text('new checkpoint');(self.new/'old-manifest.json').write_bytes(self.manifest)
    def tearDown(self):self.tmp.cleanup()
    def test_exact_ancestor_reconstruction_with_relocated_records(self):
        output=self.p/'rebuilt.zip';r=rebuild_ancestor(self.new,self.new/'old-manifest.json',{'state.txt':'history/old-state.txt'},self.sha,output)
        self.assertTrue(r['byte_identical_zip_rebuilt']);self.assertEqual(self.archive.read_bytes(),output.read_bytes())
    def test_changed_ancestor_or_existing_output_rejected(self):
        (self.new/'history/old-state.txt').write_text('changed');out=self.p/'rebuilt.zip'
        with self.assertRaises(ValueError):rebuild_ancestor(self.new,self.new/'old-manifest.json',{'state.txt':'history/old-state.txt'},self.sha,out)
        self.assertFalse(out.exists());out.write_text('keep')
        with self.assertRaises(ValueError):rebuild_ancestor(self.new,self.new/'old-manifest.json',{},self.sha,out)
        self.assertEqual(out.read_text(),'keep')
    def test_total_rebuild_quota_before_output(self):
        import unittest.mock
        out=self.p/'quota.zip'
        with unittest.mock.patch('ancestor_rebuild.MAX_TOTAL',1):
            with self.assertRaises(ValueError):rebuild_ancestor(self.new,self.new/'old-manifest.json',{'state.txt':'history/old-state.txt'},self.sha,out)
        self.assertFalse(out.exists())

if __name__=='__main__':unittest.main(verbosity=2)
