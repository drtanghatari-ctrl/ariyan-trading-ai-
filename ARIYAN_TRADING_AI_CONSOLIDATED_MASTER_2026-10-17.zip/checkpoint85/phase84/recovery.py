"""Non-executing, resumable local checkpoint restoration with no-clobber install.
Linux implementation is executed in tests; Windows locking/rename path is untested.
This is file recovery, not deployment, production integration or power-loss proof.
"""
import contextlib,ctypes,errno,hashlib,json,os,pathlib,stat,sys,zipfile
from archive_integrity import verify_package,MANIFEST,safe_name

def sha(raw):return hashlib.sha256(raw).hexdigest()
def portable(name):
    safe_name(name)
    if any(ord(c)<32 or c in '<>"|?*' for c in name):raise ValueError('nonportable checkpoint path')

def fsync_dir(path):
    if hasattr(os,'O_DIRECTORY'):
        fd=os.open(str(path),os.O_RDONLY|os.O_DIRECTORY)
        try:os.fsync(fd)
        finally:os.close(fd)

@contextlib.contextmanager
def exclusive_lock(path):
    path=pathlib.Path(path)
    if path.is_symlink():raise ValueError('symlink lock')
    flags=os.O_CREAT|os.O_RDWR|getattr(os,'O_NOFOLLOW',0)
    fd=os.open(str(path),flags,0o600)
    if not stat.S_ISREG(os.fstat(fd).st_mode):os.close(fd);raise ValueError('nonregular lock')
    handle=os.fdopen(fd,'r+b',buffering=0)
    try:
        if os.name=='nt':
            import msvcrt
            if os.fstat(fd).st_size==0:handle.write(b'0');handle.flush()
            handle.seek(0);msvcrt.locking(fd,msvcrt.LK_NBLCK,1)
        else:
            import fcntl
            fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
        yield
    finally:handle.close()

def install_no_replace(source,destination):
    if os.name=='nt':os.rename(source,destination);return
    if sys.platform!='linux':raise NotImplementedError('no tested atomic no-clobber directory install on this platform')
    libc=ctypes.CDLL(None,use_errno=True)
    if not hasattr(libc,'renameat2'):raise NotImplementedError('renameat2 is unavailable')
    function=libc.renameat2;function.argtypes=[ctypes.c_int,ctypes.c_char_p,ctypes.c_int,ctypes.c_char_p,ctypes.c_uint];function.restype=ctypes.c_int
    if function(-100,os.fsencode(source),-100,os.fsencode(destination),1)!=0:
        code=ctypes.get_errno();raise OSError(code,os.strerror(code),str(destination))

def inspect_tree(root,expected,complete):
    root=pathlib.Path(root)
    if root.is_symlink() or not root.is_dir():raise ValueError('unsafe recovery tree')
    found=set()
    for p in root.rglob('*'):
        if p.is_symlink():raise ValueError('symlink in recovery tree')
        if p.is_dir():continue
        if not p.is_file():raise ValueError('nonregular recovered entry')
        name=p.relative_to(root).as_posix();found.add(name)
        if name not in expected or sha(p.read_bytes())!=expected[name]:raise ValueError('unexpected or altered recovery file')
    if complete and found!=set(expected):raise ValueError('incomplete recovered checkpoint')
    return found

def stage_open(stage,identity):
    if stage.is_symlink():raise ValueError('symlink staging directory')
    if not stage.exists():
        stage.mkdir(mode=0o700)
        marker=stage/'metadata.json'
        with marker.open('xb') as f:f.write(json.dumps(identity,sort_keys=True).encode());f.flush();os.fsync(f.fileno())
        (stage/'payload').mkdir();(stage/'work').mkdir();fsync_dir(stage);fsync_dir(stage.parent)
    if not stage.is_dir() or {p.name for p in stage.iterdir()}-{'metadata.json','payload','work'}:raise ValueError('unrecognized staging content')
    marker=stage/'metadata.json'
    if marker.is_symlink() or not marker.is_file() or marker.stat().st_size>4096 or json.loads(marker.read_bytes())!=identity:raise ValueError('staging identity mismatch')
    work=stage/'work'
    if work.is_symlink() or not work.is_dir():raise ValueError('unsafe staging work directory')
    for p in work.iterdir():
        if p.name!='member.tmp' or p.is_symlink() or not p.is_file():raise ValueError('unrecognized staging work entry')

def cleanup_stage(stage,identity):
    if not stage.exists():return
    stage_open(stage,identity)
    if (stage/'payload').exists():raise ValueError('refuse to erase staged payload')
    temp=stage/'work/member.tmp'
    if temp.exists():temp.unlink()
    (stage/'work').rmdir();(stage/'metadata.json').unlink();stage.rmdir();fsync_dir(stage.parent)

def restore_checkpoint(archive,expected_sha256,destination,hook=lambda _:None):
    if type(expected_sha256) is not str or len(expected_sha256)!=64 or any(c not in '0123456789abcdef' for c in expected_sha256):raise ValueError('explicit caller fingerprint required')
    result=verify_package(archive,expected_sha256)
    destination=pathlib.Path(destination).absolute()
    if destination.is_symlink() or destination.parent.is_symlink() or not destination.parent.is_dir():raise ValueError('unsafe destination')
    if destination.name in ('','.','..'):raise ValueError('invalid destination')
    stage=destination.parent/('.'+destination.name+'.restore-'+expected_sha256[:16])
    identity={'version':1,'archive_sha256':expected_sha256,'destination':str(destination)}
    # Lock files persist intentionally; deleting them after unlock can create inode races.
    with exclusive_lock(str(stage)+'.lock'):
        with zipfile.ZipFile(archive) as z:
            manifest=json.loads(z.read(MANIFEST));expected=dict(manifest['files']);expected[MANIFEST]=sha(z.read(MANIFEST))
            for name in expected:portable(name)
            names={name.casefold() for name in expected}
            for name in names:
                parts=name.split('/')
                if any('/'.join(parts[:i]) in names for i in range(1,len(parts))):raise ValueError('file/directory prefix collision')
            if destination.exists():
                inspect_tree(destination,expected,True)
                if stage.exists():cleanup_stage(stage,identity)
                return {'restored':True,'already_complete':True,'files':len(expected),'archive_sha256':expected_sha256,'executed_code':False,'deployment':False}
            stage_open(stage,identity);hook('stage_initialized')
            payload=stage/'payload';found=inspect_tree(payload,expected,False)
            for name in sorted(expected):
                if name in found:continue
                raw=z.read(name)
                if sha(raw)!=expected[name]:raise ValueError('archive changed during restoration')
                target=payload/name;target.parent.mkdir(parents=True,exist_ok=True)
                temp=stage/'work/member.tmp'
                if temp.is_symlink():raise ValueError('symlink temporary file')
                with temp.open('wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
                os.replace(temp,target);fsync_dir(target.parent);hook('file_committed')
            inspect_tree(payload,expected,True);hook('before_install')
            install_no_replace(payload,destination);fsync_dir(destination.parent);hook('after_install')
            cleanup_stage(stage,identity)
    return {'restored':True,'already_complete':False,'files':len(expected),'archive_sha256':expected_sha256,'executed_code':False,'deployment':False}

if __name__=='__main__':
    print(json.dumps(restore_checkpoint(sys.argv[1],sys.argv[2],sys.argv[3]),indent=2))
