"""Preserve and compare alternative numbered sources; never choose normative authority."""
import hashlib,json,pathlib,re
PATTERN=re.compile(rb'(?im)^[ \t]*(?:SECTION[ \t]+)?(61\d\d|6200)[ \t]*(?:\xe2\x80\x94|\xe2\x80\x93|-)[ \t]*([^\n]+)')
END=b'End of Sections 6101'

def parse_block(raw):
    end=raw.find(END)
    if end<0:raise ValueError('explicit 6101-6200 end marker missing')
    matches=list(PATTERN.finditer(raw,0,end));rows={}
    for i,m in enumerate(matches):
        n=int(m[1])
        if n in rows:raise ValueError('duplicate numbered source clause')
        stop=matches[i+1].start() if i+1<len(matches) else end
        body=raw[m.start():stop]
        rows[n]={'section':n,'line':raw.count(b'\n',0,m.start())+1,'byte_start':m.start(),'byte_end':stop,'heading':m[0].decode().strip(),'sha256':hashlib.sha256(body).hexdigest(),'bytes':len(body)}
    if set(rows)!=set(range(6101,6201)):raise ValueError('expected 100 explicit source headings')
    return rows

def compare(master_raw,alternate_raw,out):
    a=parse_block(master_raw);b=parse_block(alternate_raw);out=pathlib.Path(out);out.mkdir(parents=True,exist_ok=True)
    rows=[]
    for n in range(6101,6201):
        rows.append({'section':n,'master_source_10':a[n],'supplementary_source':b[n],'byte_equal':a[n]['sha256']==b[n]['sha256'],'heading_equal':a[n]['heading']==b[n]['heading'],'authority':'UNADJUDICATED_COEXISTING_SOURCE_VARIANTS','merge_performed':False,'semantic_conflict_status':'NOT_EXHAUSTIVELY_ASSESSED'})
    result={'master_source_10_sha256':hashlib.sha256(master_raw).hexdigest(),'alternate_sha256':hashlib.sha256(alternate_raw).hexdigest(),'master_explicit_sections':100,'alternate_explicit_sections':100,'byte_equal_numbered_blocks':sum(r['byte_equal'] for r in rows),'same_headings':sum(r['heading_equal'] for r in rows),'normative_supersession_established':False,'original_baseline_sources':27,'supplementary_sources':1,'semantic_decision':'OWNER_AND_INDEPENDENT_REVIEW_REQUIRED'}
    (out/'comparison.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n');(out/'SUMMARY.json').write_text(json.dumps(result,indent=2)+'\n')
    return result

if __name__=='__main__':
    import sys
    print(json.dumps(compare(pathlib.Path(sys.argv[1]).read_bytes(),pathlib.Path(sys.argv[2]).read_bytes(),sys.argv[3]),indent=2))
