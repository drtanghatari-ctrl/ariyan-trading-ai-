import pathlib,tempfile,unittest
from variant_compare import parse_block,compare

def source(suffix=''):
    return (''.join(f'{n} — Requirement {n}{suffix}\nNormative body.\n\n' for n in range(6101,6201))+'End of Sections 6101–6200.\n').encode()

class VariantTests(unittest.TestCase):
    def test_full_hundred_explicit_headings(self):self.assertEqual(len(parse_block(source())),100)
    def test_identical_bytes_are_not_supersession(self):
        with tempfile.TemporaryDirectory() as tmp:
            r=compare(source(),source(),tmp);self.assertEqual(r['byte_equal_numbered_blocks'],100);self.assertFalse(r['normative_supersession_established'])
    def test_differing_versions_remain_separate(self):
        with tempfile.TemporaryDirectory() as tmp:
            r=compare(source(),source(' alternative'),tmp);self.assertEqual(r['byte_equal_numbered_blocks'],0);self.assertEqual(r['supplementary_sources'],1)
    def test_incomplete_source_rejected(self):
        raw=source().replace('6101 — Requirement 6101'.encode(),b'No heading')
        with self.assertRaises(ValueError):parse_block(raw)
    def test_duplicate_numbers_rejected(self):
        raw=source().replace('6102 — Requirement 6102'.encode(),'6101 — Again'.encode())
        with self.assertRaises(ValueError):parse_block(raw)
    def test_end_marker_required(self):
        with self.assertRaises(ValueError):parse_block(source().replace(b'End of Sections 6101',b'Unknown ending'))
    def test_offsets_preserve_exact_clause_bytes(self):
        raw=source();r=parse_block(raw)[6101];self.assertEqual(raw[r['byte_start']:r['byte_end']],('6101 — Requirement 6101\nNormative body.\n\n').encode())

if __name__=='__main__':unittest.main(verbosity=2)
