import copy
import pathlib
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from cryptography.exceptions import InvalidSignature
from rotation import CustodianFixture, Witness, Rejected, verify_history, digest, ZERO

class RotationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = pathlib.Path(self.tmp.name)
        self.cp = self.path/'custody.db'; self.wp = self.path/'witness.db'
        self.c, self.root = CustodianFixture.create(self.cp)
        self.w = Witness.create(self.wp, self.c, self.root)
    def tearDown(self):
        self.w.close(); self.c.close(); self.tmp.cleanup()
    def state(self):
        return verify_history(self.w.history(), self.root)
    def test_initial_pinned_identity(self):
        self.assertEqual(self.state()['epoch'], 1)
        self.assertEqual(self.state()['head'], ZERO)
    def test_issue_and_verify(self):
        self.w.issue(1, 'a'*64)
        self.assertEqual(self.state()['seq'], 1)
    def test_rotation_preserves_checkpoint(self):
        self.w.issue(1, 'a'*64); before = self.state()
        self.w.rotate(); after = self.state()
        self.assertEqual((after['seq'],after['digest']),(before['seq'],before['digest']))
        self.assertEqual(after['epoch'], 2); self.assertNotEqual(after['public'],before['public'])
    def test_repeated_rotations(self):
        for i in range(1, 5):
            self.w.issue(i, f'{i:064x}'); self.w.rotate()
        self.assertEqual(self.state()['epoch'], 5)
    def test_duplicate_issue_stable_after_rotation(self):
        receipt = self.w.issue(1, 'a'*64); self.w.rotate()
        self.assertEqual(receipt, self.w.issue(1, 'a'*64))
        self.assertEqual(self.state()['index'], 2)
    def test_equivocation_rejected(self):
        self.w.issue(1, 'a'*64)
        with self.assertRaises(Rejected): self.w.issue(1, 'b'*64)
    def test_stale_sequence_rejected(self):
        self.w.issue(2, 'a'*64)
        with self.assertRaises(Rejected): self.w.issue(1, 'a'*64)
    def test_input_validation(self):
        for seq, value in [(True,'a'*64),(0,'a'*64),(1,'A'*64),(1,3),(2**63,'a'*64)]:
            with self.subTest(seq=seq,value=value):
                with self.assertRaises(Rejected): self.w.issue(seq,value)
        self.assertEqual(self.state()['index'], 0)
    def test_restart_both_components(self):
        self.w.issue(1,'a'*64); self.w.rotate(); old = self.state()
        self.w.close(); self.c.close()
        self.c = CustodianFixture(self.cp,self.root); self.w = Witness(self.wp,self.c,self.root)
        self.assertEqual(old,self.state()); self.w.issue(2,'b'*64)
    def test_wrong_root_rejected(self):
        with self.assertRaises(Rejected): Witness(self.wp,self.c,'f'*64)
    def test_custodian_wrong_root_rejected(self):
        with self.assertRaises(Rejected): CustodianFixture(self.cp,'f'*64)
    def test_no_private_key_in_witness(self):
        self.w.rotate()
        tables = self.w.db.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
        fields = [r[1] for (t,) in tables for r in self.w.db.execute('PRAGMA table_info('+t+')')]
        self.assertFalse(set(fields) & {'secret','private','private_key'})
        for (raw,) in self.c.db.execute('SELECT secret FROM keys'):
            self.assertNotIn(raw,self.wp.read_bytes())
    def test_missing_store_not_reset(self):
        with self.assertRaises(Rejected): Witness(self.path/'absent',self.c,self.root)
        with self.assertRaises(Rejected): CustodianFixture(self.path/'absent',self.root)
    def test_bootstrap_nonempty_custodian_rejected(self):
        self.w.issue(1,'a'*64)
        with self.assertRaises(Rejected): Witness.create(self.path/'new',self.c,self.root)
    def test_trusted_floor_blocks_rollback(self):
        self.w.issue(1,'a'*64); h = self.w.history()
        self.assertEqual(verify_history(h,self.root,(1,digest(h[0])))['seq'],1)
        with self.assertRaises(Rejected): verify_history([],self.root,(1,digest(h[0])))
    def test_forged_rotation_proof_rejected(self):
        self.w.rotate(); h = self.w.history(); h[0]['signature']='0'*128
        with self.assertRaises(InvalidSignature): verify_history(h,self.root)
    def test_proof_of_possession_rejected(self):
        self.w.rotate(); h = self.w.history(); h[0]['possession']='0'*128
        with self.assertRaises(InvalidSignature): verify_history(h,self.root)
    def test_history_gap_rejected(self):
        self.w.issue(1,'a'*64); self.w.rotate(); h = self.w.history()
        with self.assertRaises(Rejected): verify_history(h[1:],self.root)
    def test_witness_truncation_rejected_against_custodian(self):
        self.w.issue(1,'a'*64); self.w.db.execute('DELETE FROM events')
        with self.assertRaises(Rejected): self.w.issue(1,'b'*64)
    def test_uncommitted_intent_rolls_back(self):
        def fail(stage):
            if stage=='intent_before_commit': raise RuntimeError('fault')
        with self.assertRaises(RuntimeError): self.w.rotate(fail)
        self.assertEqual(self.state()['epoch'],1)
        self.assertEqual(self.w.db.execute('SELECT count(*) FROM pending').fetchone()[0],0)
    def test_pending_blocks_history_until_recovered(self):
        def fail(stage):
            if stage=='intent_after_commit': raise RuntimeError('fault')
        with self.assertRaises(RuntimeError): self.w.rotate(fail)
        with self.assertRaises(Rejected): self.w.history()
        self.w.recover(); self.assertEqual(self.state()['epoch'],2)
    def test_custodian_retry_idempotent(self):
        def fail(stage):
            if stage=='custody_after_commit': raise RuntimeError('fault')
        with self.assertRaises(RuntimeError): self.w.rotate(fail)
        self.w.recover(); self.w.recover()
        self.assertEqual(self.state()['epoch'],2)
        self.assertEqual(len(self.c.snapshot()[0]),1)
    def test_tampered_pending_rejected(self):
        self.w.db.execute("INSERT INTO pending VALUES(1,'{}')")
        with self.assertRaises(Rejected): self.w.recover()
    def test_crash_matrix_subprocess(self):
        points=['intent_before_commit','intent_after_commit','custody_before_commit','custody_after_commit','witness_before_commit','witness_after_commit']
        for kind in ['rotate','issue']:
            for point in points:
                with self.subTest(kind=kind,point=point):
                    cp=self.path/(kind+point+'c'); wp=self.path/(kind+point+'w')
                    c,root=CustodianFixture.create(cp); w=Witness.create(wp,c,root)
                    w.issue(1,'a'*64); w.close(); c.close()
                    run=subprocess.run([sys.executable,str(pathlib.Path(__file__).with_name('crash_worker.py')),str(cp),str(wp),root,kind,point],capture_output=True,text=True,timeout=15)
                    self.assertEqual(run.returncode,73,run.stderr)
                    c=CustodianFixture(cp,root); w=Witness(wp,c,root)
                    try:
                        state=w.recover(); h=w.history()
                        expected=1 if point=='intent_before_commit' else 2
                        self.assertEqual(state['epoch'] if kind=='rotate' else state['seq'],expected)
                        self.assertEqual(state,verify_history(h,root))
                        self.assertEqual(len(c.snapshot()[0]),len(h))
                        self.assertEqual(w.db.execute('SELECT count(*) FROM pending').fetchone()[0],0)
                        w.issue(3,'c'*64)
                    finally: w.close(); c.close()

if __name__ == '__main__': unittest.main(verbosity=2)
