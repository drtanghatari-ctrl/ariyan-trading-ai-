import os, sys
from rotation import CustodianFixture, Witness
custody, witness, root, kind, point = sys.argv[1:]
c = CustodianFixture(custody, root)
w = Witness(witness, c, root)
def hook(stage):
    if stage == point:
        os._exit(73)
if kind == 'rotate':
    w.rotate(hook)
else:
    w.issue(2, 'b'*64, hook)
w.close(); c.close()
