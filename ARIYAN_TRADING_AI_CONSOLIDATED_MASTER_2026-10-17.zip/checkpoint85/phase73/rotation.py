"""Offline reference protocol. No financial actions or production authority.
CustodianFixture stores UNENCRYPTED disposable test keys in a separate database.
Replace it with an independently controlled atomic, durable custody service.
"""
import hashlib
import json
import sqlite3
import uuid
from contextlib import contextmanager
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey
from cryptography.hazmat.primitives import serialization

ZERO = '0' * 64
DOMAIN = 'ARIYAN-OFFLINE-WITNESS-v1'

class Rejected(ValueError):
    pass

def canonical(obj):
    return json.dumps(obj, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode('ascii')

def digest(obj):
    return hashlib.sha256(canonical(obj)).hexdigest()

def raw_public(key):
    return key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw).hex()

def hexfield(value, length):
    if type(value) is not str or len(value) != length or any(c not in '0123456789abcdef' for c in value):
        raise Rejected('noncanonical hexadecimal field')

def integer(value, minimum=0):
    if type(value) is not int or not minimum <= value <= 2**63 - 1:
        raise Rejected('invalid integer')

def validate_request(req):
    if type(req) is not dict or set(req) != {'domain', 'op', 'index', 'previous', 'kind', 'seq', 'digest'}:
        raise Rejected('invalid request schema')
    if req['domain'] != DOMAIN or req['kind'] not in ('issue', 'rotate'):
        raise Rejected('invalid domain or kind')
    hexfield(req['op'], 32); hexfield(req['previous'], 64); hexfield(req['digest'], 64)
    integer(req['index'], 1); integer(req['seq'])

def connect(path):
    db = sqlite3.connect(str(path), isolation_level=None, timeout=10)
    db.execute('PRAGMA journal_mode=WAL')
    db.execute('PRAGMA synchronous=FULL')
    return db

@contextmanager
def transaction(db):
    db.execute('BEGIN IMMEDIATE')
    try:
        yield
        db.execute('COMMIT')
    except BaseException:
        if db.in_transaction:
            db.execute('ROLLBACK')
        raise

def load_events(db):
    rows = db.execute('SELECT n,receipt FROM events ORDER BY n').fetchall()
    if [r[0] for r in rows] != list(range(1, len(rows) + 1)):
        raise Rejected('event index gap')
    return [json.loads(r[1]) for r in rows]

def verify_history(events, root, floor=None):
    """Verify all transitions from caller-pinned root; never discover trust from DB.
    floor=(index, receipt_sha256) must come from a trusted independent owner.
    """
    hexfield(root, 64)
    key = root; epoch = 1; seq = 0; state_digest = ZERO; previous = ZERO
    seen = set(); hashes = {0: ZERO}
    for index, receipt in enumerate(events, 1):
        if type(receipt) is not dict or set(receipt) != {'body', 'signature', 'possession'}:
            raise Rejected('invalid receipt schema')
        body = receipt['body']
        if type(body) is not dict or set(body) != {'request', 'epoch', 'next_public'}:
            raise Rejected('invalid body schema')
        req = body['request']; validate_request(req); integer(body['epoch'], 1)
        if req['index'] != index or req['previous'] != previous or body['epoch'] != epoch or req['op'] in seen:
            raise Rejected('history continuity')
        seen.add(req['op']); hexfield(receipt['signature'], 128)
        Ed25519PublicKey.from_public_bytes(bytes.fromhex(key)).verify(bytes.fromhex(receipt['signature']), canonical(body))
        if req['kind'] == 'issue':
            if req['seq'] <= seq or body['next_public'] != '' or receipt['possession'] != '':
                raise Rejected('invalid issue transition')
            seq, state_digest = req['seq'], req['digest']
        else:
            if (req['seq'], req['digest']) != (seq, state_digest):
                raise Rejected('rotation changed checkpoint')
            next_key = body['next_public']; hexfield(next_key, 64); hexfield(receipt['possession'], 128)
            if next_key == key:
                raise Rejected('rotation did not replace key')
            Ed25519PublicKey.from_public_bytes(bytes.fromhex(next_key)).verify(bytes.fromhex(receipt['possession']), canonical(body))
            key = next_key; epoch += 1
        previous = digest(receipt); hashes[index] = previous
    if floor is not None:
        if type(floor) is not tuple or len(floor) != 2:
            raise Rejected('invalid trusted floor')
        integer(floor[0]); hexfield(floor[1], 64)
        if hashes.get(floor[0]) != floor[1]:
            raise Rejected('rollback below trusted floor or divergent history')
    return {'index': len(events), 'head': previous, 'epoch': epoch, 'public': key, 'seq': seq, 'digest': state_digest}

class CustodianFixture:
    """Test double, NOT secure custody. Keys are never returned by its API.
    apply() must be atomic and idempotent in the eventual external implementation.
    """
    @classmethod
    def create(cls, path):
        # Exclusive creation prevents accidental replacement of an existing identity.
        with open(path, 'xb'):
            pass
        db = connect(path)
        try:
            db.executescript('CREATE TABLE keys(epoch INTEGER PRIMARY KEY,secret BLOB NOT NULL); CREATE TABLE events(n INTEGER PRIMARY KEY,op TEXT UNIQUE NOT NULL,receipt TEXT NOT NULL);')
            key = Ed25519PrivateKey.generate()
            raw = key.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw, serialization.NoEncryption())
            db.execute('INSERT INTO keys VALUES(1,?)', (raw,))
            root = raw_public(key)
        finally:
            db.close()
        return cls(path, root), root

    def __init__(self, path, root):
        if not __import__('pathlib').Path(path).is_file():
            raise Rejected('custodian missing; no automatic identity reset')
        self.root = root; self.db = connect(path)
        try:
            self.snapshot()
        except BaseException:
            self.close(); raise

    def _snapshot(self):
        events = load_events(self.db); state = verify_history(events, self.root)
        row = self.db.execute('SELECT secret FROM keys WHERE epoch=?', (state['epoch'],)).fetchone()
        if row is None or raw_public(Ed25519PrivateKey.from_private_bytes(row[0])) != state['public']:
            raise Rejected('custodian key does not match pinned signed history')
        return events, state

    def snapshot(self):
        with transaction(self.db):
            return self._snapshot()

    def apply(self, req, hook=lambda _: None):
        validate_request(req)
        with transaction(self.db):
            events, state = self._snapshot()
            for receipt in events:
                if receipt['body']['request']['op'] == req['op']:
                    if receipt['body']['request'] != req:
                        raise Rejected('operation ID reused for different request')
                    return receipt
            if (req['index'], req['previous']) != (state['index'] + 1, state['head']):
                raise Rejected('stale custody CAS')
            if req['kind'] == 'issue' and req['seq'] <= state['seq']:
                raise Rejected('rollback or duplicate sequence')
            if req['kind'] == 'rotate' and (req['seq'], req['digest']) != (state['seq'], state['digest']):
                raise Rejected('rotation checkpoint mismatch')
            current = Ed25519PrivateKey.from_private_bytes(self.db.execute('SELECT secret FROM keys WHERE epoch=?', (state['epoch'],)).fetchone()[0])
            new_key = Ed25519PrivateKey.generate() if req['kind'] == 'rotate' else None
            body = {'request': req, 'epoch': state['epoch'], 'next_public': raw_public(new_key) if new_key else ''}
            receipt = {'body': body, 'signature': current.sign(canonical(body)).hex(), 'possession': new_key.sign(canonical(body)).hex() if new_key else ''}
            verify_history(events + [receipt], self.root)
            if new_key:
                raw = new_key.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw, serialization.NoEncryption())
                self.db.execute('INSERT INTO keys VALUES(?,?)', (state['epoch'] + 1, raw))
            self.db.execute('INSERT INTO events VALUES(?,?,?)', (req['index'], req['op'], canonical(receipt).decode()))
            hook('custody_before_commit')
        hook('custody_after_commit')
        return receipt

    def close(self):
        self.db.close()

class Witness:
    @classmethod
    def create(cls, path, custodian, root):
        events, state = custodian.snapshot()
        verify_history(events, root)
        if events:
            raise Rejected('bootstrap requires empty custodian; restore requires explicit recovery')
        with open(path, 'xb'):
            pass
        db = connect(path)
        try:
            db.executescript('CREATE TABLE identity(root TEXT NOT NULL); CREATE TABLE events(n INTEGER PRIMARY KEY,receipt TEXT NOT NULL); CREATE TABLE pending(id INTEGER PRIMARY KEY CHECK(id=1),request TEXT NOT NULL);')
            db.execute('INSERT INTO identity VALUES(?)', (root,))
        finally:
            db.close()
        return cls(path, custodian, root)

    def __init__(self, path, custodian, root, floor=None):
        if not __import__('pathlib').Path(path).is_file():
            raise Rejected('witness missing; explicit bootstrap required')
        self.db = connect(path); self.custodian = custodian; self.root = root; self.floor = floor
        try:
            with transaction(self.db):
                self._validate_local()
                if not self.db.execute('SELECT 1 FROM pending').fetchone():
                    self._aligned()
        except BaseException:
            self.close(); raise

    def _validate_local(self):
        if self.db.execute('SELECT root FROM identity').fetchall() != [(self.root,)]:
            raise Rejected('root pin mismatch')
        events = load_events(self.db)
        return events, verify_history(events, self.root, self.floor)

    def _aligned(self):
        events, state = self._validate_local()
        remote_events, remote = self.custodian.snapshot()
        verify_history(remote_events, self.root, self.floor)
        if state != remote:
            raise Rejected('unexplained witness/custodian divergence')
        return events, state

    def _recover_locked(self, hook):
        events, state = self._validate_local()
        row = self.db.execute('SELECT request FROM pending WHERE id=1').fetchone()
        if row is None:
            return self._aligned()[1]
        req = json.loads(row[0]); validate_request(req)
        if (req['index'], req['previous']) != (state['index'] + 1, state['head']):
            raise Rejected('pending journal continuity')
        receipt = self.custodian.apply(req, hook)
        if receipt['body']['request'] != req:
            raise Rejected('custodian receipt does not match journal')
        new_state = verify_history(events + [receipt], self.root, self.floor)
        _, remote = self.custodian.snapshot()
        if new_state != remote:
            raise Rejected('custodian diverged during recovery')
        self.db.execute('INSERT INTO events VALUES(?,?)', (req['index'], canonical(receipt).decode()))
        self.db.execute('DELETE FROM pending WHERE id=1')
        hook('witness_before_commit')
        return new_state

    def recover(self, hook=lambda _: None):
        with transaction(self.db):
            state = self._recover_locked(hook)
        hook('witness_after_commit')
        return state

    def _operate(self, kind, seq=None, state_digest=None, hook=lambda _: None):
        # Pending intent is committed before any call that can change custodian state.
        with transaction(self.db):
            self._recover_locked(hook)
            events, state = self._aligned()
            if kind == 'issue':
                integer(seq, 1); hexfield(state_digest, 64)
                if seq < state['seq'] or (seq == state['seq'] and state_digest != state['digest']):
                    raise Rejected('rollback/equivocation')
                if seq == state['seq']:
                    return next(r for r in reversed(events) if r['body']['request']['kind'] == 'issue')
            else:
                seq, state_digest = state['seq'], state['digest']
            req = {'domain': DOMAIN, 'op': uuid.uuid4().hex, 'index': state['index'] + 1, 'previous': state['head'], 'kind': kind, 'seq': seq, 'digest': state_digest}
            self.db.execute('INSERT INTO pending VALUES(1,?)', (canonical(req).decode(),))
            hook('intent_before_commit')
        hook('intent_after_commit')
        # Separate transaction permits restart and serializes simultaneous recovery.
        self.recover(hook)
        with transaction(self.db):
            for receipt in load_events(self.db):
                if receipt['body']['request']['op'] == req['op']:
                    return receipt
        raise Rejected('operation receipt missing')

    def issue(self, seq, state_digest, hook=lambda _: None):
        return self._operate('issue', seq, state_digest, hook)

    def rotate(self, hook=lambda _: None):
        return self._operate('rotate', hook=hook)

    def history(self):
        with transaction(self.db):
            events, _ = self._aligned()
            if self.db.execute('SELECT 1 FROM pending').fetchone():
                raise Rejected('recovery pending')
            return events

    def close(self):
        self.db.close()
