"""Bounded local reference adapters and byte gateway; no network/deployment.
Exhausted limits fail closed. No automatic pruning, key deletion or authority reset.
"""
import json,pathlib
from dataclasses import dataclass
from rotation import CustodianFixture,Witness,Rejected,integer,canonical
from checkpoint import exact
from control_plane import GovernedAuthority

@dataclass(frozen=True)
class Limits:
    events:int=1000
    governance:int=256
    authority_commits:int=256
    record_bytes:int=8*1024*1024
    table_bytes:int=32*1024*1024
    database_bytes:int=64*1024*1024
    request_bytes:int=1024*1024
    def __post_init__(self):
        for value in self.__dict__.values():integer(value,1)

DEFAULT=Limits()
TABLES={'events':('receipt',),'keys':('secret',),'pending':('request',),'identity':('root',),
        'commits':('envelope','history','receipt'),'governance_events':('envelope',),'governance_ack':('receipt',),'governance_identity':('policy',)}

def file_guard(path,limits):
    p=pathlib.Path(path)
    for name in (p,pathlib.Path(str(p)+'-wal'),pathlib.Path(str(p)+'-shm')):
        if name.exists() and (not name.is_file() or name.stat().st_size>limits.database_bytes):raise Rejected('database file quota')

def table_guard(db,table,columns,rows,limits):
    # Identifiers come only from hard-coded internal schema constants.
    if table not in TABLES or tuple(columns)!=TABLES[table]:raise Rejected('unsupported quota target')
    expr='+'.join('length(CAST('+name+' AS BLOB))' for name in columns)
    n,total,largest=db.execute('SELECT count(*),coalesce(sum('+expr+'),0),coalesce(max('+expr+'),0) FROM '+table).fetchone()
    if n>rows or total>limits.table_bytes or largest>limits.record_bytes:raise Rejected('stored evidence quota')
    return n

class BoundedCustodian(CustodianFixture):
    def __init__(self,path,root,limits=DEFAULT):self.limits=limits;self.path=path;file_guard(path,limits);super().__init__(path,root)
    def _guard(self):
        file_guard(self.path,self.limits)
        table_guard(self.db,'events',('receipt',),self.limits.events,self.limits)
        table_guard(self.db,'keys',('secret',),self.limits.events+1,self.limits)
    def _snapshot(self):self._guard();return super()._snapshot()
    def apply(self,req,hook=lambda _:None):
        def bounded_hook(stage):
            if stage=='custody_before_commit':self._guard()
            hook(stage)
        return super().apply(req,bounded_hook)

class BoundedWitness(Witness):
    def __init__(self,path,custodian,root,floor=None,limits=DEFAULT):
        self.limits=limits;self.path=path;file_guard(path,limits);super().__init__(path,custodian,root,floor)
    def _guard(self):
        file_guard(self.path,self.limits)
        n=table_guard(self.db,'events',('receipt',),self.limits.events,self.limits)
        pending=table_guard(self.db,'pending',('request',),1,self.limits)
        table_guard(self.db,'identity',('root',),1,self.limits)
        if n+pending>self.limits.events:raise Rejected('witness event capacity exhausted')
    def _validate_local(self):self._guard();return super()._validate_local()
    def _operate(self,kind,seq=None,state_digest=None,hook=lambda _:None):
        def bounded_hook(stage):
            if stage in ('intent_before_commit','witness_before_commit'):self._guard()
            hook(stage)
        return super()._operate(kind,seq,state_digest,bounded_hook)

class BoundedAuthority(GovernedAuthority):
    def __init__(self,path,config,signer,policy,limits=DEFAULT):
        self.limits=limits;self.path=path;file_guard(path,limits);super().__init__(path,config,signer,policy)
    def _guard(self):
        file_guard(self.path,self.limits)
        table_guard(self.db,'commits',('envelope','history','receipt'),self.limits.authority_commits,self.limits)
        table_guard(self.db,'governance_events',('envelope',),self.limits.governance,self.limits)
        table_guard(self.db,'governance_ack',('receipt',),self.limits.governance,self.limits)
        table_guard(self.db,'governance_identity',('policy',),1,self.limits)
        # authority identity uses config rather than witness root; validate separately.
        n,size=self.db.execute('SELECT count(*),coalesce(sum(length(CAST(config AS BLOB))),0) FROM identity').fetchone()
        if n!=1 or size>self.limits.record_bytes:raise Rejected('authority identity quota')
    def _read(self):self._guard();return super()._read()
    def submit(self,envelope,history,hook=lambda _:None):
        def bounded_hook(stage):
            if stage=='authority_before_commit':self._guard()
            hook(stage)
        return super().submit(envelope,history,bounded_hook)
    def govern(self,envelope,now,hook=lambda _:None):
        def bounded_hook(stage):
            if stage=='governance_before_commit':self._guard()
            hook(stage)
        return super().govern(envelope,now,bounded_hook)

def unique_pairs(pairs):
    result={}
    for key,value in pairs:
        if key in result:raise Rejected('duplicate JSON key')
        result[key]=value
    return result

def nonfinite(_):raise Rejected('nonfinite number')

class Gateway:
    """In-process byte boundary only. Service owns the clock; requests cannot set it."""
    def __init__(self,service,clock,limits=DEFAULT):
        if not isinstance(service,BoundedAuthority):raise Rejected('gateway requires bounded service')
        self.service=service;self.clock=clock;self.limits=limits
    def handle(self,raw):
        try:
            if type(raw) is not bytes or not 0<len(raw)<=self.limits.request_bytes:raise Rejected('request size/type')
            request=json.loads(raw.decode('utf-8'),object_pairs_hook=unique_pairs,parse_constant=nonfinite)
            exact(request,('operation','payload'));payload=request['payload'];op=request['operation']
            if op=='submit':
                exact(payload,('envelope','history'));result=self.service.submit(payload['envelope'],payload['history'])
            elif op=='govern':
                exact(payload,('envelope',));result=self.service.govern(payload['envelope'],self.clock())
            elif op=='query':
                exact(payload,('challenge',));result=self.service.query_control(payload['challenge'])
            else:raise Rejected('unsupported operation')
            return {'ok':True,'result':result,'financial_authority':False}
        except Exception as exc:
            return {'ok':False,'error_type':type(exc).__name__,'financial_authority':False}
