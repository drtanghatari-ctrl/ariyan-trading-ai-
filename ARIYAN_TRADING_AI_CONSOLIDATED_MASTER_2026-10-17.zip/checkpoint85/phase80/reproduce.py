"""Portable all-suite runner. Output belongs outside the immutable checkpoint."""
import argparse,json,os,pathlib,re,subprocess,sys
p=argparse.ArgumentParser();p.add_argument('output');p.add_argument('--first-phase',type=int,default=66);p.add_argument('--last-phase',type=int,default=80);args=p.parse_args()
root=pathlib.Path(__file__).resolve().parents[1];out=pathlib.Path(args.output).resolve();out.mkdir(parents=True,exist_ok=True)
results=[]
for phase in range(args.first_phase,args.last_phase+1):
 folder=root/'inherited/phase70/REFERENCE_TESTS'/f'ariyan_phase{phase}' if phase<70 else root/'inherited/phase70/phase70' if phase==70 else root/'inherited'/f'phase{phase}' if phase<73 else root/f'phase{phase}'
 if not folder.is_dir():raise SystemExit('Required suite missing: '+str(folder))
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
 paths=[str(root/f'phase{n}') for n in range(73,args.last_phase+1)]
 if phase==70:paths += [str(root/'inherited/phase70/REFERENCE_TESTS'/f'ariyan_phase{n}') for n in (68,69)]
 env['PYTHONPATH']=os.pathsep.join(paths)
 cmd=[sys.executable,'-B','-m','unittest','discover','-v']
 r=subprocess.run(cmd,cwd=folder,env=env,capture_output=True,text=True,timeout=90)
 log=r.stdout+r.stderr;(out/f'phase{phase}.txt').write_text(log)
 count=re.search(r'Ran (\d+) tests?',log)
 results.append({'phase':phase,'returncode':r.returncode,'methods':int(count[1]) if count else None,'command':cmd,'cwd':str(folder.relative_to(root))})
(out/'summary.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(results,indent=2))
if any(r['returncode']!=0 or not r['methods'] for r in results):raise SystemExit(1)
