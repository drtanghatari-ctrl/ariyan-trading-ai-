import dataclasses,json,pathlib,tempfile,unittest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from rotation import CustodianFixture,Witness,raw_public,Rejected,canonical,ZERO
from checkpoint import make_request
from governance import proposal,approve
from bounded_service import Limits,BoundedAuthority,BoundedCustodian,BoundedWitness,Gateway

class BoundedTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.p=pathlib.Path(self.tmp.name)
        self.c,self.root=BoundedCustodian.create(self.p/'c');self.w=BoundedWitness.create(self.p/'w',self.c,self.root)
        self.client=Ed25519PrivateKey.generate();self.signer=Ed25519PrivateKey.generate();self.keys={n:Ed25519PrivateKey.generate() for n in ('one','two','three')}
        self.config={'tenant':'ariyan','witness':'w1','custody_root':self.root,'client_public':raw_public(self.client),'authority_public':raw_public(self.signer)}
        self.policy={'tenant':'ariyan','witness':'w1','approvers':{n:raw_public(k) for n,k in self.keys.items()},'quorum':2}
        self.a=BoundedAuthority.create_service(self.p/'a',self.config,self.signer,self.policy);self.gateway=Gateway(self.a,lambda:100)
    def tearDown(self):self.a.close();self.w.close();self.c.close();self.tmp.cleanup()
    def request(self):
        h=self.w.history();g=self.a.query_control('a'*64)['body']['governance'];e=make_request(self.client,self.config,self.a.snapshot()['generation'],g['epoch'],h)
        return {'operation':'submit','payload':{'envelope':e,'history':h}}
    def gov(self):
        g=self.a.query_control('a'*64)['body']['governance'];return approve(proposal(self.policy,g,'freeze',{'reason_hash':'a'*64},100,200),self.keys)
    def test_valid_byte_submission(self):
        self.w.issue(1,'a'*64);result=self.gateway.handle(canonical(self.request()));self.assertTrue(result['ok']);self.assertFalse(result['financial_authority'])
    def test_valid_byte_query(self):
        r=self.gateway.handle(canonical({'operation':'query','payload':{'challenge':'a'*64}}));self.assertTrue(r['ok']);self.assertFalse(r['financial_authority'])
    def test_duplicate_json_keys(self):
        raw=b'{"operation":"submit","operation":"query","payload":{"challenge":"'+b'a'*64+b'"}}'
        self.assertFalse(self.gateway.handle(raw)['ok'])
    def test_nonfinite_numbers(self):self.assertFalse(self.gateway.handle(b'{"operation":NaN,"payload":{}}')['ok'])
    def test_invalid_utf8(self):self.assertFalse(self.gateway.handle(b'\xff')['ok'])
    def test_request_type_matrix(self):
        for raw in (None,{},'{}',b'',b'null',b'[]',b'{'):
            with self.subTest(raw=raw):self.assertFalse(self.gateway.handle(raw)['ok'])
    def test_request_size_limit(self):
        gw=Gateway(self.a,lambda:100,Limits(request_bytes=10));self.assertFalse(gw.handle(b' '*11)['ok'])
    def test_unknown_operation(self):self.assertFalse(self.gateway.handle(canonical({'operation':'trade','payload':{}}))['ok'])
    def test_caller_cannot_set_clock(self):
        r=self.gateway.handle(canonical({'operation':'govern','payload':{'envelope':self.gov(),'now':100}}));self.assertFalse(r['ok'])
    def test_service_clock_is_used(self):
        gw=Gateway(self.a,lambda:300);r=gw.handle(canonical({'operation':'govern','payload':{'envelope':self.gov()}}));self.assertFalse(r['ok'])
        self.assertEqual(self.a.query_control('a'*64)['body']['governance']['epoch'],1)
    def test_nested_input_fails_closed(self):
        raw=b'['*1200+b'0'+b']'*1200;self.assertFalse(self.gateway.handle(raw)['ok'])
    def test_bad_boolean_governance_epoch(self):
        self.w.issue(1,'a'*64);r=self.request();r['payload']['envelope']['body']['governance_epoch']=True
        self.assertFalse(self.gateway.handle(canonical(r))['ok']);self.assertEqual(self.a.snapshot()['generation'],0)
    def test_atomic_authority_capacity(self):
        self.a.limits=Limits(authority_commits=1)
        self.w.issue(1,'a'*64);first=self.request();self.assertTrue(self.gateway.handle(canonical(first))['ok'])
        self.w.rotate();second=self.request();self.assertFalse(self.gateway.handle(canonical(second))['ok'])
        self.assertEqual(self.a.snapshot()['generation'],1)
        self.assertTrue(self.gateway.handle(canonical(first))['ok'])
    def test_atomic_governance_capacity(self):
        self.a.limits=Limits(governance=1);self.a.govern(self.gov(),100)
        g=self.a.query_control('a'*64)['body']['governance'];e=approve(proposal(self.policy,g,'freeze',{'reason_hash':'b'*64},100,200),self.keys)
        with self.assertRaises(Rejected):self.a.govern(e,100)
        self.assertEqual(self.a.query_control('a'*64)['body']['governance']['epoch'],2)
        self.assertEqual(self.a.db.execute('SELECT count(*) FROM governance_ack').fetchone()[0],1)
    def test_custody_quota_rolls_back_key_and_event(self):
        self.c.limits=Limits(events=1);self.w.issue(1,'a'*64)
        with self.assertRaises(Rejected):self.w.rotate()
        self.assertEqual(self.c.snapshot()[1]['epoch'],1)
        self.assertEqual(self.c.db.execute('SELECT count(*) FROM keys').fetchone()[0],1)
        self.assertEqual(self.w.db.execute('SELECT count(*) FROM pending').fetchone()[0],1)
        # Explicit local fixture reconfiguration permits recovery, never automatic deletion.
        self.c.limits=Limits(events=2);self.w.recover();self.assertEqual(self.c.snapshot()[1]['epoch'],2)
    def test_witness_quota_blocks_intent_before_external_effect(self):
        self.w.limits=Limits(events=1);self.w.issue(1,'a'*64)
        with self.assertRaises(Rejected):self.w.rotate()
        self.assertEqual(self.w.db.execute('SELECT count(*) FROM pending').fetchone()[0],0)
        self.assertEqual(self.c.snapshot()[1]['epoch'],1)
    def test_record_size_before_loading(self):
        self.a.limits=Limits(record_bytes=20)
        with self.assertRaises(Rejected):self.a.snapshot()
    def test_database_file_size_before_loading(self):
        with self.assertRaises(Rejected):BoundedAuthority(self.p/'a',self.config,self.signer,self.policy,Limits(database_bytes=1))
    def test_invalid_quota_values(self):
        for kwargs in ({'events':0},{'events':True},{'request_bytes':-1}):
            with self.subTest(kwargs=kwargs):
                with self.assertRaises(Rejected):Limits(**kwargs)
    def test_gateway_always_denies_financial_authority(self):
        for raw in (b'{}',canonical({'operation':'query','payload':{'challenge':'a'*64}})):
            self.assertFalse(self.gateway.handle(raw)['financial_authority'])
    def test_oversized_witness_row_before_json_decode(self):
        self.w.db.execute('INSERT INTO events VALUES(1,?)',('x'*100,));self.w.limits=Limits(record_bytes=20)
        with self.assertRaises(Rejected):self.w.history()
    def test_reopen_same_limits(self):
        self.w.issue(1,'a'*64);r=self.request();self.a.submit(r['payload']['envelope'],r['payload']['history']);old=self.a.snapshot()
        self.a.close();self.a=BoundedAuthority(self.p/'a',self.config,self.signer,self.policy);self.assertEqual(old,self.a.snapshot())
    def test_unknown_payload_fields_rejected(self):
        raw=canonical({'operation':'query','payload':{'challenge':'a'*64,'allow_live':True}})
        self.assertFalse(self.gateway.handle(raw)['ok'])

if __name__=='__main__':unittest.main(verbosity=2)
