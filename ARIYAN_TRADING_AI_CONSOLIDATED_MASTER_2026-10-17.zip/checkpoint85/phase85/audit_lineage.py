"""Recover historical audit bytes and append measurable corrections, not semantic approval."""
import hashlib,json,pathlib,re,stat,zipfile
from source_audit import scan_source
MAX_TEXT=2*1024*1024

def sha(raw):return hashlib.sha256(raw).hexdigest()

def read_report(path,expected_sha256,phase):
    if type(phase) is not int or not 1<=phase<=6:raise ValueError('historical audit phase out of scope')
    p=pathlib.Path(path)
    if p.stat().st_size>MAX_TEXT:raise ValueError('audit archive quota')
    raw=p.read_bytes()
    if sha(raw)!=expected_sha256:raise ValueError('historical audit ZIP fingerprint mismatch')
    expected_name=f'ARIYAN_TRADING_AI_MASTER_AUDIT_PHASE_{phase}.txt'
    with zipfile.ZipFile(p) as z:
        infos=z.infolist()
        if len(infos)!=1 or infos[0].filename!=expected_name or infos[0].file_size>MAX_TEXT or infos[0].flag_bits&1 or stat.S_ISLNK(infos[0].external_attr>>16):raise ValueError('unexpected audit archive member')
        if infos[0].compress_type not in (zipfile.ZIP_STORED,zipfile.ZIP_DEFLATED):raise ValueError('unsupported audit compression')
        text_raw=z.read(infos[0])
    text=text_raw.decode('utf-8')
    return {'phase':phase,'archive_name':p.name,'archive_sha256':sha(raw),'archive_bytes':len(raw),'report_name':expected_name,'report_sha256':sha(text_raw),'report_bytes':len(text_raw),'report_lines':len(text.splitlines()),'raw':text_raw,'text':text}

def write_preserving(path,raw):
    p=pathlib.Path(path);p.parent.mkdir(parents=True,exist_ok=True)
    if p.exists():
        if p.read_bytes()!=raw:raise ValueError('refuse to overwrite differing historical bytes')
    else:p.write_bytes(raw)

def current_range_finding(source_raw,expected_sha256,phase1_text):
    parsed=scan_source(source_raw,10,expected_sha256)
    occurrences=[r for r in parsed['singles'] if 6601<=r['number']<=6700]
    found={r['number'] for r in occurrences};missing=sorted(set(range(6601,6701))-found)
    return {'source_id':10,'source_sha256':expected_sha256,'fingerprint_cited_in_recovered_phase1':expected_sha256 in phase1_text,
            'range_start':6601,'range_end':6700,'explicit_heading_count':len(found),'missing_explicit_headings':missing,
            'heading_locations':occurrences,'current_missing_range_claim_supported':bool(missing),
            'disposition':'OLD_MISSING_RANGE_CLAIM_NOT_APPLICABLE_TO_VERIFIED_CURRENT_BYTES' if not missing else 'SOURCE_GAP_REMAINS',
            'semantic_completeness_certified':False,'historical_issuance_timeline_authenticated':False}

def ingest(directory,expectations,source_raw,source_sha256,baseline_hashes,output):
    out=pathlib.Path(output);out.mkdir(parents=True,exist_ok=True);records=[];hash_mentions=[]
    for phase,item in sorted(expectations.items(),key=lambda pair:int(pair[0])):
        p=pathlib.Path(directory)/item['filename'];r=read_report(p,item['sha256'],int(phase))
        write_preserving(out/'originals'/p.name,p.read_bytes());write_preserving(out/'reports'/r['report_name'],r['raw'])
        for line_no,line in enumerate(r['text'].splitlines(),1):
            for value in re.findall(r'\b[0-9a-f]{64}\b',line):
                hash_mentions.append({'audit_phase':int(phase),'line':line_no,'hash':value,'line_text':line,'classification':'ORIGINAL_SOURCE_FINGERPRINT_MATCH' if value in baseline_hashes else 'HASH_SCOPE_UNSPECIFIED_REQUIRES_CONTEXT','accepted_as_new_source_authority':False})
        records.append({k:v for k,v in r.items() if k not in ('raw','text')})
    phase1=next((out/'reports').glob('*_1.txt')).read_text()
    finding=current_range_finding(source_raw,source_sha256,phase1)
    summary={'historical_audit_archives_recovered':len(records),'new_semantic_approvals':0,'production_certification':False,'original_architectural_source_count':27,
             'matching_original_source_hash_mentions':sum(r['classification']=='ORIGINAL_SOURCE_FINGERPRINT_MATCH' for r in hash_mentions),'unspecified_hash_mentions':sum(r['classification']!='ORIGINAL_SOURCE_FINGERPRINT_MATCH' for r in hash_mentions),'range6601_6700_explicit_headings':finding['explicit_heading_count']}
    for name,obj in [('RECOVERED_AUDITS.json',records),('HASH_MENTIONS.json',hash_mentions),('RANGE_6601_6700_CORRECTION.json',finding),('SUMMARY.json',summary)]:
        (out/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
    return summary

if __name__=='__main__':
    import sys
    root=pathlib.Path(sys.argv[2]);expectations=json.loads(pathlib.Path(sys.argv[3]).read_text());rows=json.loads((root/'evidence/source_index.json').read_text())
    baseline={r['sha256'] for r in rows};source=(root/'historical_sources/10.txt').read_bytes();expected=next(r['sha256'] for r in rows if r['id']==10)
    print(json.dumps(ingest(sys.argv[1],expectations,source,expected,baseline,sys.argv[4]),indent=2))
