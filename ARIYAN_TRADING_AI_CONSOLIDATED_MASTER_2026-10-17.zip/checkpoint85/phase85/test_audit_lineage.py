import hashlib,pathlib,stat,tempfile,unittest,zipfile
from audit_lineage import read_report,write_preserving,current_range_finding

class AuditLineageTests(unittest.TestCase):
    def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.p=pathlib.Path(self.tmp.name)
    def tearDown(self):self.tmp.cleanup()
    def bundle(self,name='ARIYAN_TRADING_AI_MASTER_AUDIT_PHASE_1.txt',raw=b'Historical status: NOT VERIFIED\r\n',extra=False):
        path=self.p/'audit.zip'
        with zipfile.ZipFile(path,'w') as z:
            z.writestr(name,raw)
            if extra:z.writestr('extra.txt','unexpected')
        return path,hashlib.sha256(path.read_bytes()).hexdigest()
    def test_original_text_bytes_preserved(self):
        r=read_report(*self.bundle(),1);self.assertEqual(r['raw'],b'Historical status: NOT VERIFIED\r\n')
    def test_wrong_fingerprint_rejected(self):
        path,_=self.bundle()
        with self.assertRaises(ValueError):read_report(path,'0'*64,1)
    def test_unexpected_filename_rejected(self):
        with self.assertRaises(ValueError):read_report(*self.bundle('../outside.txt'),1)
    def test_extra_members_rejected(self):
        with self.assertRaises(ValueError):read_report(*self.bundle(extra=True),1)
    def test_bool_phase_rejected(self):
        with self.assertRaises(ValueError):read_report(*self.bundle(),True)
    def test_idempotent_preserving_write(self):
        path=self.p/'history.txt';write_preserving(path,b'original');write_preserving(path,b'original')
        with self.assertRaises(ValueError):write_preserving(path,b'changed')
        self.assertEqual(path.read_bytes(),b'original')
    def test_markdown_range_correction_is_measured_not_semantic(self):
        raw=''.join(f'### Section {n} — Rule\n' for n in range(6601,6701)).encode();sha=hashlib.sha256(raw).hexdigest();r=current_range_finding(raw,sha,'Source SHA256 '+sha)
        self.assertEqual(r['explicit_heading_count'],100);self.assertFalse(r['current_missing_range_claim_supported']);self.assertFalse(r['semantic_completeness_certified']);self.assertTrue(r['fingerprint_cited_in_recovered_phase1'])
    def test_partial_range_not_claimed_complete(self):
        raw=b'### Section 6601 - Rule\n';r=current_range_finding(raw,hashlib.sha256(raw).hexdigest(),'')
        self.assertEqual(len(r['missing_explicit_headings']),99);self.assertTrue(r['current_missing_range_claim_supported'])
    def test_source_hash_mismatch_blocks_correction(self):
        with self.assertRaises(ValueError):current_range_finding(b'changed','0'*64,'')

if __name__=='__main__':unittest.main(verbosity=2)
