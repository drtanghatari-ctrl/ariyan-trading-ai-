"""Bounded, non-executing source intake. Never imports or extracts candidate code.
A self-declared project manifest is a claim, not verified ownership or integration.
"""
import ast,hashlib,json,pathlib,stat,zipfile
from archive_integrity import safe_name
MAX_ENTRIES=2048
MAX_ARCHIVE=64*1024*1024
MAX_TOTAL=64*1024*1024
MAX_FILE=8*1024*1024
MANIFEST='APP_SOURCE_MANIFEST.json'
NETWORK={'requests','httpx','socket','urllib','aiohttp','websocket','websockets','ftplib','smtplib'}
FINANCIAL={'ccxt','MetaTrader5','binance','alpaca','ib_insync','oandapyV20'}
PROCESSES={'subprocess','multiprocessing'}

def sha(raw):return hashlib.sha256(raw).hexdigest()
def pairs(rows):
    d={}
    for k,v in rows:
        if k in d:raise ValueError('duplicate manifest key')
        d[k]=v
    return d

def inspect_zip(path,expected_sha256,expected_project='ARIYAN_TRADING_AI'):
    p=pathlib.Path(path)
    if p.stat().st_size>MAX_ARCHIVE:raise ValueError('archive quota')
    if type(expected_sha256) is not str or len(expected_sha256)!=64 or any(c not in '0123456789abcdef' for c in expected_sha256):raise ValueError('exact caller fingerprint required')
    fingerprint=sha(p.read_bytes())
    if fingerprint!=expected_sha256:raise ValueError('archive fingerprint mismatch')
    files={};findings=[];python=[];directories=[]
    with zipfile.ZipFile(p) as z:
        infos=z.infolist()
        if len(infos)>MAX_ENTRIES:raise ValueError('entry count quota')
        paths=[];total=0
        for info in infos:
            name=info.filename[:-1] if info.is_dir() else info.filename
            safe_name(name)
            if any(ord(c)<32 or c in '<>"|?*' for c in name):raise ValueError('nonportable archive path')
            if name.casefold() in {n.casefold() for n in paths}:raise ValueError('duplicate or case-colliding entry')
            paths.append(name);total+=info.file_size
            if info.flag_bits&1 or stat.S_ISLNK(info.external_attr>>16):raise ValueError('encrypted or symbolic entry')
            if info.compress_type not in (zipfile.ZIP_STORED,zipfile.ZIP_DEFLATED):raise ValueError('unsupported compression')
            if info.file_size>MAX_FILE or total>MAX_TOTAL:raise ValueError('uncompressed byte quota')
            if info.is_dir():directories.append(name);continue
            raw=z.read(info);files[name]={'sha256':sha(raw),'bytes':len(raw)}
            if name.endswith('.py'):
                imports=set();flags=[];parse_error=None
                try:
                    tree=ast.parse(raw,filename=name)
                    for node in ast.walk(tree):
                        if isinstance(node,ast.Import):imports.update(a.name.split('.')[0] for a in node.names)
                        elif isinstance(node,ast.ImportFrom) and node.module:imports.add(node.module.split('.')[0])
                        elif isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id in ('exec','eval','__import__'):flags.append('DYNAMIC_CODE_CAPABILITY')
                    if imports&NETWORK:flags.append('NETWORK_CAPABILITY_REQUIRES_REVIEW')
                    if imports&FINANCIAL:flags.append('FINANCIAL_ADAPTER_CAPABILITY_REQUIRES_REVIEW')
                    if imports&PROCESSES:flags.append('PROCESS_CAPABILITY_REQUIRES_REVIEW')
                except (SyntaxError,UnicodeError,ValueError,RecursionError) as exc:parse_error=type(exc).__name__;flags.append('AST_PARSE_FAILED')
                python.append({'path':name,'imports':sorted(imports),'flags':sorted(set(flags)),'parse_error':parse_error,'executed':False})
        file_paths={name.casefold() for name in files}
        for name in paths:
            parts=name.casefold().split('/')
            if any('/'.join(parts[:i]) in file_paths for i in range(1,len(parts))):raise ValueError('file/directory prefix collision')
        manifest=None
        if MANIFEST in files:
            manifest=json.loads(z.read(MANIFEST),object_pairs_hook=pairs)
            if type(manifest) is not dict or set(manifest)!={'project','artifact_kind','entrypoint','source_commit','files'}:raise ValueError('source manifest schema')
            if manifest['project']!=expected_project or manifest['artifact_kind'] not in ('application_source','reference_archive'):raise ValueError('project or artifact kind mismatch')
            safe_name(manifest['entrypoint'])
            commit=manifest['source_commit']
            if type(commit) is not str or len(commit) not in (40,64) or any(c not in '0123456789abcdef' for c in commit):raise ValueError('source commit must be explicit')
            declared=manifest['files']
            if type(declared) is not dict or set(declared)!=set(files)-{MANIFEST}:raise ValueError('source manifest member mismatch')
            for name,value in declared.items():
                if value!=files[name]['sha256']:raise ValueError('source member hash mismatch')
            if manifest['entrypoint'] not in files:raise ValueError('missing declared entrypoint')
        kind='UNIDENTIFIED_ARCHIVE' if manifest is None else 'CLAIMED_APPLICATION_SOURCE' if manifest['artifact_kind']=='application_source' else 'DECLARED_REFERENCE_ARCHIVE'
    return {'archive_sha256':fingerprint,'fingerprint_matched':True,'classification':kind,'project_manifest_claim':manifest,'files':files,'python_files':python,'directories':directories,
            'ownership_verified':False,'runnable_verified':False,'application_integration_verified':False,'executed_candidate_code':False,'financial_authority':False,
            'disposition':'REVIEW_REQUIRED','limitations':['Static Python import flags are incomplete capability hints, not proof of safety or wrongdoing.','No dependency installation, imports, subprocess execution or extraction of candidate code.','Manifest and commit strings do not authenticate ownership or Git history.']}

if __name__=='__main__':
    import sys
    result=inspect_zip(sys.argv[1],sys.argv[2]);pathlib.Path(sys.argv[3]).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('archive_sha256','classification','ownership_verified','application_integration_verified','executed_candidate_code')},indent=2))
