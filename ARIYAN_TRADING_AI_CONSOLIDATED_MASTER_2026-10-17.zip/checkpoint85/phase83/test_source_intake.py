import hashlib,json,pathlib,stat,tempfile,unittest,zipfile,warnings
from source_intake import inspect_zip,MANIFEST

class IntakeTests(unittest.TestCase):
    def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.p=pathlib.Path(self.tmp.name)
    def tearDown(self):self.tmp.cleanup()
    def build(self,members,manifest=False):
        if manifest:
            raw={'project':'ARIYAN_TRADING_AI','artifact_kind':'application_source','entrypoint':'main.py','source_commit':'a'*40,'files':{n:hashlib.sha256(v).hexdigest() for n,v in members}}
            members=members+[(MANIFEST,json.dumps(raw).encode())]
        path=self.p/'candidate.zip'
        with warnings.catch_warnings():
            warnings.simplefilter('ignore',UserWarning)
            with zipfile.ZipFile(path,'w') as z:
                for name,raw in members:z.writestr(name,raw)
        return path,hashlib.sha256(path.read_bytes()).hexdigest()
    def inspect(self,members,manifest=False):return inspect_zip(*self.build(members,manifest))
    def test_self_declared_source_is_not_verified_application(self):
        r=self.inspect([('main.py',b'print("hello")')],True);self.assertEqual(r['classification'],'CLAIMED_APPLICATION_SOURCE');self.assertFalse(r['ownership_verified']);self.assertFalse(r['application_integration_verified'])
    def test_unidentified_archive_is_not_application(self):self.assertEqual(self.inspect([('prototype.py',b'x=1')])['classification'],'UNIDENTIFIED_ARCHIVE')
    def test_candidate_code_never_executes(self):
        marker=self.p/'executed';code=('from pathlib import Path\nPath('+repr(str(marker))+').write_text("bad")\nraise RuntimeError("candidate executed")').encode()
        r=self.inspect([('main.py',code)],True);self.assertFalse(marker.exists());self.assertFalse(r['executed_candidate_code'])
    def test_mismatched_archive_hash(self):
        path,_=self.build([('main.py',b'pass')])
        with self.assertRaises(ValueError):inspect_zip(path,'0'*64)
    def test_caller_hash_required(self):
        path,_=self.build([('main.py',b'pass')])
        with self.assertRaises(ValueError):inspect_zip(path,None)
    def test_path_traversal_rejected(self):
        with self.assertRaises(ValueError):self.inspect([('../outside.py',b'pass')])
    def test_case_collision_rejected(self):
        with self.assertRaises(ValueError):self.inspect([('Main.py',b'pass'),('main.py',b'pass')])
    def test_duplicate_path_rejected(self):
        with self.assertRaises(ValueError):self.inspect([('main.py',b'pass'),('main.py',b'other')])
    def test_static_capability_flags(self):
        r=self.inspect([('main.py',b'import socket, subprocess, ccxt\neval("x")')]);flags=r['python_files'][0]['flags'];self.assertEqual(len(flags),4)
    def test_syntax_failure_is_visible_not_executed(self):
        r=self.inspect([('main.py',b'!!!')]);self.assertIn('AST_PARSE_FAILED',r['python_files'][0]['flags']);self.assertFalse(r['executed_candidate_code'])
    def test_manifest_tampered_hash_rejected(self):
        m={'project':'ARIYAN_TRADING_AI','artifact_kind':'application_source','entrypoint':'main.py','source_commit':'a'*40,'files':{'main.py':'0'*64}}
        with self.assertRaises(ValueError):self.inspect([('main.py',b'pass'),(MANIFEST,json.dumps(m).encode())])
    def test_manifest_missing_member_rejected(self):
        m={'project':'ARIYAN_TRADING_AI','artifact_kind':'application_source','entrypoint':'absent.py','source_commit':'a'*40,'files':{}}
        with self.assertRaises(ValueError):self.inspect([(MANIFEST,json.dumps(m).encode())])
    def test_manifest_duplicate_key_rejected(self):
        with self.assertRaises(ValueError):self.inspect([(MANIFEST,b'{"project":"x","project":"y"}')])
    def test_wrong_project_rejected(self):
        path,h=self.build([('main.py',b'pass')],True)
        with self.assertRaises(ValueError):inspect_zip(path,h,'OTHER_PROJECT')
    def test_symlink_rejected(self):
        path=self.p/'link.zip'
        with zipfile.ZipFile(path,'w') as z:
            info=zipfile.ZipInfo('link.py');info.create_system=3;info.external_attr=(stat.S_IFLNK|0o777)<<16;z.writestr(info,'target')
        with self.assertRaises(ValueError):inspect_zip(path,hashlib.sha256(path.read_bytes()).hexdigest())
    def test_directory_entry_is_not_extracted(self):
        r=self.inspect([('folder/',b''),('folder/main.py',b'pass')]);self.assertEqual(r['directories'],['folder']);self.assertFalse((self.p/'folder').exists())
    def test_file_directory_prefix_collision(self):
        with self.assertRaises(ValueError):self.inspect([('folder',b'file'),('folder/main.py',b'pass')])
    def test_windows_forbidden_characters(self):
        for name in ('bad*.py','bad?.py','bad|.py','bad\x01.py'):
            with self.subTest(name=name):
                with self.assertRaises(ValueError):self.inspect([(name,b'pass')])
    def test_unsupported_compression(self):
        path=self.p/'codec.zip'
        with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_BZIP2) as z:z.writestr('main.py',b'pass')
        with self.assertRaises(ValueError):inspect_zip(path,hashlib.sha256(path.read_bytes()).hexdigest())
    def test_uncompressed_size_limit(self):
        import unittest.mock
        path,h=self.build([('main.py',b'x'*21)])
        with unittest.mock.patch('source_intake.MAX_FILE',20):
            with self.assertRaises(ValueError):inspect_zip(path,h)

if __name__=='__main__':unittest.main(verbosity=2)
