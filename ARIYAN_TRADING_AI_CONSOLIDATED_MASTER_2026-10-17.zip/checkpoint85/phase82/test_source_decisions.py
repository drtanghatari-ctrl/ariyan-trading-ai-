import copy,pathlib,tempfile,unittest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.exceptions import InvalidSignature
from rotation import canonical,raw_public,Rejected,ZERO
from source_decisions import draft,source_identity,verify_decision,make_review_pack

def source(suffix):return (''.join(f'{n} — Clause {n} {suffix}\nNo authority is inferred.\n' for n in range(6101,6201))+'End of Sections 6101–6200.\n').encode()

class SourceDecisionTests(unittest.TestCase):
    def setUp(self):
        self.left=source('master');self.right=source('alternate');self.sources={source_identity(x):x for x in (self.left,self.right)}
        self.owner=Ed25519PrivateKey.generate();self.reviewer=Ed25519PrivateKey.generate();self.b=draft(self.left,self.right,6101)
        self.b.update(outcome='COEXIST_NO_SUPERSESSION',reason='Preserve both versions pending further scoped interpretation.',evidence_hashes=['a'*64],issued_at=100,expires_at=200)
    def packet(self,b=None):
        b=b or self.b;return {'decision':b,'owner_signature':self.owner.sign(canonical(b)).hex(),'reviewer_signature':self.reviewer.sign(canonical(b)).hex()}
    def verify(self,packet=None,**kwargs):return verify_decision(packet or self.packet(),self.sources,raw_public(self.owner),raw_public(self.reviewer),150,**kwargs)
    def test_valid_scoped_fixture_decision_denies_production_authority(self):
        r=self.verify();self.assertTrue(r['source_review_signature_valid']);self.assertFalse(r['financial_authority']);self.assertFalse(r['production_certified']);self.assertFalse(r['original_bytes_may_be_modified'])
    def test_incomplete_draft_rejected(self):
        with self.assertRaises(Rejected):self.verify(self.packet(draft(self.left,self.right,6101)))
    def test_two_roles_cannot_use_same_key(self):
        p=self.packet();p['reviewer_signature']=p['owner_signature']
        with self.assertRaises(Rejected):verify_decision(p,self.sources,raw_public(self.owner),raw_public(self.owner),150)
    def test_forged_reviewer_signature(self):
        p=self.packet();p['reviewer_signature']='0'*128
        with self.assertRaises(InvalidSignature):self.verify(p)
    def test_source_bytes_tamper(self):
        self.sources[source_identity(self.left)]=self.left+b'changed'
        with self.assertRaises(Rejected):self.verify()
    def test_reference_offsets_tamper(self):
        self.b['sources'][0]['byte_start']+=1
        with self.assertRaises(Rejected):self.verify()
    def test_section_mismatch(self):
        self.b['scope']['section']=6102
        with self.assertRaises(Rejected):self.verify()
    def test_no_implicit_authority_selection(self):
        self.b['selected_source']=source_identity(self.left)
        with self.assertRaises(Rejected):self.verify()
    def test_supersession_requires_selected_reviewed_source(self):
        self.b['outcome']='SCOPED_SUPERSESSION'
        with self.assertRaises(Rejected):self.verify()
        self.b['selected_source']=source_identity(self.right);self.assertTrue(self.verify()['source_review_signature_valid'])
    def test_production_scope_rejected(self):
        self.b['scope']['environment']='PRODUCTION'
        with self.assertRaises(Rejected):self.verify()
    def test_expired_decision(self):
        self.b['expires_at']=150
        with self.assertRaises(Rejected):self.verify()
    def test_stale_generation_or_previous_head(self):
        with self.assertRaises(Rejected):self.verify(expected_generation=2)
        with self.assertRaises(Rejected):self.verify(previous='f'*64)
    def test_boolean_generation_rejected(self):
        self.b['generation']=True
        with self.assertRaises(Rejected):self.verify()
    def test_review_pack_has_no_signed_actual_decisions(self):
        with tempfile.TemporaryDirectory() as tmp:
            r=make_review_pack(self.left,self.right,tmp);self.assertEqual(r['drafts'],100);self.assertEqual(r['signed_real_decisions'],0)
    def test_review_pack_regeneration_is_deterministic(self):
        with tempfile.TemporaryDirectory() as tmp:
            a=pathlib.Path(tmp)/'a';b=pathlib.Path(tmp)/'b'
            make_review_pack(self.left,self.right,a);make_review_pack(self.left,self.right,b)
            self.assertEqual((a/'SOURCE_REVIEW_DRAFTS.json').read_bytes(),(b/'SOURCE_REVIEW_DRAFTS.json').read_bytes())

if __name__=='__main__':unittest.main(verbosity=2)
