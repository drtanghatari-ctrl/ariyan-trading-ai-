"""Draft/source-adjudication verifier. Fixture signatures do NOT identify humans.
Never infer normative authority from source number, title, date, or lexical rank.
"""
import hashlib,json,pathlib,re,uuid
from rotation import canonical,digest,hexfield,integer,Rejected,ZERO
from checkpoint import exact,verify_signature,label
from variant_compare import parse_block
DOMAIN='ARIYAN-SOURCE-DECISION-v1'
OUTCOMES={'UNDECIDED','COEXIST_NO_SUPERSESSION','COMPATIBLE_COEXISTENCE','CONFLICT_BLOCKING','SCOPED_SUPERSESSION'}

def source_identity(raw):return hashlib.sha256(raw).hexdigest()

def reference(raw,section):
    row=parse_block(raw)[section]
    return {'source_sha256':source_identity(raw),'section':section,'byte_start':row['byte_start'],'byte_end':row['byte_end'],'clause_sha256':row['sha256']}

def validate_reference(ref,sources):
    exact(ref,('source_sha256','section','byte_start','byte_end','clause_sha256'))
    hexfield(ref['source_sha256'],64);hexfield(ref['clause_sha256'],64)
    integer(ref['section'],6101);integer(ref['byte_start']);integer(ref['byte_end'],1)
    if ref['section']>6200 or ref['source_sha256'] not in sources:raise Rejected('unavailable or out-of-scope source')
    if ref!=reference(sources[ref['source_sha256']],ref['section']):raise Rejected('source reference mismatch')

def draft(left,right,section):
    return {'domain':DOMAIN,'decision_id':uuid.uuid4().hex,'scope':{'project':'ARIYAN_TRADING_AI','section':section,'environment':'OFFLINE_REFERENCE'},
            'sources':[reference(left,section),reference(right,section)],'outcome':'UNDECIDED','selected_source':None,
            'reason':None,'evidence_hashes':[],'issued_at':None,'expires_at':None,'generation':1,'previous':ZERO}

def verify_decision(packet,sources,owner_public,reviewer_public,now,expected_generation=1,previous=ZERO):
    """Caller must independently establish identities and retain generation/head.
    Returns a scoped review result, never implementation certification or authority
    for capital, execution, production, or modifying original architectural bytes.
    """
    exact(packet,('decision','owner_signature','reviewer_signature'));b=packet['decision']
    exact(b,('domain','decision_id','scope','sources','outcome','selected_source','reason','evidence_hashes','issued_at','expires_at','generation','previous'))
    if b['domain']!=DOMAIN:raise Rejected('decision domain')
    hexfield(b['decision_id'],32);integer(b['generation'],1);hexfield(b['previous'],64);integer(expected_generation,1);hexfield(previous,64)
    if (b['generation'],b['previous'])!=(expected_generation,previous):raise Rejected('stale or forked decision')
    scope=b['scope'];exact(scope,('project','section','environment'));integer(scope['section'],6101)
    if scope['project']!='ARIYAN_TRADING_AI' or scope['environment']!='OFFLINE_REFERENCE' or scope['section']>6200:raise Rejected('decision scope')
    if type(b['sources']) is not list or len(b['sources'])!=2:raise Rejected('two exact source references required')
    for ref in b['sources']:
        validate_reference(ref,sources)
        if ref['section']!=scope['section']:raise Rejected('cross-section decision')
    fingerprints=[r['source_sha256'] for r in b['sources']]
    if len(set(fingerprints))!=2:raise Rejected('distinct versions required')
    if b['outcome'] not in OUTCOMES or b['outcome']=='UNDECIDED':raise Rejected('unsigned/incomplete draft is not a decision')
    if b['outcome']=='SCOPED_SUPERSESSION':
        if b['selected_source'] not in fingerprints:raise Rejected('selected source not in reviewed pair')
    elif b['selected_source'] is not None:raise Rejected('non-supersession decision cannot select authority')
    if type(b['reason']) is not str or not 10<=len(b['reason'])<=4000:raise Rejected('review rationale required')
    if type(b['evidence_hashes']) is not list or not 1<=len(b['evidence_hashes'])<=32 or len(set(b['evidence_hashes']))!=len(b['evidence_hashes']):raise Rejected('distinct review evidence required')
    for value in b['evidence_hashes']:hexfield(value,64)
    integer(b['issued_at']);integer(b['expires_at']);integer(now)
    if not b['issued_at']<=now<b['expires_at'] or not 0<b['expires_at']-b['issued_at']<=30*86400:raise Rejected('decision validity')
    hexfield(owner_public,64);hexfield(reviewer_public,64)
    if owner_public==reviewer_public:raise Rejected('owner and independent reviewer must have distinct pinned keys')
    verify_signature(owner_public,b,packet['owner_signature']);verify_signature(reviewer_public,b,packet['reviewer_signature'])
    return {'source_review_signature_valid':True,'outcome':b['outcome'],'scope':scope,'decision_sha256':digest(b),'financial_authority':False,'production_certified':False,'original_bytes_may_be_modified':False}

STOP=set('the a an and or of to for in on with is are must shall may be not by its it this that as where from each any no'.split())
def terms(raw):return set(re.findall(r'[a-z][a-z_]{2,}',raw.decode().lower()))-STOP

def make_review_pack(left,right,output):
    out=pathlib.Path(output);out.mkdir(parents=True,exist_ok=True);a=parse_block(left);b=parse_block(right);rows=[]
    alternate_terms={n:terms(right[r['byte_start']:r['byte_end']]) for n,r in b.items()}
    for n in range(6101,6201):
        t=terms(left[a[n]['byte_start']:a[n]['byte_end']]);rank=[]
        for k,u in alternate_terms.items():rank.append((len(t&u)/len(t|u) if t|u else 0,k))
        rank.sort(key=lambda item:(-item[0],item[1]))
        candidates=[{'alternate_section':k,'lexical_jaccard':round(score,6),'evidence':'LEXICAL_ONLY_NOT_SEMANTIC_OR_AUTHORITY'} for score,k in rank[:3]]
        record=draft(left,right,n)
        record['decision_id']=digest({'domain':DOMAIN,'left':source_identity(left),'right':source_identity(right),'section':n})[:32]
        rows.append({'section':n,'master_heading':a[n]['heading'],'alternate_same_number_heading':b[n]['heading'],'draft':record,'candidate_related_alternate_sections':candidates,'owner_identity':None,'reviewer_identity':None,'approval':'NOT_REQUESTED_OR_GRANTED'})
    (out/'SOURCE_REVIEW_DRAFTS.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
    summary={'numbered_pairs':100,'drafts':100,'signed_real_decisions':0,'source_authority_resolved':0,'original_sources_modified':0,'lexical_candidates_per_pair':3,'no_automatic_merge':True}
    (out/'SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n');return summary

if __name__=='__main__':
    import sys
    print(json.dumps(make_review_pack(pathlib.Path(sys.argv[1]).read_bytes(),pathlib.Path(sys.argv[2]).read_bytes(),sys.argv[3]),indent=2))
