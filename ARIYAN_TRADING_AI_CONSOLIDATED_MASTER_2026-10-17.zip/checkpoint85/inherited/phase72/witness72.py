"""Research-only external-signer interface. In-memory keys are NOT protected HSM keys."""
import sqlite3,json
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey,Ed25519PublicKey
from cryptography.hazmat.primitives import serialization

def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':'))
class MemorySigner:
 def __init__(self):self.keys={1:Ed25519PrivateKey.generate()};self.epoch=1
 def rotate(self):self.epoch+=1;self.keys[self.epoch]=Ed25519PrivateKey.generate()
 def sign(self,epoch,msg):return self.keys[epoch].sign(msg).hex()
 def public(self,epoch):return self.keys[epoch].public_key()
class Witness:
 def __init__(self,path,signer):
  self.signer=signer;self.db=sqlite3.connect(str(path),isolation_level=None,timeout=15)
  self.db.execute('PRAGMA journal_mode=WAL');self.db.execute('PRAGMA synchronous=FULL')
  self.db.execute('CREATE TABLE IF NOT EXISTS state (id INTEGER PRIMARY KEY CHECK(id=1), seq INTEGER NOT NULL,digest TEXT NOT NULL,epoch INTEGER NOT NULL)')
  self.db.execute('CREATE TABLE IF NOT EXISTS attest (seq INTEGER PRIMARY KEY,digest TEXT NOT NULL,epoch INTEGER NOT NULL,signature TEXT NOT NULL)')
  self.db.execute('CREATE TABLE IF NOT EXISTS rotations (epoch INTEGER PRIMARY KEY,previous_epoch INTEGER NOT NULL,proof TEXT NOT NULL)')
  self.db.execute("INSERT OR IGNORE INTO state VALUES (1,0,?,1)",('0'*64,))
 def state(self):return self.db.execute('SELECT seq,digest,epoch FROM state').fetchone()
 def issue(self,seq,digest):
  if type(seq)!=int or seq<1 or not isinstance(digest,str) or len(digest)!=64 or any(c not in '0123456789abcdef' for c in digest):raise ValueError('invalid')
  self.db.execute('BEGIN IMMEDIATE')
  try:
   high,old,epoch=self.state()
   if self.signer.epoch!=epoch:raise ValueError('unrecorded key rotation')
   if seq<high or (seq==high and digest!=old):raise ValueError('rollback/equivocation')
   existing=self.db.execute('SELECT digest,epoch,signature FROM attest WHERE seq=?',(seq,)).fetchone()
   if existing:
    if existing[0]!=digest:raise ValueError('equivocation')
    result={'statement':{'seq':seq,'digest':digest,'epoch':existing[1]},'signature':existing[2]}
   else:
    statement={'seq':seq,'digest':digest,'epoch':epoch}
    sig=self.signer.sign(epoch,canonical(statement).encode())
    self.db.execute('INSERT INTO attest VALUES (?,?,?,?)',(seq,digest,epoch,sig))
    self.db.execute('UPDATE state SET seq=?,digest=?',(seq,digest))
    result={'statement':statement,'signature':sig}
   self.db.execute('COMMIT');return result
  except BaseException:self.db.execute('ROLLBACK');raise
 def rotate(self):
  # Must have same signer instance; real production would require secure, external key custodian.
  self.db.execute('BEGIN IMMEDIATE')
  try:
   seq,digest,epoch=self.state()
   if self.signer.epoch!=epoch:raise ValueError('signer epoch mismatch')
   new_epoch=epoch+1
   statement={'type':'rotate','from':epoch,'to':new_epoch,'seq':seq,'digest':digest}
   proof=self.signer.sign(epoch,canonical(statement).encode())
   self.signer.rotate()
   self.db.execute('INSERT INTO rotations VALUES (?,?,?)',(new_epoch,epoch,proof))
   self.db.execute('UPDATE state SET epoch=?',(new_epoch,))
   self.db.execute('COMMIT');return statement,proof
  except BaseException:self.db.execute('ROLLBACK');raise
 def close(self):self.db.close()
