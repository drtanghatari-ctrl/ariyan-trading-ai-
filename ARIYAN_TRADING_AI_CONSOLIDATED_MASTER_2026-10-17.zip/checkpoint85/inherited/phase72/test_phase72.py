import unittest,tempfile,pathlib,sqlite3,subprocess,sys
from witness72 import Witness,MemorySigner,canonical
class T(unittest.TestCase):
 def setUp(self):self.tmp=tempfile.TemporaryDirectory();self.path=pathlib.Path(self.tmp.name)/'w.db';self.signer=MemorySigner();self.w=Witness(self.path,self.signer)
 def tearDown(self):self.w.close();self.tmp.cleanup()
 def test_no_private_key_column(self):
  fields=[x[1] for x in self.w.db.execute('PRAGMA table_info(state)')];self.assertNotIn('secret',fields)
 def test_signature_verifies(self):
  a=self.w.issue(1,'a'*64);self.signer.public(1).verify(bytes.fromhex(a['signature']),canonical(a['statement']).encode())
 def test_replay_idempotent(self):self.assertEqual(self.w.issue(1,'a'*64),self.w.issue(1,'a'*64))
 def test_equivocation(self):
  self.w.issue(1,'a'*64)
  with self.assertRaises(ValueError):self.w.issue(1,'b'*64)
 def test_rollback(self):
  self.w.issue(2,'b'*64)
  with self.assertRaises(ValueError):self.w.issue(1,'a'*64)
 def test_rotate_new_epoch(self):
  self.w.issue(1,'a'*64);statement,proof=self.w.rotate();self.signer.public(1).verify(bytes.fromhex(proof),canonical(statement).encode());a=self.w.issue(2,'b'*64);self.assertEqual(a['statement']['epoch'],2);self.signer.public(2).verify(bytes.fromhex(a['signature']),canonical(a['statement']).encode())
 def test_rotation_keeps_old_attestation(self):
  old=self.w.issue(1,'a'*64);self.w.rotate();self.assertEqual(self.w.issue(1,'a'*64),old)
 def test_unrecorded_signer_rotation_fail_closed(self):
  self.signer.rotate()
  with self.assertRaises(ValueError):self.w.issue(1,'a'*64)
 def test_reopen_same_signer(self):
  self.w.issue(1,'a'*64);self.w.close();self.w=Witness(self.path,self.signer);self.assertEqual(self.w.state()[0],1)
 def test_reopen_new_signer_fails_after_rotation(self):
  self.w.rotate();self.w.close();self.w=Witness(self.path,MemorySigner())
  with self.assertRaises(ValueError):self.w.issue(1,'a'*64)
 def test_abrupt_exit_uncommitted_transaction(self):
  self.w.issue(1,'a'*64)
  code='import sqlite3,os,sys;db=sqlite3.connect(sys.argv[1]);db.execute("BEGIN IMMEDIATE");db.execute("UPDATE state SET seq=999");os._exit(33)'
  r=subprocess.run([sys.executable,'-c',code,str(self.path)]);self.assertEqual(r.returncode,33);self.assertEqual(self.w.state()[0],1)
 def test_crash_after_commit_visible(self):
  code='import sqlite3,os,sys;db=sqlite3.connect(sys.argv[1]);db.execute("BEGIN IMMEDIATE");db.execute("UPDATE state SET seq=5");db.commit();os._exit(34)'
  r=subprocess.run([sys.executable,'-c',code,str(self.path)]);self.assertEqual(r.returncode,34);self.assertEqual(self.w.state()[0],5)
if __name__=='__main__':unittest.main(verbosity=2)
