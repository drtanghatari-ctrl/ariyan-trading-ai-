import unittest,tempfile,pathlib,sqlite3,subprocess,sys,json
from durable_witness import DurableWitness
from audit_chain import canonical
class Tests(unittest.TestCase):
 def setUp(self):
  self.t=tempfile.TemporaryDirectory();self.path=pathlib.Path(self.t.name)/'w.db';self.w=DurableWitness(self.path)
 def tearDown(self):self.w.close();self.t.cleanup()
 def test_first_issue(self):self.assertEqual(self.w.issue(1,'a'*64)['statement']['sequence'],1)
 def test_repeat_idempotent(self):
  a=self.w.issue(1,'a'*64);self.assertEqual(a,self.w.issue(1,'a'*64))
 def test_rollback(self):
  self.w.issue(2,'b'*64)
  with self.assertRaises(ValueError):self.w.issue(1,'a'*64)
 def test_equivocation(self):
  self.w.issue(1,'a'*64)
  with self.assertRaises(ValueError):self.w.issue(1,'b'*64)
 def test_reopen_persists(self):
  self.w.issue(2,'b'*64);self.w.close();self.w=DurableWitness(self.path);self.assertEqual(self.w.state()[0],2)
  with self.assertRaises(ValueError):self.w.issue(1,'a'*64)
 def test_signature_verifies_after_reopen(self):
  a=self.w.issue(1,'a'*64);self.w.close();self.w=DurableWitness(self.path);self.w.public_key().verify(bytes.fromhex(a['signature']),canonical(a['statement']).encode())
 def test_reject_bad_digest(self):
  with self.assertRaises(ValueError):self.w.issue(1,'X'*64)
 def test_reject_boolean_seq(self):
  with self.assertRaises(ValueError):self.w.issue(True,'a'*64)
 def test_rollback_on_injected_failure(self):
  self.w.db.execute('BEGIN IMMEDIATE');self.w.db.execute('UPDATE witness SET seq=8 WHERE id=1');self.w.db.execute('ROLLBACK');self.assertEqual(self.w.state()[0],0)
 def test_cross_process_reopen(self):
  self.w.issue(3,'c'*64);self.w.close()
  script='from durable_witness import DurableWitness;import sys;w=DurableWitness(sys.argv[1]);print(w.state()[0]);w.close()'
  run=subprocess.run([sys.executable,'-c',script,str(self.path)],capture_output=True,text=True,cwd=str(pathlib.Path(__file__).parent))
  self.assertEqual(run.returncode,0,run.stderr);self.assertEqual(run.stdout.strip(),'3');self.w=DurableWitness(self.path)
 def test_concurrent_equivocation(self):
  self.w.close()
  a=subprocess.run([sys.executable,'worker.py',str(self.path),'a'*64],capture_output=True,text=True,cwd=str(pathlib.Path(__file__).parent))
  b=subprocess.run([sys.executable,'worker.py',str(self.path),'b'*64],capture_output=True,text=True,cwd=str(pathlib.Path(__file__).parent))
  self.assertEqual(a.returncode,0,a.stderr);self.assertEqual(b.returncode,0,b.stderr);self.assertIn('OK',a.stdout);self.assertIn('REJECT',b.stdout);self.w=DurableWitness(self.path)

if __name__=='__main__':unittest.main(verbosity=2)
