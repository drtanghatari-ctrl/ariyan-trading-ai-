import sys
from durable_witness import DurableWitness
w=DurableWitness(sys.argv[1])
try:
 w.issue(1,sys.argv[2]);print('OK')
except ValueError:print('REJECT')
finally:w.close()
