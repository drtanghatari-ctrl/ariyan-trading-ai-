"""Research reference only. Separate SQLite store is NOT an independent trust domain."""
import sqlite3,json,pathlib
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.hazmat.primitives import serialization
from audit_chain import canonical
class DurableWitness:
 def __init__(self,path):
  self.db=sqlite3.connect(str(path),isolation_level=None,timeout=10)
  self.db.execute('PRAGMA journal_mode=WAL');self.db.execute('PRAGMA synchronous=FULL')
  self.db.execute('CREATE TABLE IF NOT EXISTS witness (id INTEGER PRIMARY KEY CHECK(id=1),seq INTEGER NOT NULL,digest TEXT NOT NULL,key_epoch INTEGER NOT NULL,secret BLOB NOT NULL)')
  self.db.execute('CREATE TABLE IF NOT EXISTS issued (seq INTEGER PRIMARY KEY,digest TEXT NOT NULL,key_epoch INTEGER NOT NULL,signature TEXT NOT NULL)')
  if not self.db.execute('SELECT 1 FROM witness WHERE id=1').fetchone():
   key=Ed25519PrivateKey.generate();raw=key.private_bytes(serialization.Encoding.Raw,serialization.PrivateFormat.Raw,serialization.NoEncryption())
   self.db.execute('INSERT INTO witness VALUES (1,0,?,1,?)',('0'*64,raw))
 def issue(self,seq,digest):
  if type(seq) is not int or seq<0 or type(digest) is not str or len(digest)!=64 or any(c not in '0123456789abcdef' for c in digest):raise ValueError('invalid input')
  self.db.execute('BEGIN IMMEDIATE')
  try:
   high,old,epoch,raw=self.db.execute('SELECT seq,digest,key_epoch,secret FROM witness WHERE id=1').fetchone()
   if seq<high or (seq==high and digest!=old):raise ValueError('rollback/equivocation')
   row=self.db.execute('SELECT digest,key_epoch,signature FROM issued WHERE seq=?',(seq,)).fetchone()
   if row:
    if row[0]!=digest:raise ValueError('equivocation')
    result={'statement':{'version':1,'sequence':seq,'digest':digest,'key_epoch':row[1]},'signature':row[2]}
   else:
    statement={'version':1,'sequence':seq,'digest':digest,'key_epoch':epoch}
    sig=Ed25519PrivateKey.from_private_bytes(raw).sign(canonical(statement).encode()).hex()
    self.db.execute('INSERT INTO issued VALUES (?,?,?,?)',(seq,digest,epoch,sig))
    self.db.execute('UPDATE witness SET seq=?,digest=? WHERE id=1',(seq,digest))
    result={'statement':statement,'signature':sig}
   self.db.execute('COMMIT');return result
  except BaseException:
   self.db.execute('ROLLBACK');raise
 def public_key(self):
  raw=self.db.execute('SELECT secret FROM witness WHERE id=1').fetchone()[0]
  return Ed25519PrivateKey.from_private_bytes(raw).public_key()
 def state(self):return self.db.execute('SELECT seq,digest,key_epoch FROM witness WHERE id=1').fetchone()
 def close(self):self.db.close()
