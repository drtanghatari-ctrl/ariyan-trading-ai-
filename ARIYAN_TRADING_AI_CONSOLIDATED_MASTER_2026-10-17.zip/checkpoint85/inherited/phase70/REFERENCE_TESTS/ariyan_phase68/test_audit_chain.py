import pathlib, tempfile, unittest, sqlite3
from audit_chain import AuditChain

class ChainTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.path=pathlib.Path(self.tmp.name)/"events.db"
        self.chain=AuditChain(self.path)
    def tearDown(self):
        self.chain.close(); self.tmp.cleanup()
    def test_empty(self): self.assertTrue(self.chain.verify())
    def test_append(self):
        self.chain.append({"action":"deny"}); self.assertTrue(self.chain.verify())
    def test_restart(self):
        self.chain.append({"epoch":1}); self.chain.close(); self.chain=AuditChain(self.path)
        self.chain.append({"epoch":2}); self.assertTrue(self.chain.verify())
    def test_payload_tamper(self):
        self.chain.append({"decision":"deny"})
        self.chain.db.execute("UPDATE events SET payload=? WHERE seq=1",('{"decision":"allow"}',))
        self.assertFalse(self.chain.verify())
    def test_digest_tamper(self):
        self.chain.append({"a":1}); self.chain.db.execute("UPDATE events SET digest=? WHERE seq=1",('f'*64,))
        self.assertFalse(self.chain.verify())
    def test_deletion_gap(self):
        self.chain.append({"a":1}); self.chain.append({"a":2}); self.chain.db.execute("DELETE FROM events WHERE seq=1")
        self.assertFalse(self.chain.verify())
    def test_previous_tamper(self):
        self.chain.append({"a":1}); self.chain.append({"a":2}); self.chain.db.execute("UPDATE events SET previous=? WHERE seq=2",('f'*64,))
        self.assertFalse(self.chain.verify())
    def test_rollback_does_not_append(self):
        self.chain.append({"a":1})
        with self.assertRaises(sqlite3.IntegrityError):
            self.chain.db.execute("INSERT INTO events VALUES (1,'x','x','x')")
        self.assertTrue(self.chain.verify())
if __name__=='__main__': unittest.main(verbosity=2)
