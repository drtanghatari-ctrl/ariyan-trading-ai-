"""Isolated reference audit-chain experiment. NOT production authorization."""
import hashlib, json, sqlite3

def canonical(obj):
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)

class AuditChain:
    def __init__(self, path):
        self.db=sqlite3.connect(str(path), isolation_level=None, timeout=10)
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=FULL")
        self.db.execute("CREATE TABLE IF NOT EXISTS events (seq INTEGER PRIMARY KEY, previous TEXT NOT NULL, payload TEXT NOT NULL, digest TEXT NOT NULL)")
    def append(self, event):
        self.db.execute("BEGIN IMMEDIATE")
        try:
            row=self.db.execute("SELECT seq,digest FROM events ORDER BY seq DESC LIMIT 1").fetchone()
            seq=(row[0]+1) if row else 1
            prev=row[1] if row else "0"*64
            payload=canonical(event)
            digest=hashlib.sha256(canonical({"seq":seq,"previous":prev,"payload":payload}).encode()).hexdigest()
            self.db.execute("INSERT INTO events VALUES (?,?,?,?)",(seq,prev,payload,digest))
            self.db.execute("COMMIT")
            return digest
        except BaseException:
            self.db.execute("ROLLBACK")
            raise
    def verify(self):
        prev="0"*64
        for expected,(seq,previous,payload,digest) in enumerate(self.db.execute("SELECT seq,previous,payload,digest FROM events ORDER BY seq"),1):
            if seq!=expected or previous!=prev:
                return False
            check=hashlib.sha256(canonical({"seq":seq,"previous":previous,"payload":payload}).encode()).hexdigest()
            if check!=digest:
                return False
            prev=digest
        return True
    def close(self):
        self.db.close()
