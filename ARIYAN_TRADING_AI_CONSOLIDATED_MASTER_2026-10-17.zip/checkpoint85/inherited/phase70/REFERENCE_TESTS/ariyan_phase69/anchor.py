"""Phase 69 isolated reference: separate-file checkpoint; NOT an independent trust anchor."""
import json, os, pathlib, tempfile
from audit_chain import AuditChain, canonical

class AnchoredChain(AuditChain):
    def head(self):
        row=self.db.execute('SELECT seq,digest FROM events ORDER BY seq DESC LIMIT 1').fetchone()
        return (row[0],row[1]) if row else (0,'0'*64)

def write_checkpoint(chain, destination):
    """Reference-only atomic replace, not a trusted external signature."""
    if not chain.verify(): raise ValueError('chain invalid')
    destination=pathlib.Path(destination)
    destination.parent.mkdir(parents=True,exist_ok=True)
    seq,digest=chain.head()
    payload={'version':1,'sequence':seq,'digest':digest}
    fd,tmp=tempfile.mkstemp(dir=destination.parent,prefix='.anchor-')
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as out:
            out.write(canonical(payload)+'\n');out.flush();os.fsync(out.fileno())
        os.replace(tmp,destination)
        # Directory fsync where supported; not a guarantee against all power loss.
        if hasattr(os,'O_DIRECTORY'):
            dfd=os.open(str(destination.parent),os.O_RDONLY|os.O_DIRECTORY)
            try: os.fsync(dfd)
            finally: os.close(dfd)
    finally:
        if os.path.exists(tmp): os.unlink(tmp)
    return payload

def verify_checkpoint(chain,destination):
    if not chain.verify(): return False
    try:
        obj=json.loads(pathlib.Path(destination).read_text(encoding='utf-8'))
    except (OSError,ValueError): return False
    if set(obj)!={'version','sequence','digest'} or obj['version']!=1: return False
    seq,digest=chain.head()
    return type(obj['sequence']) is int and obj['sequence']==seq and obj['digest']==digest
