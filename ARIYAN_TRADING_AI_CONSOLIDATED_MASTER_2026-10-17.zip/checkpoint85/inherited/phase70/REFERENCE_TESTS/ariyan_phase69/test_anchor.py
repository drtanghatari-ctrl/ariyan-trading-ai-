import json, pathlib, tempfile, unittest
from anchor import AnchoredChain, write_checkpoint, verify_checkpoint
from audit_chain import canonical
import hashlib

class AnchorTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); self.root=pathlib.Path(self.temp.name)
        self.db=self.root/'database'/'events.db';self.db.parent.mkdir()
        self.anchor=self.root/'other_location'/'checkpoint.json';self.chain=AnchoredChain(self.db)
    def tearDown(self):
        self.chain.close();self.temp.cleanup()
    def test_valid_checkpoint(self):
        self.chain.append({'event':'deny'});write_checkpoint(self.chain,self.anchor)
        self.assertTrue(verify_checkpoint(self.chain,self.anchor))
    def test_missing_checkpoint_fail_closed(self):
        self.chain.append({'event':'deny'});self.assertFalse(verify_checkpoint(self.chain,self.anchor))
    def test_truncation_detected(self):
        self.chain.append({'a':1});self.chain.append({'a':2});write_checkpoint(self.chain,self.anchor)
        self.chain.db.execute('DELETE FROM events WHERE seq=2')
        self.assertTrue(self.chain.verify());self.assertFalse(verify_checkpoint(self.chain,self.anchor))
    def test_whole_chain_consistent_rewrite_detected(self):
        self.chain.append({'event':'deny'});write_checkpoint(self.chain,self.anchor)
        payload=canonical({'event':'allow'});prev='0'*64
        digest=hashlib.sha256(canonical({'seq':1,'previous':prev,'payload':payload}).encode()).hexdigest()
        self.chain.db.execute('UPDATE events SET payload=?,digest=? WHERE seq=1',(payload,digest))
        self.assertTrue(self.chain.verify());self.assertFalse(verify_checkpoint(self.chain,self.anchor))
    def test_checkpoint_tamper_detected(self):
        self.chain.append({'a':1});write_checkpoint(self.chain,self.anchor)
        obj=json.loads(self.anchor.read_text());obj['digest']='f'*64;self.anchor.write_text(json.dumps(obj))
        self.assertFalse(verify_checkpoint(self.chain,self.anchor))
    def test_restart_checkpoint(self):
        self.chain.append({'a':1});write_checkpoint(self.chain,self.anchor)
        self.chain.close();self.chain=AnchoredChain(self.db)
        self.assertTrue(verify_checkpoint(self.chain,self.anchor))
    def test_unanchored_new_append_not_authorized(self):
        self.chain.append({'a':1});write_checkpoint(self.chain,self.anchor)
        self.chain.append({'a':2});self.assertFalse(verify_checkpoint(self.chain,self.anchor))
    def test_reanchor_new_append(self):
        self.chain.append({'a':1});write_checkpoint(self.chain,self.anchor)
        self.chain.append({'a':2});write_checkpoint(self.chain,self.anchor)
        self.assertTrue(verify_checkpoint(self.chain,self.anchor))
    def test_corrupt_checkpoint_fail_closed(self):
        self.chain.append({'a':1});self.anchor.parent.mkdir();self.anchor.write_text('{')
        self.assertFalse(verify_checkpoint(self.chain,self.anchor))
    def test_empty_chain_checkpoint_not_authority(self):
        write_checkpoint(self.chain,self.anchor)
        self.assertTrue(verify_checkpoint(self.chain,self.anchor))
if __name__=='__main__':unittest.main(verbosity=2)
