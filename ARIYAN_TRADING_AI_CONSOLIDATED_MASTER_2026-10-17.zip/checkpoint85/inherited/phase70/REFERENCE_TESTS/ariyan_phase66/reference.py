"""Phase 66 isolated deterministic reference model; NOT production trading code."""
from dataclasses import dataclass
from threading import RLock
from hashlib import sha256
import json

REQUIRED=('adapter','policy','restriction','risk','capability','watermark','reconciliation','grant','revocation','trust')

@dataclass(frozen=True)
class Attestation:
    generations: tuple
    digest: str
    signature_valid: bool = True
    expires_at: int = 100
    scope: str = 'paper-order'

class Gate:
    def __init__(self):
        self.lock=RLock()
        self.epochs={k:0 for k in REQUIRED}
        self.available=True
        self.grant=True
        self.halted=False
        self.quarantined=False
        self.order_unknown=False
        self.events=[]

    def bump(self,key):
        with self.lock:
            self.epochs[key]+=1
            self.events.append(('bump',key,self.epochs[key]))

    def snapshot(self):
        return tuple((k,self.epochs[k]) for k in REQUIRED)

    def attest(self):
        with self.lock:
            s=self.snapshot()
            return Attestation(s,sha256(json.dumps(s,separators=(',',':')).encode()).hexdigest())

    def authorize(self,a,now=1,scope='paper-order',hook=None):
        with self.lock:
            if hook: hook(self)
            ok=(self.available and self.grant and not self.halted and not self.quarantined
                and not self.order_unknown and a.signature_valid and now<a.expires_at
                and scope==a.scope and a.generations==self.snapshot()
                and a.digest==sha256(json.dumps(a.generations,separators=(',',':')).encode()).hexdigest())
            self.events.append(('decision','ALLOW' if ok else 'BLOCK'))
            return ok

    def unknown_submission(self):
        with self.lock:
            self.order_unknown=True
            self.events.append(('reconcile_required',))
