import unittest
from dataclasses import replace
from reference import Gate

class Phase66(unittest.TestCase):
    def setUp(self):
        self.g=Gate(); self.a=self.g.attest()
    def blocked(self): self.assertFalse(self.g.authorize(self.a))
    def test_01_adapter_change(self): self.g.bump('adapter'); self.blocked()
    def test_02_policy_aba(self):
        self.g.bump('policy'); self.g.bump('policy'); self.blocked()
    def test_03_revocation_queued(self): self.g.grant=False; self.g.bump('revocation'); self.blocked()
    def test_04_capability_retry(self): self.g.bump('capability'); self.blocked()
    def test_05_partition(self): self.g.available=False; self.blocked()
    def test_06_fenced_race(self):
        self.assertFalse(self.g.authorize(self.a,hook=lambda gate:gate.bump('restriction')))
    def test_07_valid_signature_superseded(self):
        self.g.bump('risk'); self.assertTrue(self.a.signature_valid); self.blocked()
    def test_08_trust_rotation(self):
        self.g.bump('trust'); self.blocked()
    def test_09_unknown_submission(self):
        self.g.unknown_submission(); self.blocked(); self.assertIn(('reconcile_required',),self.g.events)
    def test_10_fanout_miss(self): self.g.quarantined=True; self.blocked()
    def test_11_watermark(self): self.g.bump('watermark'); self.blocked()
    def test_12_new_pass_no_grant(self):
        self.g.bump('policy'); fresh=self.g.attest(); self.g.grant=False
        self.assertFalse(self.g.authorize(fresh))
    def test_13_positive_control(self): self.assertTrue(self.g.authorize(self.a))
    def test_14_tampered_digest(self): self.assertFalse(self.g.authorize(replace(self.a,digest='0'*64)))
    def test_15_expiry(self): self.assertFalse(self.g.authorize(self.a,now=100))
    def test_16_scope(self): self.assertFalse(self.g.authorize(self.a,scope='live-order'))
    def test_17_emergency_halt(self): self.g.halted=True; self.blocked()

if __name__=='__main__': unittest.main(verbosity=2)
