import unittest,tempfile,multiprocessing
from pathlib import Path
from durable import Store

def contender(path,expected,q): q.put(Store(path).change('policy',expected))
class Phase67(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.path=str(Path(self.tmp.name)/'state.sqlite');self.s=Store(self.path)
 def tearDown(self):self.tmp.cleanup()
 def test_restart_retains_generation(self):
  a=self.s.attest();self.s.change('policy');other=Store(self.path)
  self.assertEqual(other.state()['generation'],1);self.assertFalse(other.authorize(a))
 def test_stale_cas_rejected(self):
  self.assertTrue(self.s.change('policy',0));self.assertFalse(self.s.change('risk',0))
 def test_aba_fenced(self):
  a=self.s.attest();self.s.change('policy');self.s.change('policy');self.assertFalse(self.s.authorize(a))
 def test_halt_persists(self):
  a=self.s.attest();self.s.set_flag('halted');self.assertFalse(Store(self.path).authorize(a))
 def test_unknown_order_persists(self):
  a=self.s.attest();self.s.set_flag('unknown_order');self.assertFalse(Store(self.path).authorize(a))
 def test_tampered_digest(self):
  a=self.s.attest();a['digest']='0'*64;self.assertFalse(self.s.authorize(a))
 def test_wrong_scope(self):self.assertFalse(self.s.authorize(self.s.attest(),'live-order'))
 def test_valid_reference_only(self):self.assertTrue(self.s.authorize(self.s.attest()))
 def test_two_process_cas_one_wins(self):
  q=multiprocessing.Queue();p=[multiprocessing.Process(target=contender,args=(self.path,0,q)) for _ in range(2)]
  for x in p:x.start()
  for x in p:x.join(10);self.assertEqual(x.exitcode,0)
  self.assertEqual(sorted([q.get(timeout=2),q.get(timeout=2)]),[False,True]);self.assertEqual(self.s.state()['generation'],1)
if __name__=='__main__':unittest.main(verbosity=2)
