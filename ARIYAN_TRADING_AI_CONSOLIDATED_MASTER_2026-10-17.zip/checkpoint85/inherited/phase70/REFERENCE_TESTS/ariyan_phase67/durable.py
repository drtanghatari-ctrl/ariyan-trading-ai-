"""Phase 67 simulated durable fencing. No trading connectivity or production authority."""
import sqlite3, json, hashlib
from pathlib import Path
KEYS=('adapter','policy','restriction','risk','capability','watermark','reconciliation','grant','revocation','trust')
def digest(x): return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':')).encode()).hexdigest()
class Store:
 def __init__(self,path):
  self.path=str(Path(path)); self.init()
 def db(self):
  c=sqlite3.connect(self.path,timeout=10,isolation_level=None)
  c.execute('PRAGMA busy_timeout=10000');c.execute('PRAGMA synchronous=FULL');return c
 def init(self):
  with self.db() as c:
   c.execute('PRAGMA journal_mode=WAL')
   c.execute('CREATE TABLE IF NOT EXISTS state(id INTEGER PRIMARY KEY CHECK(id=1), generation INTEGER NOT NULL, epochs TEXT NOT NULL, halted INTEGER NOT NULL, unknown_order INTEGER NOT NULL)')
   c.execute('INSERT OR IGNORE INTO state VALUES(1,0,?,0,0)',(json.dumps({k:0 for k in KEYS},sort_keys=True),))
 def state(self):
  with self.db() as c:
   g,e,h,u=c.execute('SELECT generation,epochs,halted,unknown_order FROM state WHERE id=1').fetchone()
   return {'generation':g,'epochs':json.loads(e),'halted':bool(h),'unknown_order':bool(u)}
 def attest(self):
  s=self.state();return {'generation':s['generation'],'digest':digest(s['epochs']),'scope':'paper-order'}
 def change(self,key,expected=None):
  if key not in KEYS:raise ValueError(key)
  with self.db() as c:
   c.execute('BEGIN IMMEDIATE')
   g,e=c.execute('SELECT generation,epochs FROM state WHERE id=1').fetchone()
   if expected is not None and g!=expected: c.execute('ROLLBACK');return False
   d=json.loads(e);d[key]+=1
   c.execute('UPDATE state SET generation=?,epochs=? WHERE id=1',(g+1,json.dumps(d,sort_keys=True)));c.execute('COMMIT');return True
 def set_flag(self,flag,value=True):
  if flag not in ('halted','unknown_order'):raise ValueError(flag)
  with self.db() as c:
   c.execute('BEGIN IMMEDIATE');c.execute(f'UPDATE state SET {flag}=? WHERE id=1',(int(value),));c.execute('COMMIT')
 def authorize(self,att,scope='paper-order'):
  with self.db() as c:
   c.execute('BEGIN IMMEDIATE')
   g,e,h,u=c.execute('SELECT generation,epochs,halted,unknown_order FROM state WHERE id=1').fetchone()
   ok=not(h or u) and att.get('generation')==g and att.get('digest')==digest(json.loads(e)) and att.get('scope')==scope
   c.execute('COMMIT');return bool(ok)
