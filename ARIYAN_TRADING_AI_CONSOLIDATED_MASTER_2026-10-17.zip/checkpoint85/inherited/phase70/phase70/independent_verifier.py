"""Phase 70 research-only signed attestation. Separate trust domains required in deployment."""
import json, pathlib, hashlib
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.exceptions import InvalidSignature
from audit_chain import canonical

class IndependentWitness:
    def __init__(self, key=None):
        self.__key=key or Ed25519PrivateKey.generate()
        self.public_key=self.__key.public_key()
        self.high_water=0
        self.last_digest='0'*64
    def issue(self, sequence, digest):
        if type(sequence) is not int or sequence < self.high_water or len(digest)!=64:
            raise ValueError('invalid or rollback request')
        if sequence==self.high_water and digest!=self.last_digest:
            raise ValueError('equivocation at same sequence')
        self.high_water=sequence; self.last_digest=digest
        statement={'version':1,'sequence':sequence,'digest':digest,'witness':'reference-witness'}
        signature=self.__key.sign(canonical(statement).encode()).hex()
        return {'statement':statement,'signature':signature}

def verify_signed(chain, attestation, public_key, minimum_sequence=0):
    try:
        statement=attestation['statement']
        if set(attestation)!={'statement','signature'} or set(statement)!={'version','sequence','digest','witness'}:return False
        if statement['version']!=1 or statement['witness']!='reference-witness':return False
        if type(statement['sequence']) is not int or statement['sequence']<minimum_sequence:return False
        public_key.verify(bytes.fromhex(attestation['signature']),canonical(statement).encode())
        if not chain.verify():return False
        row=chain.db.execute('SELECT seq,digest FROM events ORDER BY seq DESC LIMIT 1').fetchone()
        head=row if row else (0,'0'*64)
        return head==(statement['sequence'],statement['digest'])
    except (InvalidSignature,ValueError,KeyError,TypeError,AttributeError,OverflowError):return False
