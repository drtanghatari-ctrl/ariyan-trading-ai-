import unittest, tempfile, pathlib, json, sqlite3, sys
from audit_chain import canonical
from anchor import AnchoredChain
from independent_verifier import IndependentWitness,verify_signed
class Phase70Tests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.db=pathlib.Path(self.tmp.name)/'audit.db';self.chain=AnchoredChain(self.db);self.w=IndependentWitness();self.chain.append({'event':'authorize','id':1});self.a=self.w.issue(*self.chain.head())
 def tearDown(self):self.chain.close();self.tmp.cleanup()
 def test_valid(self):self.assertTrue(verify_signed(self.chain,self.a,self.w.public_key))
 def test_wrong_key(self):self.assertFalse(verify_signed(self.chain,self.a,IndependentWitness().public_key))
 def test_tampered_signature(self):
  a=json.loads(json.dumps(self.a));a['signature']='00'*64;self.assertFalse(verify_signed(self.chain,a,self.w.public_key))
 def test_tampered_statement(self):
  a=json.loads(json.dumps(self.a));a['statement']['sequence']=99;self.assertFalse(verify_signed(self.chain,a,self.w.public_key))
 def test_missing_attestation(self):self.assertFalse(verify_signed(self.chain,{},self.w.public_key))
 def test_unanchored_append(self):self.chain.append({'event':'new'});self.assertFalse(verify_signed(self.chain,self.a,self.w.public_key))
 def test_reanchor(self):self.chain.append({'event':'new'});a=self.w.issue(*self.chain.head());self.assertTrue(verify_signed(self.chain,a,self.w.public_key))
 def test_rollback_pin(self):self.assertFalse(verify_signed(self.chain,self.a,self.w.public_key,minimum_sequence=2))
 def test_witness_rejects_rollback(self):
  self.chain.append({'event':'new'});self.w.issue(*self.chain.head());
  with self.assertRaises(ValueError):self.w.issue(*tuple(self.a['statement'][k] for k in ('sequence','digest')))
 def test_witness_rejects_equivocation(self):
  with self.assertRaises(ValueError):self.w.issue(1,'a'*64)
 def test_truncate(self):
  self.chain.db.execute('DELETE FROM events');self.assertFalse(verify_signed(self.chain,self.a,self.w.public_key))
 def test_consistent_rewrite(self):
  self.chain.db.execute('DELETE FROM events');self.chain.append({'event':'forged','id':1});self.assertTrue(self.chain.verify());self.assertFalse(verify_signed(self.chain,self.a,self.w.public_key))
 def test_reopen(self):
  self.chain.close();self.chain=AnchoredChain(self.db);self.assertTrue(verify_signed(self.chain,self.a,self.w.public_key))
 def test_crash_before_append(self):
  self.chain.db.execute('BEGIN IMMEDIATE');self.chain.db.execute('INSERT INTO events VALUES (2,?,?,?)',('0'*64,'broken','broken'));self.chain.db.execute('ROLLBACK');self.assertTrue(verify_signed(self.chain,self.a,self.w.public_key))
 def test_corrupt_chain(self):
  self.chain.db.execute("UPDATE events SET payload='bad' WHERE seq=1");self.assertFalse(verify_signed(self.chain,self.a,self.w.public_key))
if __name__=='__main__':unittest.main(verbosity=2)
