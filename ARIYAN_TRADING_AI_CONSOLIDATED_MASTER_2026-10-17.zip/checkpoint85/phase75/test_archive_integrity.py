import json,pathlib,tempfile,unittest,zipfile,warnings
from archive_integrity import verify_package,package_directory,MANIFEST,sha

class ArchiveTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=pathlib.Path(self.tmp.name)
        self.src=self.root/'src';self.src.mkdir();(self.src/'one.txt').write_text('unchanged source\n')
        self.zip=self.root/'good.zip';package_directory(self.src,self.zip)
    def tearDown(self):self.tmp.cleanup()
    def mutate(self,members):
        p=self.root/'bad.zip'
        with warnings.catch_warnings():
            warnings.simplefilter('ignore',UserWarning)
            with zipfile.ZipFile(p,'w') as z:
                for name,value in members:z.writestr(name,value)
        return p
    def test_valid(self):self.assertEqual(verify_package(self.zip)['files_verified'],1)
    def test_deterministic_rebuild(self):
        other=self.root/'again.zip';package_directory(self.src,other)
        self.assertEqual(self.zip.read_bytes(),other.read_bytes())
    def test_external_hash_pin(self):self.assertTrue(verify_package(self.zip,sha(self.zip.read_bytes()))['external_hash_matched'])
    def test_wrong_external_hash(self):
        with self.assertRaises(ValueError):verify_package(self.zip,'0'*64)
    def test_tampered_member(self):
        with zipfile.ZipFile(self.zip) as z:manifest=z.read(MANIFEST)
        with self.assertRaises(ValueError):verify_package(self.mutate([('one.txt','changed'),(MANIFEST,manifest)]))
    def test_unlisted_extra(self):
        with zipfile.ZipFile(self.zip) as z:members=[(n,z.read(n)) for n in z.namelist()]
        with self.assertRaises(ValueError):verify_package(self.mutate(members+[('extra.txt','extra')]))
    def test_missing_member(self):
        with zipfile.ZipFile(self.zip) as z:manifest=z.read(MANIFEST)
        with self.assertRaises(ValueError):verify_package(self.mutate([(MANIFEST,manifest)]))
    def test_missing_manifest(self):
        with self.assertRaises(ValueError):verify_package(self.mutate([('one.txt','hello')]))
    def test_duplicate_entry(self):
        with self.assertRaises(ValueError):verify_package(self.mutate([('one.txt','a'),('one.txt','b'),(MANIFEST,'{}')]))
    def test_case_collisions(self):
        with self.assertRaises(ValueError):verify_package(self.mutate([('One.txt','a'),('one.txt','b'),(MANIFEST,'{}')]))
    def test_unsafe_paths_matrix(self):
        for name in ['../outside','/absolute','x/../outside','x\\outside','C:outside','a//b','a/./b','CON.txt','LPT1','name.']:
            with self.subTest(name=name):
                with self.assertRaises(ValueError):verify_package(self.mutate([(name,'a'),(MANIFEST,'{}')]))
    def test_duplicate_manifest_keys(self):
        raw='{"version":1,"version":1,"files":{}}'
        with self.assertRaises(ValueError):verify_package(self.mutate([(MANIFEST,raw)]))
    def test_no_authenticity_claim(self):self.assertFalse(verify_package(self.zip)['independent_authenticity_established'])

if __name__=='__main__':unittest.main(verbosity=2)
