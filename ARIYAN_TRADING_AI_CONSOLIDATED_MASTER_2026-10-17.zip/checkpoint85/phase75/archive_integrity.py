"""Deterministic offline packaging and bounded ZIP integrity checks; no authenticity claim."""
import hashlib
import json
import pathlib
import re
import stat
import zipfile
import sys
MAX_TOTAL=128*1024*1024
MAX_FILE=16*1024*1024
MAX_ENTRIES=1000
MANIFEST='SHA256_MANIFEST.json'

def sha(raw): return hashlib.sha256(raw).hexdigest()

def safe_name(name):
    if type(name) is not str or not name or '\\' in name or ':' in name or '\x00' in name or name.startswith('/'):
        raise ValueError('unsafe archive path')
    for part in name.split('/'):
        if part in ('','.','..') or part.endswith(('.', ' ')):
            raise ValueError('unsafe archive component')
        if part.split('.')[0].upper() in {'CON','PRN','AUX','NUL',*[f'COM{i}' for i in range(1,10)],*[f'LPT{i}' for i in range(1,10)]}:
            raise ValueError('Windows reserved archive name')
    return name

def strict_object(pairs):
    result={}
    for key,value in pairs:
        if key in result: raise ValueError('duplicate manifest key')
        result[key]=value
    return result

def verify_package(path, expected_archive_sha256=None):
    p=pathlib.Path(path)
    if p.stat().st_size>MAX_TOTAL:raise ValueError('compressed archive size limit')
    archive_sha=sha(p.read_bytes())
    if expected_archive_sha256 is not None and archive_sha!=expected_archive_sha256:
        raise ValueError('external archive hash mismatch')
    with zipfile.ZipFile(p) as z:
        infos=z.infolist()
        if len(infos)>MAX_ENTRIES:raise ValueError('entry count limit')
        names=[safe_name(x.filename) for x in infos]
        if len(set(names))!=len(names) or len({n.casefold() for n in names})!=len(names):
            raise ValueError('duplicate/case-colliding archive path')
        if MANIFEST not in names:raise ValueError('missing manifest')
        total=0
        for info in infos:
            total+=info.file_size
            if info.file_size>MAX_FILE or total>MAX_TOTAL or info.flag_bits&1 or stat.S_ISLNK(info.external_attr>>16):
                raise ValueError('resource limit, encryption or symlink')
        manifest=json.loads(z.read(MANIFEST),object_pairs_hook=strict_object)
        if type(manifest) is not dict or set(manifest)!={'version','files'} or type(manifest['version']) is not int or manifest['version']!=1 or type(manifest['files']) is not dict:
            raise ValueError('manifest schema')
        expected=manifest['files']
        if set(expected)!=set(names)-{MANIFEST}:raise ValueError('unlisted or missing archive files')
        for name,value in expected.items():
            safe_name(name)
            if type(value) is not str or re.fullmatch('[0-9a-f]{64}',value) is None or sha(z.read(name))!=value:
                raise ValueError('member SHA256 mismatch')
    return {'files_verified':len(expected),'archive_sha256':archive_sha,'external_hash_matched':expected_archive_sha256 is not None,'independent_authenticity_established':False}

def package_directory(directory,destination):
    root=pathlib.Path(directory)
    files={}
    for p in sorted(root.rglob('*')):
        if p.is_symlink():raise ValueError('symlink input')
        if p.is_file() and '__pycache__' not in p.parts:
            name=safe_name(p.relative_to(root).as_posix())
            if name!=MANIFEST:files[name]=p.read_bytes()
    manifest={'version':1,'files':{name:sha(raw) for name,raw in files.items()}}
    files[MANIFEST]=(json.dumps(manifest,sort_keys=True,indent=2)+'\n').encode()
    with zipfile.ZipFile(destination,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,raw in sorted(files.items()):
            info=zipfile.ZipInfo(name,date_time=(2026,10,17,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
            info.create_system=3;info.external_attr=0o100644<<16
            z.writestr(info,raw,compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    return verify_package(destination)

if __name__=='__main__':
    if len(sys.argv) not in (2,3):raise SystemExit('Usage: python archive_integrity.py ZIP [TRUSTED_SHA256]')
    print(json.dumps(verify_package(*sys.argv[1:]),indent=2))
