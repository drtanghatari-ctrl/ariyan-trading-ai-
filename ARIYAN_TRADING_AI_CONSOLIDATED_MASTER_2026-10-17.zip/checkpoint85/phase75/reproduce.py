"""Rerun all retained reference suites from the flat master, keeping sources immutable."""
import json,os,pathlib,re,subprocess,sys
root=pathlib.Path(__file__).resolve().parents[1]
out=pathlib.Path(sys.argv[1]).resolve() if len(sys.argv)>1 else root/'rerun_evidence'
out.mkdir(parents=True,exist_ok=True)
results=[]
for phase in range(66,76):
 if phase<=69:folder=root/'inherited/phase70/REFERENCE_TESTS'/('ariyan_phase'+str(phase))
 elif phase==70:folder=root/'inherited/phase70/phase70'
 elif phase<73:folder=root/'inherited'/('phase'+str(phase))
 else:folder=root/('phase'+str(phase))
 env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1')
 paths=[str(root/'phase73')]
 if phase==70:paths += [str(root/'inherited/phase70/REFERENCE_TESTS'/('ariyan_phase'+str(n))) for n in (68,69)]
 env['PYTHONPATH']=os.pathsep.join(paths)
 run=subprocess.run([sys.executable,'-B','-m','unittest','discover','-v'],cwd=folder,env=env,capture_output=True,text=True,timeout=90)
 log=run.stdout+run.stderr;(out/f'phase{phase}.txt').write_text(log)
 count=re.search(r'Ran (\d+) tests?',log)
 results.append({'phase':phase,'returncode':run.returncode,'methods':int(count[1]) if count else None})
(out/'summary.json').write_text(json.dumps(results,indent=2))
print(json.dumps(results,indent=2))
if any(r['returncode'] for r in results):raise SystemExit(1)
