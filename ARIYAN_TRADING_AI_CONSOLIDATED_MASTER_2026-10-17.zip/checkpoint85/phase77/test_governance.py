import copy,pathlib,tempfile,unittest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.exceptions import InvalidSignature
from rotation import raw_public,connect,Rejected,ZERO
from governance import Governance,initial,proposal,approve,transition,validate_policy

class GovernanceTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.path=pathlib.Path(self.tmp.name)/'a';db=connect(self.path);db.close()
        self.keys={n:Ed25519PrivateKey.generate() for n in ('one','two','three')}
        self.policy={'tenant':'test','witness':'w','approvers':{n:raw_public(k) for n,k in self.keys.items()},'quorum':2}
        self.g=Governance.provision(self.path,self.policy);self.now=100
    def tearDown(self):self.g.close();self.tmp.cleanup()
    def command(self,action='freeze',params=None,names=('one','two'),possession=None,expires=200):
        if params is None:params={'reason_hash':'a'*64}
        b=proposal(self.policy,self.g.snapshot(),action,params,self.now,expires)
        return approve(b,{n:self.keys[n] for n in names},possession)
    def freeze(self):self.g.apply(self.command(names=('one',)),self.now)
    def test_one_authorized_approver_can_freeze(self):
        self.freeze();self.assertTrue(self.g.snapshot()['frozen'])
    def test_resume_requires_quorum(self):
        self.freeze();e=self.command('resume',{'reconciliation_hash':'b'*64,'checkpoint_head':ZERO},names=('one',))
        with self.assertRaises(Rejected):self.g.apply(e,self.now)
    def test_quorum_resume(self):
        self.freeze();self.g.apply(self.command('resume',{'reconciliation_hash':'b'*64,'checkpoint_head':ZERO}),self.now)
        self.assertFalse(self.g.snapshot()['frozen'])
    def test_revocation_is_permanent_in_this_model(self):
        self.g.apply(self.command('revoke_client'),self.now)
        with self.assertRaises(Rejected):self.g.apply(self.command('resume',{'reconciliation_hash':'b'*64,'checkpoint_head':ZERO}),self.now)
    def test_root_nomination_remains_quarantined(self):
        self.freeze();key=Ed25519PrivateKey.generate();root=raw_public(key)
        self.g.apply(self.command('nominate_root',{'new_root':root,'recovery_evidence_hash':'b'*64},possession=key),self.now)
        state=self.g.snapshot();self.assertTrue(state['frozen']);self.assertEqual(state['candidate_root'],root)
        with self.assertRaises(Rejected):self.g.apply(self.command('resume',{'reconciliation_hash':'b'*64,'checkpoint_head':ZERO}),self.now)
    def test_nomination_requires_freeze(self):
        key=Ed25519PrivateKey.generate()
        with self.assertRaises(Rejected):self.g.apply(self.command('nominate_root',{'new_root':raw_public(key),'recovery_evidence_hash':'b'*64},possession=key),self.now)
    def test_nomination_requires_possession(self):
        self.freeze();key=Ed25519PrivateKey.generate()
        with self.assertRaises(Rejected):self.g.apply(self.command('nominate_root',{'new_root':raw_public(key),'recovery_evidence_hash':'b'*64}),self.now)
    def test_nomination_wrong_possession(self):
        self.freeze();key=Ed25519PrivateKey.generate()
        with self.assertRaises(InvalidSignature):self.g.apply(self.command('nominate_root',{'new_root':raw_public(key),'recovery_evidence_hash':'b'*64},possession=Ed25519PrivateKey.generate()),self.now)
    def test_forged_approval(self):
        e=self.command();e['approvals']['one']='0'*128
        with self.assertRaises(InvalidSignature):self.g.apply(e,self.now)
    def test_approver_aliases_do_not_make_quorum(self):
        p=copy.deepcopy(self.policy);p['approvers']['two']=p['approvers']['one']
        with self.assertRaises(Rejected):validate_policy(p)
    def test_unknown_approver(self):
        e=self.command();e['approvals']['outsider']='0'*128
        with self.assertRaises(Rejected):self.g.apply(e,self.now)
    def test_stale_governance_cas(self):
        one=self.command();two=self.command();self.g.apply(one,self.now)
        with self.assertRaises(Rejected):self.g.apply(two,self.now)
    def test_cross_scope(self):
        e=self.command();e['proposal']['tenant']='other';e=approve(e['proposal'],self.keys)
        with self.assertRaises(Rejected):self.g.apply(e,self.now)
    def test_expired_proposal(self):
        with self.assertRaises(Rejected):self.g.apply(self.command(expires=101),101)
    def test_future_proposal(self):
        with self.assertRaises(Rejected):self.g.apply(self.command(),99)
    def test_clock_rollback(self):
        self.freeze();self.now=99
        with self.assertRaises(Rejected):self.g.apply(self.command(),99)
    def test_idempotent_ack_loss_retry(self):
        e=self.command()
        def fault(stage):
            if stage=='governance_after_commit':raise TimeoutError()
        with self.assertRaises(TimeoutError):self.g.apply(e,self.now,fault)
        self.assertTrue(self.g.apply(e,self.now)['already_committed']);self.assertEqual(self.g.snapshot()['epoch'],2)
    def test_before_commit_storage_error_rollback(self):
        e=self.command()
        def fault(stage):
            if stage=='governance_before_commit':raise OSError()
        with self.assertRaises(OSError):self.g.apply(e,self.now,fault)
        self.assertEqual(self.g.snapshot()['epoch'],1)
    def test_reopen_verifies_approval_history(self):
        self.freeze();self.g.close();self.g=Governance(self.path,self.policy);self.assertTrue(self.g.snapshot()['frozen'])
    def test_unsupported_auto_root_activation(self):
        with self.assertRaises(Rejected):self.g.apply(self.command('activate_root',{}),self.now)
    def test_invalid_boolean_epoch(self):
        e=self.command();e['proposal']['expected_epoch']=True;e=approve(e['proposal'],self.keys)
        with self.assertRaises(Rejected):self.g.apply(e,self.now)
    def test_resume_evidence_has_exact_schema(self):
        self.freeze()
        with self.assertRaises(Rejected):self.g.apply(self.command('resume',{'reconciliation_hash':'b'*64}),self.now)

if __name__=='__main__':unittest.main(verbosity=2)
