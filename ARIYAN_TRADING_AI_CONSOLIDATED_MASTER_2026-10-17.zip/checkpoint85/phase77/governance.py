"""Signed quorum governance for OFFLINE reference checkpoint services.
Approver keys are test fixtures, not verified human identities. A proposed new
root remains quarantined; this code never self-activates a replacement root.
"""
import json,pathlib,uuid
from rotation import canonical,digest,hexfield,integer,Rejected,ZERO,connect,transaction,raw_public
from checkpoint import exact,label,verify_signature
DOMAIN='ARIYAN-GOVERNANCE-v1'

def validate_policy(policy):
    exact(policy,('tenant','witness','approvers','quorum'))
    label(policy['tenant']);label(policy['witness'])
    if type(policy['approvers']) is not dict or len(policy['approvers'])<3:raise Rejected('at least three pinned approvers required')
    for name,pub in policy['approvers'].items():label(name);hexfield(pub,64)
    if len(set(policy['approvers'].values()))!=len(policy['approvers']):raise Rejected('approver key aliases')
    integer(policy['quorum'],2)
    if policy['quorum']>len(policy['approvers']):raise Rejected('unreachable quorum')

def initial(policy):
    validate_policy(policy)
    return {'epoch':1,'head':ZERO,'frozen':False,'revoked':False,'candidate_root':'','last_time':0}

def proposal(policy,state,action,params,issued_at,expires_at,op=None):
    return {'domain':DOMAIN,'tenant':policy['tenant'],'witness':policy['witness'],'op':op or uuid.uuid4().hex,
            'expected_epoch':state['epoch'],'previous':state['head'],'action':action,'params':params,'issued_at':issued_at,'expires_at':expires_at}

def approve(body,keys,possession=None):
    return {'proposal':body,'approvals':{name:key.sign(canonical(body)).hex() for name,key in keys.items()},'possession':possession.sign(canonical(body)).hex() if possession is not None else ''}

def transition(policy,state,envelope,now):
    exact(envelope,('proposal','approvals','possession'));b=envelope['proposal']
    exact(b,('domain','tenant','witness','op','expected_epoch','previous','action','params','issued_at','expires_at'))
    if (b['domain'],b['tenant'],b['witness'])!=(DOMAIN,policy['tenant'],policy['witness']):raise Rejected('governance scope')
    hexfield(b['op'],32);hexfield(b['previous'],64);integer(b['expected_epoch'],1);integer(b['issued_at']);integer(b['expires_at']);integer(now)
    if (b['expected_epoch'],b['previous'])!=(state['epoch'],state['head']):raise Rejected('stale governance CAS')
    if b['expires_at']<=b['issued_at'] or b['expires_at']-b['issued_at']>3600 or not b['issued_at']<=now<b['expires_at'] or now<state['last_time']:
        raise Rejected('governance time window/clock rollback')
    approvals=envelope['approvals']
    if type(approvals) is not dict or not approvals or any(name not in policy['approvers'] for name in approvals):raise Rejected('unknown approver')
    for name,signature in approvals.items():verify_signature(policy['approvers'][name],b,signature)
    action=b['action'];params=b['params'];new=dict(state)
    required=1 if action=='freeze' else policy['quorum']
    if len(approvals)<required:raise Rejected('quorum absent')
    if action=='freeze':
        exact(params,('reason_hash',));hexfield(params['reason_hash'],64);new['frozen']=True
    elif action=='revoke_client':
        exact(params,('reason_hash',));hexfield(params['reason_hash'],64);new['revoked']=True;new['frozen']=True
    elif action=='resume':
        exact(params,('reconciliation_hash','checkpoint_head'))
        for name in params:hexfield(params[name],64)
        if not state['frozen'] or state['revoked'] or state['candidate_root']:raise Rejected('cannot resume quarantined/revoked identity')
        new['frozen']=False
    elif action=='nominate_root':
        exact(params,('new_root','recovery_evidence_hash'))
        for name in params:hexfield(params[name],64)
        if not state['frozen'] or state['candidate_root']:raise Rejected('freeze before root nomination; no replacement of pending proposal')
        verify_signature(params['new_root'],b,envelope['possession'])
        new['candidate_root']=params['new_root']
    else:raise Rejected('unsupported governance action')
    if action!='nominate_root' and envelope['possession']!='':raise Rejected('unexpected possession proof')
    new.update(epoch=state['epoch']+1,head=digest(envelope),last_time=now)
    return new

class Governance:
    """Can share the Authority SQLite DB to serialize governance and submissions."""
    @classmethod
    def provision(cls,path,policy):
        validate_policy(policy)
        if not pathlib.Path(path).is_file():raise Rejected('provision into existing reference authority DB')
        db=connect(path)
        try:
            with transaction(db):
                if db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='governance_identity'").fetchone():raise Rejected('governance already provisioned')
                db.execute('CREATE TABLE governance_identity(policy TEXT NOT NULL)')
                db.execute('CREATE TABLE governance_events(n INTEGER PRIMARY KEY,op TEXT UNIQUE NOT NULL,accepted_at INTEGER NOT NULL,envelope TEXT NOT NULL)')
                db.execute('INSERT INTO governance_identity VALUES(?)',(canonical(policy).decode(),))
        finally:db.close()
        return cls(path,policy)
    def __init__(self,path,policy):
        validate_policy(policy)
        if not pathlib.Path(path).is_file():raise Rejected('missing governance store')
        self.policy=policy;self.db=connect(path)
        try:
            with transaction(self.db):self.read_from(self.db,self.policy)
        except BaseException:self.close();raise
    @staticmethod
    def read_from(db,policy):
        if db.execute('SELECT policy FROM governance_identity').fetchall()!=[(canonical(policy).decode(),)]:raise Rejected('governance policy pin')
        state=initial(policy);seen=set()
        for n,op,accepted_at,raw in db.execute('SELECT n,op,accepted_at,envelope FROM governance_events ORDER BY n'):
            e=json.loads(raw)
            if n!=state['epoch'] or op!=e['proposal']['op'] or op in seen:raise Rejected('governance log gap/substitution')
            seen.add(op);state=transition(policy,state,e,accepted_at)
        return state
    def snapshot(self):
        with transaction(self.db):return self.read_from(self.db,self.policy)
    def apply(self,envelope,now,hook=lambda _:None):
        # Domain and signature checks also run on a historical retry before returning success.
        exact(envelope,('proposal','approvals','possession'));op=envelope['proposal']['op'];hexfield(op,32)
        with transaction(self.db):
            state=self.read_from(self.db,self.policy)
            old=self.db.execute('SELECT envelope FROM governance_events WHERE op=?',(op,)).fetchone()
            if old:
                if old[0]!=canonical(envelope).decode():raise Rejected('governance operation substitution')
                return {'already_committed':True,'current':state}
            new=transition(self.policy,state,envelope,now)
            self.db.execute('INSERT INTO governance_events VALUES(?,?,?,?)',(state['epoch'],op,now,canonical(envelope).decode()))
            hook('governance_before_commit')
        hook('governance_after_commit')
        return {'already_committed':False,'current':new}
    def close(self):self.db.close()
