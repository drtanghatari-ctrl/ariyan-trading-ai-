"""Read-only structural index. Candidates are not semantic certification.
Never synthesize numbered clauses from grouped headings or correct source text.
"""
import collections,hashlib,json,pathlib,re
SINGLE=re.compile(r'^\s*(?:(SECTION)\s+)?(\d{1,5})(?![\d.])\s*(?:[—–:-]|\.\s+)(?:\s*)(.+?)\s*$',re.I)
GROUP=re.compile(r'^\s*(?:SECTIONS?\s+)?(\d{1,5})\s*[–—-]\s*(\d{1,5})(?:\s|[—–:.-]|$)(.*)$',re.I)
NORM=re.compile(r'\b(?:SHALL|MUST|MUST NOT|SHALL NOT)\b')

def scan_source(raw,source_id,expected_sha):
    actual=hashlib.sha256(raw).hexdigest()
    if actual!=expected_sha:raise ValueError('source hash mismatch')
    text=raw.decode('utf-8');singles=[];groups=[];obligations=[]
    for line_no,line in enumerate(text.splitlines(),1):
        detected=re.sub(r'^\s*#{1,6}\s+','',line)
        # ISO date examples are not inverted section ranges.
        if re.match(r'^\s*\d{4}-\d{2}-\d{2}(?:\s|$)',detected):
            continue
        # Group recognition precedes single recognition; ranges must never become single headings.
        g=GROUP.match(detected)
        if g:
            a,b=int(g[1]),int(g[2])
            groups.append({'source':source_id,'line':line_no,'start':a,'end':b,'inverted':a>b,'text':line,'candidate_only':True})
        else:
            s=SINGLE.match(detected)
            if s:
                n=int(s[2]);singles.append({'source':source_id,'line':line_no,'number':n,'text':line,'explicit_section_prefix':s[1] is not None,'candidate_only':True})
        if NORM.search(line):
            obligations.append({'source':source_id,'line':line_no,'text':line,'sha256':hashlib.sha256(line.encode()).hexdigest(),'review':'NOT_ASSESSED'})
    return {'source':source_id,'sha256':actual,'lines':len(text.splitlines()),'singles':singles,'groups':groups,'obligations':obligations}

def build(source_directory,rows,output):
    output=pathlib.Path(output);output.mkdir(parents=True,exist_ok=True)
    scans=[]
    for row in rows:
        p=pathlib.Path(source_directory)/(f"{row['id']:02}.txt")
        scans.append(scan_source(p.read_bytes(),row['id'],row['sha256']))
    singles=[x for s in scans for x in s['singles']];groups=[x for s in scans for x in s['groups']]
    obligations=[x for s in scans for x in s['obligations']]
    by_number=collections.defaultdict(list)
    for x in singles:
        if 0<=x['number']<=15200:by_number[x['number']].append(x)
    grouped=set()
    for x in groups:
        if not x['inverted']:grouped.update(range(max(1,x['start']),min(15200,x['end'])+1))
    coverage=[]
    for n in range(1,15201):
        status='SINGLE_HEADING_CANDIDATE' if n in by_number else 'GROUP_LABEL_ONLY' if n in grouped else 'NO_HEADING_CANDIDATE'
        coverage.append({'section':n,'structural_status':status,'single_occurrences':len(by_number[n]),'semantic_acceptance':'NOT_ASSESSED','production_mapping':'NOT_ASSESSED'})
    dup={str(n):hits for n,hits in by_number.items() if len(hits)>1}
    by_clause=collections.defaultdict(list)
    for row in obligations:by_clause[row['sha256']].append(row)
    repeated=[{'sha256':k,'occurrences':[{'source':r['source'],'line':r['line']} for r in v],'text':v[0]['text']} for k,v in by_clause.items() if len(v)>1]
    counts=dict(collections.Counter(r['structural_status'] for r in coverage))
    result={'source_count':len(rows),'numbering_denominator':15200,'section_zero_is_continuity_marker_not_in_denominator':True,'heading_candidates':len(singles),'group_candidates':len(groups),'number_classification':counts,'duplicate_number_candidates':len(dup),'inverted_group_candidates':[r for r in groups if r['inverted']],'normative_line_candidates':len(obligations),'exact_repeated_normative_lines':len(repeated),'semantic_sections_certified':0,'exhaustive_semantic_review':False,'limitations':['Headings and numbered list items can be ambiguous; all records are candidates.','Group/tranche headings are not individual clauses or evidence of missing/complete behavior.','Exact duplicate lines are textual evidence, not normative supersession.','No source or numbering is rewritten.']}
    for name,obj in [('SUMMARY.json',result),('heading_candidates.json',singles),('group_candidates.json',groups),('section_registry.json',coverage),('duplicate_numbers.json',dup),('normative_candidates.json',obligations),('exact_clause_repetitions.json',repeated)]:
        (output/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
    return result

if __name__=='__main__':
    import sys
    root=pathlib.Path(sys.argv[1]);out=pathlib.Path(sys.argv[2]);rows=json.loads((root/'evidence/source_index.json').read_text())
    print(json.dumps(build(root/'historical_sources',rows,out),indent=2))
