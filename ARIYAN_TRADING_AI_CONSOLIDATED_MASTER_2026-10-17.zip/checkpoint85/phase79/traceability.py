"""Inventory test methods and candidate related closure evidence; no conformance promotion."""
import ast,json,pathlib,re

def build_trace(root,out):
    root=pathlib.Path(root);out=pathlib.Path(out);out.mkdir(parents=True,exist_ok=True)
    modules=[]
    for phase in range(66,81):
        folder=root/'inherited/phase70/REFERENCE_TESTS'/f'ariyan_phase{phase}' if phase<70 else root/'inherited/phase70/phase70' if phase==70 else root/'inherited'/f'phase{phase}' if phase<73 else root/f'phase{phase}'
        for path in sorted(folder.glob('test_*.py')):
            tree=ast.parse(path.read_text())
            for node in tree.body:
                if isinstance(node,ast.ClassDef):
                    for f in node.body:
                        if isinstance(f,ast.FunctionDef) and f.name.startswith('test_'):
                            modules.append({'phase':phase,'file':str(path.relative_to(root)),'class':node.name,'method':f.name,'line':f.lineno,'production_conformance':'NOT_ESTABLISHED'})
    src=root/'historical_sources/27.txt';lines=src.read_text().splitlines();source_hash=__import__('hashlib').sha256(src.read_bytes()).hexdigest()
    selected={0:['phase77/governance.py','phase78/control_plane.py'],4:['phase76/checkpoint.py','phase78/control_plane.py'],9:['phase74/test_adversarial.py','phase78/test_control_plane.py'],20:['phase73/rotation.py','phase78/test_control_plane.py'],22:['phase73/rotation.py','phase77/governance.py'],23:['phase76/checkpoint.py','phase77/governance.py','phase78/control_plane.py'],24:['phase75/archive_integrity.py','phase79/source_audit.py']}
    closure=[]
    for line_no,line in enumerate(lines,1):
        m=re.match(r'^(1[45]\d{3}) — (.+)$',line)
        if m and 14701<=int(m[1])<=15200:
            n=int(m[1]);related=selected.get((n-14701)//20,[])
            closure.append({'section':n,'source':27,'source_sha256':source_hash,'line':line_no,'heading':line,'candidate_related_reference_artifacts':related,'relationship':'TOPIC_ONLY_NOT_CONFORMANCE','canonical_earlier_source_map':'NOT_VERIFIED','responsible_human_owner':None,'independent_reviewer':None,'production_implementation':'NOT_VERIFIED','acceptance':'NOT_ASSESSED','blocking':True})
    if len(closure)!=500:raise ValueError('closure heading extraction did not produce exactly 500 source records')
    (out/'test_method_inventory.json').write_text(json.dumps(modules,indent=2)+'\n')
    (out/'closure_500_evidence_ledger.json').write_text(json.dumps(closure,ensure_ascii=False,indent=2)+'\n')
    return {'methods_indexed':len(modules),'closure_source_records':len(closure),'accepted_closure_contracts':0,'independently_verified_source_maps':0}

if __name__=='__main__':
    import sys
    print(json.dumps(build_trace(sys.argv[1],sys.argv[2]),indent=2))
