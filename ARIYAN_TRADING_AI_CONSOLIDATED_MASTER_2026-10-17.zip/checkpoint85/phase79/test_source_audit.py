import hashlib,json,pathlib,tempfile,unittest
from source_audit import scan_source,build

class SourceIndexTests(unittest.TestCase):
    def scan(self,text):
        raw=text.encode();return scan_source(raw,7,hashlib.sha256(raw).hexdigest())
    def test_explicit_section_heading(self):
        s=self.scan('SECTION 3000 — CAPITAL AUTHORITY\nThe model MUST NOT authorize.\n')
        self.assertEqual(s['singles'][0]['number'],3000);self.assertTrue(s['singles'][0]['explicit_section_prefix']);self.assertEqual(s['obligations'][0]['line'],2)
    def test_bare_heading_candidate_not_certified(self):
        s=self.scan('14701 — Human authority\n');self.assertTrue(s['singles'][0]['candidate_only'])
    def test_group_does_not_synthesize_singles(self):
        s=self.scan('SECTIONS 5991–5999\n');self.assertEqual(s['singles'],[]);self.assertEqual(s['groups'][0]['end'],5999)
    def test_inverted_range_retained(self):
        s=self.scan('Sections 371–370\n');self.assertTrue(s['groups'][0]['inverted'])
    def test_decimal_subclause_not_individual_section(self):
        s=self.scan('3000.2 Capital Authority Object\n');self.assertEqual(s['singles'],[])
    def test_source_hash_mismatch_rejected(self):
        with self.assertRaises(ValueError):scan_source(b'changed',1,'0'*64)
    def test_iso_dates_are_not_section_ranges(self):
        s=self.scan('2026-01-01 → FAILED\n2026-01-05 → PASSED\n')
        self.assertEqual(s['groups'],[]);self.assertEqual(s['singles'],[])
    def test_markdown_headings_are_detected_without_rewriting(self):
        line='### Section 6601 — Explicit lifecycle'
        s=self.scan(line+'\n### Sections 6601–6700\n')
        self.assertEqual(s['singles'][0]['number'],6601)
        self.assertEqual(s['singles'][0]['text'],line)
        self.assertEqual(s['groups'][0]['end'],6700)
    def test_no_silent_number_correction(self):
        text='Sections 371–370\n';s=self.scan(text);self.assertEqual(s['groups'][0]['text'],text.rstrip())
    def test_registry_denominator_and_duplicate_candidates(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=pathlib.Path(tmp);raw=b'SECTIONS 1-3\nSECTION 1 - One\nSECTION 1 - Again\n'
            (root/'01.txt').write_bytes(raw);rows=[{'id':1,'sha256':hashlib.sha256(raw).hexdigest()}]
            r=build(root,rows,root/'out');registry=json.loads((root/'out/section_registry.json').read_text())
            self.assertEqual(len(registry),15200);self.assertEqual(r['duplicate_number_candidates'],1)
            self.assertEqual(registry[1]['structural_status'],'GROUP_LABEL_ONLY');self.assertEqual(registry[3]['structural_status'],'NO_HEADING_CANDIDATE')
            self.assertEqual(r['semantic_sections_certified'],0)
    def test_exact_repeated_normative_lines_preserved(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=pathlib.Path(tmp);raw=b'A MUST remain closed.\nA MUST remain closed.\n'
            (p/'01.txt').write_bytes(raw);r=build(p,[{'id':1,'sha256':hashlib.sha256(raw).hexdigest()}],p/'out')
            self.assertEqual(r['exact_repeated_normative_lines'],1)

if __name__=='__main__':unittest.main(verbosity=2)
