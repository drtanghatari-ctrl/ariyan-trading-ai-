"""Bounded, fail-closed verification of OFFLINE reference evidence, not authorization."""
import json
from rotation import DOMAIN, verify_history
MAX_BYTES = 8 * 1024 * 1024
MAX_EVENTS = 10000

def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('duplicate JSON key')
        result[key] = value
    return result

def verify_export(raw, pinned_root, trusted_floor, expected_head):
    """Pin/floor/head are caller-owned inputs, never learned from this packet.
    A successful result proves consistency only with those inputs, not freshness,
    human authority, external custody isolation, or permission for any action.
    """
    try:
        if type(raw) is not bytes or not 0 < len(raw) <= MAX_BYTES:
            raise ValueError('evidence size/type')
        obj = json.loads(raw.decode('utf-8'), object_pairs_hook=unique_object,
                         parse_constant=lambda _: (_ for _ in ()).throw(ValueError('nonfinite JSON')))
        if type(obj) is not dict or set(obj) != {'version', 'domain', 'events'}:
            raise ValueError('export schema')
        if type(obj['version']) is not int or obj['version'] != 1 or obj['domain'] != DOMAIN:
            raise ValueError('export domain/version')
        if type(obj['events']) is not list or len(obj['events']) > MAX_EVENTS:
            raise ValueError('event count/type')
        if trusted_floor is None or type(expected_head) is not tuple or len(expected_head) != 2:
            raise ValueError('caller-owned floor and exact head required')
        state = verify_history(obj['events'], pinned_root, trusted_floor)
        if type(expected_head[0]) is not int or (state['index'], state['head']) != expected_head:
            raise ValueError('unexpected head')
        return {'evidence_verified': True, 'state': state, 'financial_authority': False}
    except Exception as exc:
        return {'evidence_verified': False, 'error_type': type(exc).__name__, 'financial_authority': False}
