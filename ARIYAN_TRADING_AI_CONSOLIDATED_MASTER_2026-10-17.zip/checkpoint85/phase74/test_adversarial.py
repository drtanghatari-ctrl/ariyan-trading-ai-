import copy
import json
import multiprocessing
import pathlib
import random
import sqlite3
import tempfile
import unittest
from cryptography.exceptions import InvalidSignature
from rotation import CustodianFixture, Witness, Rejected, DOMAIN, ZERO, verify_history, digest, canonical
from evidence_verifier import verify_export, MAX_BYTES, MAX_EVENTS
from race_worker import run

class AdversarialTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.path = pathlib.Path(self.tmp.name)
        self.cp = self.path/'c'; self.wp = self.path/'w'
        self.c,self.root = CustodianFixture.create(self.cp)
        self.w = Witness.create(self.wp,self.c,self.root)
    def tearDown(self):
        self.w.close(); self.c.close(); self.tmp.cleanup()
    def packet(self):
        events=self.w.history(); head=(len(events),digest(events[-1]) if events else ZERO)
        return canonical({'version':1,'domain':DOMAIN,'events':events}),head
    def test_valid_export_has_no_financial_authority(self):
        self.w.issue(1,'a'*64); self.w.rotate(); raw,head=self.packet()
        result=verify_export(raw,self.root,head,head)
        self.assertTrue(result['evidence_verified']);self.assertFalse(result['financial_authority'])
    def test_missing_trusted_floor_rejected(self):
        raw,head=self.packet(); self.assertFalse(verify_export(raw,self.root,None,head)['evidence_verified'])
    def test_wrong_expected_head(self):
        raw,head=self.packet(); self.assertFalse(verify_export(raw,self.root,(0,ZERO),(1,ZERO))['evidence_verified'])
    def test_duplicate_json_key_rejected(self):
        raw=b'{"version":0,"version":1,"domain":"'+DOMAIN.encode()+b'","events":[]}'
        self.assertFalse(verify_export(raw,self.root,(0,ZERO),(0,ZERO))['evidence_verified'])
    def test_strict_malformed_input_matrix(self):
        cases=[b'',b'{',b'null',b'[]',b'\xff',b'{"version":NaN}',b'{"version":true}',b'{}',b'"text"',None,'{}']
        for raw in cases:
            with self.subTest(raw=raw): self.assertFalse(verify_export(raw,self.root,(0,ZERO),(0,ZERO))['evidence_verified'])
    def test_resource_limits(self):
        raw=b' '*(MAX_BYTES+1)
        self.assertFalse(verify_export(raw,self.root,(0,ZERO),(0,ZERO))['evidence_verified'])
        raw=canonical({'version':1,'domain':DOMAIN,'events':[{}]*(MAX_EVENTS+1)})
        self.assertFalse(verify_export(raw,self.root,(0,ZERO),(0,ZERO))['evidence_verified'])
    def test_bool_and_extra_fields(self):
        for obj in [{'version':True,'domain':DOMAIN,'events':[]},{'version':1,'domain':DOMAIN,'events':[],'root':self.root}]:
            with self.subTest(obj=obj):self.assertFalse(verify_export(canonical(obj),self.root,(0,ZERO),(0,ZERO))['evidence_verified'])
    def test_deterministic_mutation_campaign(self):
        self.w.issue(1,'a'*64);self.w.rotate();self.w.issue(2,'b'*64)
        raw,head=self.packet();rng=random.Random(7401)
        # 200 fixed-seed byte flips, none may be accepted under the original exact head.
        for case in range(200):
            altered=bytearray(raw);pos=rng.randrange(len(altered));altered[pos]^=rng.randrange(1,256)
            with self.subTest(case=case):self.assertFalse(verify_export(bytes(altered),self.root,head,head)['evidence_verified'])
    def test_truncated_signed_history_rejected(self):
        self.w.issue(1,'a'*64);self.w.rotate();raw,head=self.packet()
        obj=json.loads(raw);obj['events'].pop()
        self.assertFalse(verify_export(canonical(obj),self.root,head,head)['evidence_verified'])
    def test_two_store_rollback_detected_with_surviving_floor(self):
        self.w.issue(1,'a'*64)
        for db,name in [(self.w.db,'w_old'),(self.c.db,'c_old')]:
            saved=sqlite3.connect(self.path/name);db.backup(saved);saved.close()
        self.w.rotate();self.w.issue(2,'b'*64);h=self.w.history();floor=(len(h),digest(h[-1]))
        self.w.close();self.c.close()
        for old,destination in [('w_old',self.wp),('c_old',self.cp)]:
            src=sqlite3.connect(self.path/old);dst=sqlite3.connect(destination);src.backup(dst);src.close();dst.close()
        self.c=CustodianFixture(self.cp,self.root)
        with self.assertRaises(Rejected):Witness(self.wp,self.c,self.root,floor)
        # Documented residual risk: no surviving independent floor => consistent joint rollback is undetectable.
        self.w=Witness(self.wp,self.c,self.root)
        self.assertEqual(self.w.recover()['seq'],1)
    def test_active_custody_key_substitution_rejected(self):
        self.c.db.execute('UPDATE keys SET secret=? WHERE epoch=1',(b'x'*32,))
        with self.assertRaises(Rejected):self.w.issue(1,'a'*64)
    def test_custody_truncation_rejected_against_witness(self):
        self.w.issue(1,'a'*64);self.c.db.execute('DELETE FROM events')
        with self.assertRaises(Rejected):self.w.recover()
    def test_signed_event_tamper_rejected(self):
        self.w.issue(1,'a'*64);h=self.w.history();h[0]['body']['request']['digest']='b'*64
        self.w.db.execute('UPDATE events SET receipt=?',(canonical(h[0]).decode(),))
        with self.assertRaises(InvalidSignature):self.w.recover()
    def test_same_op_different_request_rejected(self):
        receipt=self.w.issue(1,'a'*64);req=copy.deepcopy(receipt['body']['request']);req['digest']='b'*64
        with self.assertRaises(Rejected):self.c.apply(req)
    def test_custody_stale_cas_rejected(self):
        receipt=self.w.issue(1,'a'*64);req=copy.deepcopy(receipt['body']['request']);req['op']='f'*32
        with self.assertRaises(Rejected):self.c.apply(req)
    def test_deleting_root_record_rejected(self):
        self.w.db.execute('DELETE FROM identity')
        with self.assertRaises(Rejected):self.w.recover()
    def race(self, kinds, values):
        # spawn creates separate interpreters, connections and real simultaneous contenders.
        ctx=multiprocessing.get_context('spawn');barrier=ctx.Barrier(len(kinds));queue=ctx.Queue()
        jobs=[ctx.Process(target=run,args=(self.cp,self.wp,self.root,k,v,barrier,queue)) for k,v in zip(kinds,values)]
        for job in jobs:job.start()
        try:
            for job in jobs:job.join(20);self.assertEqual(job.exitcode,0)
            result=[queue.get(timeout=5) for _ in jobs]
        finally:
            for job in jobs:
                if job.is_alive():job.terminate();job.join()
            queue.close();queue.join_thread()
        self.assertNotIn('ERROR',[r[0] for r in result],result)
        return result
    def test_spawn_simultaneous_equivocation_one_wins(self):
        result=self.race(['issue','issue'],['a','b'])
        self.assertEqual(sorted(r[0] for r in result),['OK','REJECT'])
        self.assertEqual(len(self.w.history()),1)
    def test_spawn_simultaneous_duplicate_same_receipt(self):
        result=self.race(['issue','issue'],['a','a'])
        self.assertEqual(result[0],result[1]);self.assertEqual(result[0][0],'OK')
        self.assertEqual(len(self.w.history()),1)
    def test_spawn_simultaneous_rotations(self):
        result=self.race(['rotate','rotate'],['a','a'])
        self.assertEqual([r[0] for r in result],['OK','OK'])
        self.assertNotEqual(result[0][1],result[1][1])
        self.assertEqual(self.w.recover()['epoch'],3)
    def test_spawn_issue_rotation_race(self):
        result=self.race(['issue','rotate'],['a','a'])
        self.assertEqual([r[0] for r in result],['OK','OK'])
        state=self.w.recover();self.assertEqual((state['seq'],state['epoch']),(1,2))
    def test_spawn_recovery_of_committed_custody(self):
        def fail(stage):
            if stage=='custody_after_commit':raise RuntimeError('fault')
        with self.assertRaises(RuntimeError):self.w.rotate(fail)
        result=self.race(['issue','issue'],['a','a'])
        self.assertEqual(result[0],result[1]);self.assertEqual(result[0][0],'OK')
        state=self.w.recover();self.assertEqual((state['index'],state['seq'],state['epoch']),(2,1,2))

if __name__=='__main__':unittest.main(verbosity=2)
