from rotation import CustodianFixture, Witness, Rejected

def run(cp, wp, root, kind, value, barrier, queue):
    c = None; w = None
    try:
        c = CustodianFixture(cp, root); w = Witness(wp, c, root)
        barrier.wait(timeout=15)
        receipt = w.rotate() if kind == 'rotate' else w.issue(1, value * 64)
        queue.put(('OK', receipt['body']['request']['op']))
    except Rejected as exc:
        queue.put(('REJECT', str(exc)))
    except BaseException as exc:
        queue.put(('ERROR', repr(exc)))
    finally:
        if w is not None: w.close()
        if c is not None: c.close()
