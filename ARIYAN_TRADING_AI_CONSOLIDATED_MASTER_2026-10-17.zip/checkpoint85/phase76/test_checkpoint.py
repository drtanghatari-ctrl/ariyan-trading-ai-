import copy,pathlib,secrets,sqlite3,tempfile,unittest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
from cryptography.exceptions import InvalidSignature
from rotation import CustodianFixture,Witness,raw_public,ZERO,Rejected,digest,canonical
from checkpoint import Authority,make_request,verify_query,genesis,signed

class CheckpointTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.p=pathlib.Path(self.tmp.name)
        self.c,self.root=CustodianFixture.create(self.p/'c');self.w=Witness.create(self.p/'w',self.c,self.root)
        self.client=Ed25519PrivateKey.generate();self.signer=Ed25519PrivateKey.generate()
        self.config={'tenant':'ariyan_test','witness':'offline_1','custody_root':self.root,'client_public':raw_public(self.client),'authority_public':raw_public(self.signer)}
        self.a=Authority.create(self.p/'a',self.config,self.signer)
    def tearDown(self):self.a.close();self.w.close();self.c.close();self.tmp.cleanup()
    def request(self,epoch=1):
        h=self.w.history();return make_request(self.client,self.config,self.a.snapshot()['generation'],epoch,h),h
    def advance(self):
        self.w.issue(1,'a'*64);e,h=self.request();return self.a.submit(e,h)
    def test_signed_authenticated_advance(self):
        self.advance();s=self.a.snapshot();self.assertEqual((s['generation'],s['floor_index']),(1,1))
    def test_idempotent_lost_response_retry(self):
        self.w.issue(1,'a'*64);e,h=self.request()
        def fault(stage):
            if stage=='authority_after_commit':raise TimeoutError('lost response')
        with self.assertRaises(TimeoutError):self.a.submit(e,h,fault)
        first=self.a.submit(e,h);self.assertEqual(first,self.a.submit(e,h));self.assertEqual(self.a.snapshot()['generation'],1)
    def test_before_commit_failure_rolls_back(self):
        self.w.issue(1,'a'*64);e,h=self.request()
        def fault(stage):
            if stage=='authority_before_commit':raise OSError('storage failure')
        with self.assertRaises(OSError):self.a.submit(e,h,fault)
        self.assertEqual(self.a.snapshot()['generation'],0);self.a.submit(e,h)
    def test_stale_generation_rejected(self):
        self.w.issue(1,'a'*64);e,h=self.request();self.a.submit(e,h)
        self.w.rotate();new=self.w.history();stale=make_request(self.client,self.config,0,1,new)
        with self.assertRaises(Rejected):self.a.submit(stale,new)
    def test_wrong_client_rejected(self):
        self.w.issue(1,'a'*64);h=self.w.history();e=make_request(Ed25519PrivateKey.generate(),self.config,0,1,h)
        with self.assertRaises(InvalidSignature):self.a.submit(e,h)
    def test_cross_tenant_rejected(self):
        self.w.issue(1,'a'*64);e,h=self.request();e['body']['tenant']='other';e=signed(self.client,e['body'])
        with self.assertRaises(Rejected):self.a.submit(e,h)
    def test_cross_witness_rejected(self):
        self.w.issue(1,'a'*64);e,h=self.request();e['body']['witness']='other';e=signed(self.client,e['body'])
        with self.assertRaises(Rejected):self.a.submit(e,h)
    def test_history_binding_rejected(self):
        self.w.issue(1,'a'*64);e,h=self.request();self.w.rotate()
        with self.assertRaises(Rejected):self.a.submit(e,self.w.history())
    def test_history_forgery_rejected(self):
        self.w.issue(1,'a'*64);h=self.w.history();h[0]['signature']='0'*128;e=make_request(self.client,self.config,0,1,h)
        with self.assertRaises(InvalidSignature):self.a.submit(e,h)
    def test_no_checkpoint_regression(self):
        self.advance();e,h=self.request()
        with self.assertRaises(Rejected):self.a.submit(e,h)
    def test_operation_id_substitution(self):
        self.w.issue(1,'a'*64);e,h=self.request();self.a.submit(e,h);self.w.rotate();new=self.w.history()
        e2=make_request(self.client,self.config,1,1,new,op=e['body']['op'])
        with self.assertRaises(Rejected):self.a.submit(e2,new)
    def test_new_challenge_prevents_response_replay(self):
        nonce=secrets.token_hex(32);reply=self.a.query(nonce)
        self.assertEqual(verify_query(reply,self.config,nonce,genesis(self.config))['generation'],0)
        with self.assertRaises(Rejected):verify_query(reply,self.config,secrets.token_hex(32),genesis(self.config))
    def test_wrong_authority_pin(self):
        config=dict(self.config,authority_public=raw_public(Ed25519PrivateKey.generate()))
        nonce=secrets.token_hex(32)
        with self.assertRaises(InvalidSignature):verify_query(self.a.query(nonce),config,nonce,genesis(config))
    def test_restart_same_external_signer(self):
        self.advance();old=self.a.snapshot();self.a.close();self.a=Authority(self.p/'a',self.config,self.signer)
        self.assertEqual(old,self.a.snapshot())
    def test_authority_snapshot_rollback_needs_retained_minimum(self):
        saved=sqlite3.connect(self.p/'old');self.a.db.backup(saved);saved.close()
        self.advance();minimum=self.a.snapshot();self.a.close()
        saved=sqlite3.connect(self.p/'old');target=sqlite3.connect(self.p/'a');saved.backup(target);saved.close();target.close()
        self.a=Authority(self.p/'a',self.config,self.signer);nonce=secrets.token_hex(32);reply=self.a.query(nonce)
        with self.assertRaises(Rejected):verify_query(reply,self.config,nonce,minimum)
        self.assertEqual(verify_query(reply,self.config,nonce,genesis(self.config))['generation'],0)
    def test_database_receipt_mutation_detected(self):
        self.advance();row=self.a.db.execute('SELECT receipt FROM commits').fetchone()[0]
        import json
        r=json.loads(row);r['signature']='0'*128;self.a.db.execute('UPDATE commits SET receipt=?',(canonical(r).decode(),))
        with self.assertRaises(InvalidSignature):self.a.snapshot()
    def test_unprovisioned_policy_epoch(self):
        self.w.issue(1,'a'*64);e,h=self.request(2)
        with self.assertRaises(Rejected):self.a.submit(e,h)
    def test_no_secret_in_authority_schema(self):
        schema=' '.join(r[0] for r in self.a.db.execute("SELECT sql FROM sqlite_master WHERE type='table'"))
        self.assertNotIn('secret',schema);self.assertNotIn('private',schema)
    def test_boolean_generation_rejected(self):
        self.w.issue(1,'a'*64);e,h=self.request();e['body']['expected_generation']=False;e=signed(self.client,e['body'])
        with self.assertRaises(Rejected):self.a.submit(e,h)
    def test_wrong_external_signer_on_reopen(self):
        with self.assertRaises(Rejected):Authority(self.p/'a',self.config,Ed25519PrivateKey.generate())
    def test_missing_authority_not_reset(self):
        with self.assertRaises(Rejected):Authority(self.p/'absent',self.config,self.signer)

if __name__=='__main__':unittest.main(verbosity=2)
