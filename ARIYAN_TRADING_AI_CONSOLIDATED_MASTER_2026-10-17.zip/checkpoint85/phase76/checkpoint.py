"""Offline authenticated checkpoint-authority reference, not an external trust service.
Callers own pins, fresh challenges and retained checkpoints. Injected signers here
use disposable keys; deployment/independence/secret protection are not provided.
"""
import json
import pathlib
import uuid
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from rotation import canonical, digest, hexfield, integer, Rejected, ZERO, connect, transaction, verify_history, raw_public
DOMAIN='ARIYAN-CHECKPOINT-v1'
MAX_HISTORY=10000

def exact(obj, fields):
    if type(obj) is not dict or set(obj)!=set(fields):raise Rejected('schema')

def label(value):
    if type(value) is not str or not 1<=len(value)<=64 or any(c not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-' for c in value):
        raise Rejected('scope label')

def verify_signature(public, body, signature):
    hexfield(public,64);hexfield(signature,128)
    Ed25519PublicKey.from_public_bytes(bytes.fromhex(public)).verify(bytes.fromhex(signature),canonical(body))

def signed(key,body):return {'body':body,'signature':key.sign(canonical(body)).hex()}

def config_validate(config):
    exact(config,('tenant','witness','custody_root','client_public','authority_public'))
    label(config['tenant']);label(config['witness'])
    for name in ('custody_root','client_public','authority_public'):hexfield(config[name],64)

def make_request(key,config,generation,governance_epoch,history,op=None):
    body={'domain':DOMAIN,'tenant':config['tenant'],'witness':config['witness'],'op':op or uuid.uuid4().hex,
          'expected_generation':generation,'governance_epoch':governance_epoch,'history_hash':digest(history)}
    return signed(key,body)

def request_validate(envelope,config,history,client_public=None):
    exact(envelope,('body','signature'));b=envelope['body']
    exact(b,('domain','tenant','witness','op','expected_generation','governance_epoch','history_hash'))
    if (b['domain'],b['tenant'],b['witness'])!=(DOMAIN,config['tenant'],config['witness']):raise Rejected('scope/domain')
    hexfield(b['op'],32);integer(b['expected_generation']);integer(b['governance_epoch'],1);hexfield(b['history_hash'],64)
    if type(history) is not list or len(history)>MAX_HISTORY or len(canonical(history))>8*1024*1024:raise Rejected('history limit')
    if b['history_hash']!=digest(history):raise Rejected('history binding')
    verify_signature(client_public or config['client_public'],b,envelope['signature'])
    return b

def genesis(config):
    config_validate(config)
    return {'generation':0,'head':ZERO,'floor_index':0,'floor_head':ZERO,'custody_root':config['custody_root']}

def receipt_validate(receipt,config,state):
    exact(receipt,('body','signature'));b=receipt['body']
    exact(b,('domain','tenant','witness','generation','previous','request_hash','operation','governance_epoch','floor_index','floor_head','custody_root'))
    if (b['domain'],b['tenant'],b['witness'])!=(DOMAIN,config['tenant'],config['witness']):raise Rejected('receipt scope')
    integer(b['generation'],1);integer(b['governance_epoch'],1);integer(b['floor_index'],1)
    for name in ('previous','request_hash','floor_head','custody_root'):hexfield(b[name],64)
    hexfield(b['operation'],32)
    if b['generation']!=state['generation']+1 or b['previous']!=state['head'] or b['floor_index']<=state['floor_index'] or b['custody_root']!=state['custody_root']:
        raise Rejected('checkpoint continuity')
    verify_signature(config['authority_public'],b,receipt['signature'])
    return {'generation':b['generation'],'head':digest(receipt),'floor_index':b['floor_index'],'floor_head':b['floor_head'],'custody_root':b['custody_root']}

def verify_query(packet,config,challenge,minimum):
    """minimum is a trusted previously retained authority state (or explicit genesis).
    A new challenge defeats replayed responses; it cannot defeat authority rollback
    unless minimum survives independently. No trading authority is ever returned.
    """
    exact(packet,('body','signature'));b=packet['body'];hexfield(challenge,64)
    exact(b,('domain','tenant','witness','challenge','state'))
    if (b['domain'],b['tenant'],b['witness'],b['challenge'])!=(DOMAIN,config['tenant'],config['witness'],challenge):raise Rejected('query scope/challenge')
    verify_signature(config['authority_public'],b,packet['signature'])
    s=b['state'];exact(s,('generation','head','floor_index','floor_head','custody_root'))
    exact(minimum,('generation','head','floor_index','floor_head','custody_root'))
    integer(s['generation']);integer(s['floor_index'])
    for n in ('head','floor_head','custody_root'):hexfield(s[n],64)
    if s['custody_root']!=config['custody_root'] or minimum['custody_root']!=s['custody_root']:raise Rejected('query root')
    if s['generation']<minimum['generation'] or s['floor_index']<minimum['floor_index']:raise Rejected('query rollback')
    if s['generation']==minimum['generation'] and s!=minimum:raise Rejected('query fork')
    if s['floor_index']==minimum['floor_index'] and s['floor_head']!=minimum['floor_head']:raise Rejected('query floor fork')
    return dict(s)

class Authority:
    @classmethod
    def create(cls,path,config,signer):
        config_validate(config)
        if raw_public(signer)!=config['authority_public']:raise Rejected('signer pin')
        with open(path,'xb'):pass
        db=connect(path)
        try:
            db.executescript('CREATE TABLE identity(config TEXT NOT NULL);CREATE TABLE commits(n INTEGER PRIMARY KEY,op TEXT UNIQUE NOT NULL,envelope TEXT NOT NULL,history TEXT NOT NULL,receipt TEXT NOT NULL);')
            db.execute('INSERT INTO identity VALUES(?)',(canonical(config).decode(),))
        finally:db.close()
        return cls(path,config,signer)
    def __init__(self,path,config,signer,policy=None):
        config_validate(config)
        if not pathlib.Path(path).is_file():raise Rejected('authority missing; explicit provisioning required')
        if raw_public(signer)!=config['authority_public']:raise Rejected('signer pin')
        self.db=connect(path);self.config=dict(config);self.signer=signer;self.policy=policy
        try:
            with transaction(self.db):self._read()
        except BaseException:self.close();raise
    def _read(self):
        rows=self.db.execute('SELECT config FROM identity').fetchall()
        if rows!=[(canonical(self.config).decode(),)]:raise Rejected('authority identity')
        state=genesis(self.config);seen=set()
        for n,op,envelope,history,receipt in self.db.execute('SELECT n,op,envelope,history,receipt FROM commits ORDER BY n'):
            e,h,r=json.loads(envelope),json.loads(history),json.loads(receipt)
            # Historical signature verification never applies today's revocation retroactively.
            b=request_validate(e,self.config,h)
            if n!=state['generation']+1 or b['expected_generation']!=state['generation'] or op!=b['op'] or op in seen:raise Rejected('authority log continuity')
            seen.add(op)
            verified=verify_history(h,state['custody_root'],(state['floor_index'],state['floor_head']))
            if verified['index']<=state['floor_index']:raise Rejected('nonadvancing checkpoint')
            if (r['body']['floor_index'],r['body']['floor_head'],r['body']['request_hash'],r['body']['operation'],r['body']['governance_epoch'])!=(verified['index'],verified['head'],digest(e),op,b['governance_epoch']):raise Rejected('receipt binding')
            state=receipt_validate(r,self.config,state)
        return state
    def snapshot(self):
        with transaction(self.db):return self._read()
    def query(self,challenge):
        hexfield(challenge,64)
        with transaction(self.db):
            body={'domain':DOMAIN,'tenant':self.config['tenant'],'witness':self.config['witness'],'challenge':challenge,'state':self._read()}
            return signed(self.signer,body)
    def submit(self,envelope,history,hook=lambda _:None):
        b=request_validate(envelope,self.config,history)
        with transaction(self.db):
            state=self._read()
            # Retry of an identical committed operation yields the original receipt.
            prior=self.db.execute('SELECT envelope,history,receipt FROM commits WHERE op=?',(b['op'],)).fetchone()
            if prior:
                if (prior[0],prior[1])!=(canonical(envelope).decode(),canonical(history).decode()):raise Rejected('operation substitution')
                return json.loads(prior[2])
            if self.policy is not None:self.policy(b,state)
            elif b['governance_epoch']!=1:raise Rejected('unprovisioned governance epoch')
            if b['expected_generation']!=state['generation']:raise Rejected('stale authority CAS')
            verified=verify_history(history,state['custody_root'],(state['floor_index'],state['floor_head']))
            if verified['index']<=state['floor_index']:raise Rejected('nonadvancing checkpoint')
            body={'domain':DOMAIN,'tenant':self.config['tenant'],'witness':self.config['witness'],'generation':state['generation']+1,'previous':state['head'],'request_hash':digest(envelope),'operation':b['op'],'governance_epoch':b['governance_epoch'],'floor_index':verified['index'],'floor_head':verified['head'],'custody_root':state['custody_root']}
            receipt=signed(self.signer,body);receipt_validate(receipt,self.config,state)
            self.db.execute('INSERT INTO commits VALUES(?,?,?,?,?)',(body['generation'],b['op'],canonical(envelope).decode(),canonical(history).decode(),canonical(receipt).decode()))
            hook('authority_before_commit')
        hook('authority_after_commit')
        return receipt
    def close(self):self.db.close()
