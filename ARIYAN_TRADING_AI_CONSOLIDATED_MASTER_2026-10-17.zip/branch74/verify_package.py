"""Verify delivered bytes before executing any included reference code."""
import hashlib,json,pathlib,sys
root=pathlib.Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text())
errors=[]
for name,expected in manifest['files'].items():
    path=root/name
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=expected:errors.append(name)
if errors:
    print('MISMATCH: '+', '.join(errors));sys.exit(1)
print('Verified '+str(len(manifest['files']))+' packaged file hashes. Internal consistency only; no origin authentication or certification.')
