"""Reproduce local reference checks. Requires Python + cryptography; not a trading app."""
import pathlib,subprocess,sys,tempfile
root=pathlib.Path(__file__).resolve().parent
subprocess.run([sys.executable,str(root/'verify_package.py')],check=True)
with tempfile.TemporaryDirectory(prefix='ariyan_audit_') as temp:
    subprocess.run([sys.executable,str(root/'evidence/audit_inherited.py'),str(root/'prior/phase72.zip'),temp],check=True)
    import json
    audit=json.loads((pathlib.Path(temp)/'inherited_audit.json').read_text())
    if len(audit['source_blocks'])!=27 or not all(x['matched'] for x in audit['source_blocks']):raise RuntimeError('historical source mismatch')
    if any(s['returncode'] for s in audit['suites']):raise RuntimeError('inherited test failure')
    if sum(s['tests'] for s in audit['suites'])!=82:raise RuntimeError('unexpected inherited test count')
    direct=sum(x['matched'] for x in audit['manifest_checks'])
    relocated=sum(bool(x.get('relocated_matches')) for x in audit['manifest_checks'] if not x['matched'])
    unavailable=sum(not x['matched'] and not x.get('relocated_matches') for x in audit['manifest_checks'])
    if (direct,relocated,unavailable)!=(46,5,1):raise RuntimeError('inherited manifest findings changed; review required')
for test in ['phase73/test_rotation.py','phase74/test_acceptance.py']:
    subprocess.run([sys.executable,str(root/test)],check=True)
print('121 reference tests passed; eight crash boundaries exercised inside Phase73 tests.')
print('Known inherited manifest findings remain: 5 relocated references, 1 unavailable historical ZIP. PROVISIONAL / NOT CERTIFIED.')
