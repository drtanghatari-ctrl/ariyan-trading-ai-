import json,pathlib,subprocess,sys,tempfile,unittest
from checkpoint import capture,require_checkpoint
from rotation import SQLiteCustodian,Witness

class AcceptanceTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.path=pathlib.Path(self.tmp.name)
        self.c=SQLiteCustodian(self.path/'c.db');self.root=self.c.status()[1]
        self.w=Witness(self.path/'w.db',self.c,'reference-lab',self.root)
    def tearDown(self):self.w.close();self.c.close();self.tmp.cleanup()
    def processes(self,actions):
        worker=str(pathlib.Path(__file__).with_name('coordinator_worker.py'))
        ps=[subprocess.Popen([sys.executable,worker,str(self.path/'c.db'),str(self.path/'w.db'),self.root,*a],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True) for a in actions]
        return [(p.communicate(timeout=20),p.returncode) for p in ps]
    def test_exact_checkpoint(self):
        self.w.issue(1,'a'*64);cp=capture(self.w);self.assertEqual(cp,require_checkpoint(self.w,cp))
    def test_newer_state_accepted(self):
        self.w.issue(1,'a'*64);cp=capture(self.w);self.w.begin_rotation();self.w.issue(2,'b'*64)
        self.assertEqual(require_checkpoint(self.w,cp)['epoch'],2)
    def test_wrong_checkpoint_digest(self):
        self.w.issue(1,'a'*64);cp=capture(self.w);cp['digest']='b'*64
        with self.assertRaises(ValueError):require_checkpoint(self.w,cp)
    def test_future_sequence(self):
        cp=capture(self.w);cp['seq']=1
        with self.assertRaises(ValueError):require_checkpoint(self.w,cp)
    def test_future_epoch(self):
        cp=capture(self.w);cp['epoch']=2
        with self.assertRaises(ValueError):require_checkpoint(self.w,cp)
    def test_cross_scope(self):
        cp=capture(self.w);cp['scope']='other'
        with self.assertRaises(ValueError):require_checkpoint(self.w,cp)
    def test_cross_root(self):
        cp=capture(self.w);cp['root']='f'*64
        with self.assertRaises(ValueError):require_checkpoint(self.w,cp)
    def test_invalid_checkpoint(self):
        for field,value in [('seq',True),('epoch',0),('digest','A'*64)]:
            cp=capture(self.w);cp[field]=value
            with self.subTest(field=field),self.assertRaises(ValueError):require_checkpoint(self.w,cp)
    def test_pending_checkpoint_rejected(self):
        cp=capture(self.w)
        def fail(point):
            if point=='after_intent_commit':raise RuntimeError('injected')
        with self.assertRaises(RuntimeError):self.w.begin_rotation(fail)
        with self.assertRaises(ValueError):require_checkpoint(self.w,cp)
        with self.assertRaises(ValueError):capture(self.w)
    def test_joint_snapshot_rollback_detected_only_with_retained_checkpoint(self):
        # SQLite backup produces consistent snapshots, including WAL contents.
        import sqlite3
        for db,name in [(self.c.db,'old_c.db'),(self.w.db,'old_w.db')]:
            target=sqlite3.connect(self.path/name);db.backup(target);target.close()
        self.w.issue(1,'a'*64);self.w.begin_rotation();cp=capture(self.w)
        oldc=SQLiteCustodian(self.path/'old_c.db');oldw=Witness(self.path/'old_w.db',oldc,'reference-lab',self.root)
        try:
            oldw.recover()  # A valid joint rollback is invisible without an external checkpoint.
            self.assertEqual(oldw.state()[2],1)
            with self.assertRaises(ValueError):require_checkpoint(oldw,cp)
        finally:oldw.close();oldc.close()
    def test_concurrent_duplicate_issue(self):
        for output,code in self.processes([['issue','a'*64]]*4):self.assertEqual(code,0,output)
        self.assertEqual(self.w.db.execute('SELECT count(*) FROM attest').fetchone()[0],1)
    def test_concurrent_conflicting_issue(self):
        results=self.processes([['issue','a'*64],['issue','b'*64]])
        self.assertEqual(sorted(code for _,code in results),[0,2]);self.assertEqual(self.w.state()[0],1)
    def test_concurrent_recoverers(self):
        def fail(point):
            if point=='after_custodian_activate':raise RuntimeError('injected')
        with self.assertRaises(RuntimeError):self.w.begin_rotation(fail)
        for output,code in self.processes([['recover']]*4):self.assertEqual(code,0,output)
        self.assertEqual(self.w.state()[2],2);self.assertIsNone(self.w._pending())
    def test_concurrent_rotations_serialized(self):
        results=self.processes([['rotate']]*4)
        self.assertTrue(all(code in [0,2] for _,code in results),results)
        successes=sum(code==0 for _,code in results)
        self.w.recover();self.assertEqual(self.w.state()[2],1+successes)
        self.assertEqual(self.w.db.execute("SELECT count(*) FROM journal WHERE stage='COMMITTED'").fetchone()[0],successes)

if __name__=='__main__':unittest.main(verbosity=2)
