import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'phase73'))
from rotation import SQLiteCustodian,Witness
c=SQLiteCustodian(sys.argv[1]);w=Witness(sys.argv[2],c,'reference-lab',sys.argv[3])
try:
    if sys.argv[4]=='recover':w.recover()
    elif sys.argv[4]=='issue':w.issue(1,sys.argv[5])
    elif sys.argv[4]=='rotate':w.begin_rotation()
except ValueError as exc:
    print(type(exc).__name__+': '+str(exc));sys.exit(2)
finally:w.close();c.close()
