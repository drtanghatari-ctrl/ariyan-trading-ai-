"""Reference acceptance gate against a caller-supplied TRUSTED external checkpoint.
Checkpoint authenticity, freshness, storage and transport are deployment obligations.
This module does not create a secure external anchor and grants no trading authority.
"""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'phase73'))
from rotation import ZERO

FIELDS={'scope','root','epoch','seq','digest'}

def _capture(witness):
    witness._validate()
    if witness._pending() or witness.custodian.status()!=witness.state()[2:]:
        raise ValueError('unsettled identity')
    seq,digest,epoch,_=witness.state()
    return {'scope':witness.scope,'root':witness.root,'epoch':epoch,'seq':seq,'digest':digest}

def capture(witness):
    """Only a candidate checkpoint; caller must independently retain and authenticate it."""
    witness.db.execute('BEGIN IMMEDIATE')
    try:
        result=_capture(witness);witness.db.execute('COMMIT');return result
    except BaseException:
        witness.db.execute('ROLLBACK');raise

def require_checkpoint(witness, checkpoint):
    if not isinstance(checkpoint,dict) or set(checkpoint)!=FIELDS:raise ValueError('checkpoint shape')
    if type(checkpoint['epoch']) is not int or checkpoint['epoch']<1 or type(checkpoint['seq']) is not int or checkpoint['seq']<0:
        raise ValueError('checkpoint counters')
    digest=checkpoint['digest']
    if not isinstance(digest,str) or len(digest)!=64 or any(c not in '0123456789abcdef' for c in digest):raise ValueError('checkpoint digest')
    witness.db.execute('BEGIN IMMEDIATE')
    try:
        current=_capture(witness)
        if (checkpoint['scope'],checkpoint['root'])!=(current['scope'],current['root']):raise ValueError('checkpoint identity')
        if checkpoint['epoch']>current['epoch'] or checkpoint['seq']>current['seq']:raise ValueError('state rollback')
        row=witness.db.execute('SELECT digest FROM attest WHERE seq=?',(checkpoint['seq'],)).fetchone()
        actual=ZERO if checkpoint['seq']==0 else row[0] if row else None
        if actual!=digest:raise ValueError('checkpoint history mismatch')
        witness.db.execute('COMMIT');return current
    except BaseException:
        witness.db.execute('ROLLBACK');raise
