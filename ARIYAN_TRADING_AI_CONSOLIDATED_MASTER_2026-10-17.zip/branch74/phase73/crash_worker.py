import os, sys
from rotation import SQLiteCustodian, Witness
custodian=SQLiteCustodian(sys.argv[1])
w=Witness(sys.argv[2],custodian,'reference-lab',sys.argv[3])
def hook(point):
    if point==sys.argv[4]:os._exit(73)
w.begin_rotation(hook)
os._exit(74)
