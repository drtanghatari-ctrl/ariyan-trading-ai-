import json, pathlib, sqlite3, subprocess, sys, tempfile, unittest
from cryptography.exceptions import InvalidSignature
from rotation import SQLiteCustodian, Witness, verify

POINTS=['before_intent_commit','after_intent_commit','after_custodian_prepare','before_prepared_commit','after_prepared_commit','after_custodian_activate','before_finalize_commit','after_finalize_commit']

class RotationTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.path=pathlib.Path(self.tmp.name)
        self.c=SQLiteCustodian(self.path/'custody.db');self.root=self.c.status()[1]
        self.w=Witness(self.path/'witness.db',self.c,'reference-lab',self.root)
    def tearDown(self):
        self.w.close();self.c.close();self.tmp.cleanup()
    def reopen(self):
        self.w.close();self.c.close();self.c=SQLiteCustodian(self.path/'custody.db')
        self.w=Witness(self.path/'witness.db',self.c,'reference-lab',self.root)
    def test_signature(self):
        a=self.w.issue(1,'a'*64);verify(self.root,a['signature'],a['statement'])
    def test_idempotent_attestation(self):
        a=self.w.issue(1,'a'*64);self.assertEqual(a,self.w.issue(1,'a'*64))
    def test_reject_equivocation(self):
        self.w.issue(1,'a'*64)
        with self.assertRaises(ValueError):self.w.issue(1,'b'*64)
    def test_reject_rollback(self):
        self.w.issue(2,'a'*64)
        with self.assertRaises(ValueError):self.w.issue(1,'a'*64)
    def test_invalid_input(self):
        for seq,digest in [(True,'a'*64),(0,'a'*64),(1,'G'*64),(1,'a'*63)]:
            with self.subTest(seq=seq,digest=digest),self.assertRaises(ValueError):self.w.issue(seq,digest)
    def test_two_rotations_persist_old_proof(self):
        old=self.w.issue(1,'a'*64)
        self.w.begin_rotation();self.w.begin_rotation();self.reopen();self.w.recover()
        self.assertEqual(self.w.state()[2],3);self.assertEqual(self.w.issue(1,'a'*64),old)
        a=self.w.issue(2,'b'*64);verify(self.c.status()[1],a['signature'],a['statement'])
    def test_wrong_root_same_epoch(self):
        other=SQLiteCustodian(self.path/'other.db')
        try:
            with self.assertRaises(ValueError):Witness(self.path/'witness.db',other,'reference-lab',other.status()[1])
        finally:other.close()
    def test_same_pin_wrong_custodian(self):
        other=SQLiteCustodian(self.path/'other.db')
        try:
            w=Witness(self.path/'witness.db',other,'reference-lab',self.root)
            try:
                with self.assertRaises(ValueError):w.issue(1,'a'*64)
                with self.assertRaises(ValueError):w.recover()
            finally:w.close()
        finally:other.close()
    def test_wrong_scope(self):
        with self.assertRaises(ValueError):Witness(self.path/'witness.db',self.c,'another-scope',self.root)
    def test_bad_bootstrap_pin(self):
        with self.assertRaises(ValueError):Witness(self.path/'new.db',self.c,'reference-lab','0'*64)
    def test_prepare_idempotent(self):
        a=self.c.prepare('id',1,self.root);self.assertEqual(a,self.c.prepare('id',1,self.root))
        with self.assertRaises(ValueError):self.c.prepare('id',2,self.root)
    def test_competing_preparation_rejected(self):
        self.c.prepare('one',1,self.root)
        with self.assertRaises(sqlite3.IntegrityError):self.c.prepare('two',1,self.root)
    def test_pending_blocks_issue_and_second_rotation(self):
        def fail(point):
            if point=='after_intent_commit':raise RuntimeError('injected')
        with self.assertRaises(RuntimeError):self.w.begin_rotation(fail)
        with self.assertRaises(ValueError):self.w.issue(1,'a'*64)
        with self.assertRaises(ValueError):self.w.begin_rotation()
        self.w.recover();self.w.issue(1,'a'*64)
    def test_custody_outage_retains_intent(self):
        original=self.c.prepare
        def unavailable(*args):raise ConnectionError('injected outage')
        self.c.prepare=unavailable
        with self.assertRaises(ConnectionError):self.w.begin_rotation()
        self.assertEqual(self.w._pending()[-1],'INTENT');self.c.prepare=original
        self.w.recover();self.assertEqual(self.w.state()[2],2)
    def test_corrupt_rotation_signature(self):
        self.w.begin_rotation();cert=json.loads(self.w.db.execute('SELECT certificate FROM journal').fetchone()[0])
        cert['old_signature']='0'*128
        self.w.db.execute('UPDATE journal SET certificate=?',(json.dumps(cert),))
        with self.assertRaises(InvalidSignature):self.w.issue(1,'a'*64)
    def test_new_public_substitution(self):
        self.w.begin_rotation();cert=json.loads(self.w.db.execute('SELECT certificate FROM journal').fetchone()[0])
        cert['statement']['new_public']=self.root
        self.w.db.execute('UPDATE journal SET certificate=?',(json.dumps(cert),))
        with self.assertRaises(ValueError):self.w.recover()
    def test_scope_substitution(self):
        self.w.begin_rotation();cert=json.loads(self.w.db.execute('SELECT certificate FROM journal').fetchone()[0])
        cert['statement']['scope']='forged'
        self.w.db.execute('UPDATE journal SET certificate=?',(json.dumps(cert),))
        with self.assertRaises(ValueError):self.w.recover()
    def test_deleted_certificate(self):
        self.w.begin_rotation();self.w.db.execute('UPDATE journal SET certificate=NULL')
        with self.assertRaises(ValueError):self.w.recover()
    def test_altered_head(self):
        self.w.issue(1,'a'*64);self.w.db.execute('UPDATE state SET seq=2')
        with self.assertRaises(ValueError):self.w.issue(3,'b'*64)
    def test_altered_attestation(self):
        self.w.issue(1,'a'*64);self.w.db.execute("UPDATE attest SET digest=?",('b'*64,))
        with self.assertRaises(InvalidSignature):self.w.recover()
    def test_unproven_epoch(self):
        self.w.db.execute('UPDATE state SET epoch=2')
        with self.assertRaises(ValueError):self.w.recover()
    def test_no_secret_in_witness_schema(self):
        fields=[r[1] for table in ['identity','state','journal','attest'] for r in self.w.db.execute('PRAGMA table_info('+table+')')]
        self.assertNotIn('private',fields)
    def test_custodian_reused_key_rejected(self):
        self.c.prepare=lambda *args:self.root
        with self.assertRaises(ValueError):self.w.begin_rotation()
        self.assertEqual(self.w.state()[2],1);self.assertEqual(self.w._pending()[-1],'INTENT')
    def test_recovery_repeat_noop(self):
        self.w.begin_rotation();self.w.recover();self.w.recover();self.assertEqual(self.w.state()[2],2)
    def test_crash_boundaries(self):
        # Every subcase uses separately persisted custody and witness databases.
        for index,point in enumerate(POINTS):
            with self.subTest(point=point):
                folder=self.path/str(index);folder.mkdir()
                c=SQLiteCustodian(folder/'c.db');root=c.status()[1]
                w=Witness(folder/'w.db',c,'reference-lab',root);old=w.issue(1,'a'*64);w.close();c.close()
                r=subprocess.run([sys.executable,str(pathlib.Path(__file__).with_name('crash_worker.py')),str(folder/'c.db'),str(folder/'w.db'),root,point],capture_output=True,text=True)
                self.assertEqual(r.returncode,73,r.stderr)
                c=SQLiteCustodian(folder/'c.db');w=Witness(folder/'w.db',c,'reference-lab',root)
                try:
                    if point not in ['before_intent_commit','after_finalize_commit']:
                        with self.assertRaises(ValueError):w.issue(2,'b'*64)
                    w.recover();w.recover()
                    self.assertEqual(w.state()[2],1 if point=='before_intent_commit' else 2)
                    self.assertEqual(w.issue(1,'a'*64),old)
                    result=w.issue(2,'b'*64);verify(c.status()[1],result['signature'],result['statement'])
                finally:w.close();c.close()

if __name__=='__main__':unittest.main(verbosity=2)
