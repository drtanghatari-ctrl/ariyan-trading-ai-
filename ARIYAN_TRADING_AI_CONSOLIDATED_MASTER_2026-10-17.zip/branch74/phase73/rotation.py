"""Recoverable rotation reference; no application/trading authorization.
SQLiteCustodian is an UNPROTECTED local test fixture, never production custody.
"""
import hashlib
import json
import sqlite3
import uuid
from typing import Protocol
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey, Ed25519PublicKey

ZERO = '0' * 64

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode()

def public_hex(key):
    return key.public_key().public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw).hex()

def verify(public, signature, statement):
    Ed25519PublicKey.from_public_bytes(bytes.fromhex(public)).verify(bytes.fromhex(signature), canonical(statement))

def connect(path):
    db = sqlite3.connect(str(path), isolation_level=None, timeout=10)
    db.execute('PRAGMA journal_mode=WAL')
    db.execute('PRAGMA synchronous=FULL')
    return db

class Custodian(Protocol):
    """Trusted service contract. prepare/activate must be durable and idempotent.
    Production implementation must authenticate callers, enforce policy and isolate keys.
    """
    def status(self): ...
    def prepare(self, rotation_id, old_epoch, old_public): ...
    def sign(self, epoch, statement): ...
    def activate(self, certificate): ...

class SQLiteCustodian:
    """TEST ONLY: plaintext private keys on disk, no secure boundary or policy authority."""
    def __init__(self, path):
        self.db = connect(path)
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS keys(epoch INTEGER PRIMARY KEY, private TEXT NOT NULL, public TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS active(id INTEGER PRIMARY KEY CHECK(id=1), epoch INTEGER NOT NULL);
        CREATE TABLE IF NOT EXISTS preparations(rid TEXT PRIMARY KEY, old_epoch INTEGER NOT NULL UNIQUE, old_public TEXT NOT NULL, new_public TEXT NOT NULL);
        ''')
        self.db.execute('BEGIN IMMEDIATE')
        try:
            if not self.db.execute('SELECT 1 FROM active').fetchone():
                key = Ed25519PrivateKey.generate()
                secret = key.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw, serialization.NoEncryption()).hex()
                self.db.execute('INSERT INTO keys VALUES(1,?,?)', (secret, public_hex(key)))
                self.db.execute('INSERT INTO active VALUES(1,1)')
            self.db.execute('COMMIT')
        except BaseException:
            self.db.execute('ROLLBACK'); raise

    def status(self):
        return self.db.execute('SELECT epoch,public FROM keys WHERE epoch=(SELECT epoch FROM active WHERE id=1)').fetchone()

    def prepare(self, rotation_id, old_epoch, old_public):
        self.db.execute('BEGIN IMMEDIATE')
        try:
            existing = self.db.execute('SELECT old_epoch,old_public,new_public FROM preparations WHERE rid=?', (rotation_id,)).fetchone()
            if existing:
                if existing[:2] != (old_epoch, old_public):
                    raise ValueError('rotation identifier reused with different input')
                result = existing[2]
            else:
                if self.status() != (old_epoch, old_public):
                    raise ValueError('custodian state mismatch')
                key = Ed25519PrivateKey.generate()
                secret = key.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw, serialization.NoEncryption()).hex()
                result = public_hex(key)
                self.db.execute('INSERT INTO keys VALUES(?,?,?)', (old_epoch + 1, secret, result))
                self.db.execute('INSERT INTO preparations VALUES(?,?,?,?)', (rotation_id, old_epoch, old_public, result))
            self.db.execute('COMMIT'); return result
        except BaseException:
            self.db.execute('ROLLBACK'); raise

    def sign(self, epoch, statement):
        # Old and prepared keys retained solely to support this reference recovery model.
        row = self.db.execute('SELECT private FROM keys WHERE epoch=?', (epoch,)).fetchone()
        if not row: raise ValueError('missing key')
        return Ed25519PrivateKey.from_private_bytes(bytes.fromhex(row[0])).sign(canonical(statement)).hex()

    def activate(self, certificate):
        s = certificate['statement']
        verify(s['old_public'], certificate['old_signature'], s)
        verify(s['new_public'], certificate['new_signature'], s)
        self.db.execute('BEGIN IMMEDIATE')
        try:
            row = self.db.execute('SELECT old_epoch,old_public,new_public FROM preparations WHERE rid=?', (s['rid'],)).fetchone()
            if row != (s['from'], s['old_public'], s['new_public']) or s['to'] != s['from'] + 1:
                raise ValueError('unprepared activation')
            if self.status() not in [(s['from'], s['old_public']), (s['to'], s['new_public'])]:
                raise ValueError('unexpected active identity')
            self.db.execute('UPDATE active SET epoch=? WHERE id=1', (s['to'],))
            self.db.execute('COMMIT')
        except BaseException:
            self.db.execute('ROLLBACK'); raise

    def close(self): self.db.close()

class Witness:
    def __init__(self, path, custodian: Custodian, scope, pinned_root):
        if not isinstance(scope, str) or not scope or not isinstance(pinned_root, str) or len(pinned_root) != 64:
            raise ValueError('explicit scope and independently supplied root required')
        Ed25519PublicKey.from_public_bytes(bytes.fromhex(pinned_root))
        self.custodian, self.scope, self.root = custodian, scope, pinned_root
        self.db = connect(path)
        try:
            self.db.executescript('''
            CREATE TABLE IF NOT EXISTS identity(id INTEGER PRIMARY KEY CHECK(id=1), scope TEXT NOT NULL, root TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS state(id INTEGER PRIMARY KEY CHECK(id=1), seq INTEGER NOT NULL, digest TEXT NOT NULL, epoch INTEGER NOT NULL, public TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS journal(rid TEXT PRIMARY KEY, old_epoch INTEGER NOT NULL UNIQUE, seq INTEGER NOT NULL, digest TEXT NOT NULL, old_public TEXT NOT NULL, certificate TEXT, stage TEXT NOT NULL CHECK(stage IN ('INTENT','PREPARED','COMMITTED')));
            CREATE TABLE IF NOT EXISTS attest(seq INTEGER PRIMARY KEY, digest TEXT NOT NULL, epoch INTEGER NOT NULL, signature TEXT NOT NULL);
            ''')
            self.db.execute('BEGIN IMMEDIATE')
            if not self.db.execute('SELECT 1 FROM identity').fetchone():
                if self.custodian.status() != (1, self.root): raise ValueError('bootstrap identity mismatch')
                self.db.execute('INSERT INTO identity VALUES(1,?,?)', (scope, self.root))
                self.db.execute('INSERT INTO state VALUES(1,0,?,1,?)', (ZERO, self.root))
            self._validate()
            self.db.execute('COMMIT')
        except BaseException:
            if self.db.in_transaction: self.db.execute('ROLLBACK')
            self.db.close(); raise

    def state(self): return self.db.execute('SELECT seq,digest,epoch,public FROM state WHERE id=1').fetchone()

    def _pending(self):
        rows = self.db.execute("SELECT rid,old_epoch,seq,digest,old_public,certificate,stage FROM journal WHERE stage!='COMMITTED'").fetchall()
        if len(rows) > 1: raise ValueError('multiple unfinished rotations')
        return rows[0] if rows else None

    def _validate(self):
        if self.db.execute('SELECT scope,root FROM identity WHERE id=1').fetchone() != (self.scope, self.root):
            raise ValueError('pinned identity mismatch')
        epoch, public = 1, self.root
        keys = {1: public}
        for rid, old, seq, digest, old_public, certificate, stage in self.db.execute('SELECT * FROM journal ORDER BY old_epoch'):
            if (old, old_public) != (epoch, public): raise ValueError('broken rotation chain')
            if certificate:
                cert = json.loads(certificate); s = cert['statement']
                expected = {'type':'ariyan.rotation.v73', 'scope':self.scope, 'rid':rid, 'from':old, 'to':old+1, 'seq':seq, 'digest':digest, 'old_public':old_public, 'new_public':s['new_public']}
                if s != expected: raise ValueError('rotation binding mismatch')
                if s['new_public'] in keys.values(): raise ValueError('reused rotation key')
                verify(public, cert['old_signature'], s); verify(s['new_public'], cert['new_signature'], s)
            if stage == 'COMMITTED':
                if not certificate: raise ValueError('missing certificate')
                epoch, public = old+1, s['new_public']; keys[epoch] = public
            elif stage == 'PREPARED' and not certificate:
                raise ValueError('missing prepared certificate')
            elif stage == 'INTENT' and certificate:
                raise ValueError('unexpected intent certificate')
        seq, digest, current_epoch, current_public = self.state()
        if (current_epoch,current_public) != (epoch,public): raise ValueError('unproven state identity')
        high, last_digest = 0, ZERO
        for number, value, key_epoch, signature in self.db.execute('SELECT * FROM attest ORDER BY seq'):
            if key_epoch not in keys: raise ValueError('unproven attestation key')
            verify(keys[key_epoch], signature, self._statement(number, value, key_epoch))
            high, last_digest = number, value
        if (seq, digest) != (high,last_digest): raise ValueError('attestation head mismatch')
        pending = self._pending()
        if pending and pending[1:5] != (epoch,seq,digest,public): raise ValueError('pending snapshot mismatch')
        return keys

    def _statement(self, seq, digest, epoch):
        return {'type':'ariyan.attest.v73','scope':self.scope,'seq':seq,'digest':digest,'epoch':epoch}

    def issue(self, seq, digest):
        if type(seq) is not int or seq < 1 or not isinstance(digest,str) or len(digest)!=64 or any(c not in '0123456789abcdef' for c in digest):
            raise ValueError('invalid sequence or digest')
        self.db.execute('BEGIN IMMEDIATE')
        try:
            self._validate()
            high, old, epoch, public = self.state()
            if self._pending() or self.custodian.status() != (epoch,public): raise ValueError('recovery required')
            if seq < high or (seq==high and digest!=old): raise ValueError('rollback or equivocation')
            row = self.db.execute('SELECT epoch,signature FROM attest WHERE seq=?',(seq,)).fetchone()
            if row:
                result={'statement':self._statement(seq,digest,row[0]),'signature':row[1]}
            else:
                statement=self._statement(seq,digest,epoch); sig=self.custodian.sign(epoch,statement)
                verify(public,sig,statement)
                self.db.execute('INSERT INTO attest VALUES(?,?,?,?)',(seq,digest,epoch,sig))
                self.db.execute('UPDATE state SET seq=?,digest=? WHERE id=1',(seq,digest))
                result={'statement':statement,'signature':sig}
            self.db.execute('COMMIT');return result
        except BaseException:
            self.db.execute('ROLLBACK');raise

    def begin_rotation(self, hook=lambda _:None):
        self.db.execute('BEGIN IMMEDIATE')
        try:
            self._validate()
            if self._pending(): raise ValueError('rotation already pending; recover first')
            seq,digest,epoch,public=self.state()
            if self.custodian.status()!=(epoch,public): raise ValueError('custodian identity mismatch')
            rid=uuid.uuid4().hex
            self.db.execute("INSERT INTO journal VALUES(?,?,?,?,?,NULL,'INTENT')",(rid,epoch,seq,digest,public))
            hook('before_intent_commit')
            self.db.execute('COMMIT')
        except BaseException:
            self.db.execute('ROLLBACK');raise
        hook('after_intent_commit')
        self.recover(hook)
        return rid

    def recover(self, hook=lambda _:None):
        # Serialize coordinators using the witness DB lock, including external calls.
        # Two durable resources remain independent; recovery always rolls forward.
        while True:
            self.db.execute('BEGIN IMMEDIATE')
            try:
                keys=self._validate(); pending=self._pending()
                if not pending:
                    if self.custodian.status()!=self.state()[2:]: raise ValueError('custodian identity mismatch')
                    self.db.execute('COMMIT');return
                rid,epoch,seq,digest,public,certificate,stage=pending
                if stage=='INTENT':
                    if self.custodian.status()!=(epoch,public): raise ValueError('activation without prepared proof')
                    new_public=self.custodian.prepare(rid,epoch,public);hook('after_custodian_prepare')
                    if new_public in keys.values(): raise ValueError('reused rotation key')
                    s={'type':'ariyan.rotation.v73','scope':self.scope,'rid':rid,'from':epoch,'to':epoch+1,'seq':seq,'digest':digest,'old_public':public,'new_public':new_public}
                    cert={'statement':s,'old_signature':self.custodian.sign(epoch,s),'new_signature':self.custodian.sign(epoch+1,s)}
                    verify(public,cert['old_signature'],s);verify(new_public,cert['new_signature'],s)
                    self.db.execute("UPDATE journal SET certificate=?,stage='PREPARED' WHERE rid=?",(canonical(cert).decode(),rid))
                    hook('before_prepared_commit');self.db.execute('COMMIT');hook('after_prepared_commit')
                else:
                    cert=json.loads(certificate);s=cert['statement']
                    if self.custodian.status() not in [(epoch,public),(epoch+1,s['new_public'])]: raise ValueError('unexpected custody identity')
                    self.custodian.activate(cert);hook('after_custodian_activate')
                    if self.custodian.status()!=(epoch+1,s['new_public']): raise ValueError('activation not confirmed')
                    self.db.execute("UPDATE journal SET stage='COMMITTED' WHERE rid=?",(rid,))
                    self.db.execute('UPDATE state SET epoch=?,public=? WHERE id=1',(epoch+1,s['new_public']))
                    hook('before_finalize_commit');self.db.execute('COMMIT');hook('after_finalize_commit')
            except BaseException:
                if self.db.in_transaction:self.db.execute('ROLLBACK')
                raise

    def close(self): self.db.close()
