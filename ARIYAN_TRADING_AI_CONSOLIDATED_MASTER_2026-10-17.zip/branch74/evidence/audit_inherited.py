"""Read-only nested archive, manifest, source-block and inherited-test audit."""
import hashlib, io, json, os, pathlib, re, subprocess, sys, zipfile

def sha(b):return hashlib.sha256(b).hexdigest()

def audit(source, destination):
    destination=pathlib.Path(destination);destination.mkdir(parents=True,exist_ok=True)
    files=[]; manifests=[]; suites=[]
    def visit(raw,label,directory):
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            entries={n:z.read(n) for n in z.namelist() if not n.endswith('/')}
        for n,b in entries.items():
            relative=pathlib.PurePosixPath(n)
            if relative.is_absolute() or '..' in relative.parts:raise ValueError('unsafe archive member')
            p=directory/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
            files.append({'archive':label,'name':n,'sha256':sha(b),'bytes':len(b)})
            if n.endswith('.zip'):visit(b,label+'!'+n,p.with_suffix(''))
        for n,b in entries.items():
            if 'manifest' in n.lower() and n.endswith('.json'):
                m=json.loads(b)
                for field in ['files','phase69_files','files_sha256','artifacts']:
                    if isinstance(m.get(field),dict):
                        for name,expected in m[field].items():
                            candidate=entries.get(name)
                            if candidate is None:
                                candidate=entries.get(str(pathlib.PurePosixPath(n).parent/name))
                            relocated=[key for key,value in entries.items() if pathlib.PurePosixPath(key).name==pathlib.PurePosixPath(name).name and sha(value)==expected] if candidate is None else []
                            manifests.append({'archive':label,'manifest':n,'file':name,'matched':candidate is not None and sha(candidate)==expected,'relocated_matches':relocated})
                if 'inherited_archive_sha256' in m:
                    inherited=entries.get(m['inherited_archive'])
                    manifests.append({'archive':label,'manifest':n,'file':m['inherited_archive'],'matched':inherited is not None and sha(inherited)==m['inherited_archive_sha256']})
                if 'master_sha256' in m:
                    masters=[f for f in files if f['name'].endswith('ARIYAN_TRADING_AI_COMPLETE_MASTER_ARCHIVE_THROUGH_15200.txt')]
                    manifests.append({'archive':label,'manifest':n,'file':'master digest','matched':bool(masters) and all(f['sha256']==m['master_sha256'] for f in masters)})
        for n in entries:
            if pathlib.PurePosixPath(n).name.startswith('test') and n.endswith('.py'):
                p=directory/n
                r=subprocess.run([sys.executable,p.name],cwd=p.parent,capture_output=True,text=True)
                output=r.stdout+r.stderr
                name='suite_'+str(len(suites)+1)+'.txt';(destination/name).write_text(output)
                initial_returncode=r.returncode
                if r.returncode and p.parent.name=='phase70':
                    env=os.environ.copy();env['PYTHONPATH']=str((directory/'REFERENCE_TESTS/ariyan_phase69').resolve())
                    r=subprocess.run([sys.executable,p.name],cwd=p.parent,capture_output=True,text=True,env=env)
                    (destination/('initial_'+name)).write_text(output)
                    output=r.stdout+r.stderr;(destination/name).write_text(output)
                count=re.search(r'Ran (\d+) tests?',output)
                suites.append({'archive':label,'test':n,'returncode':r.returncode,'initial_returncode':initial_returncode,'tests':int(count[1]) if count else None,'log':name})
    raw=pathlib.Path(source).read_bytes();visit(raw,'phase72',destination/'tree')
    master=next((destination/'tree').rglob('ARIYAN_TRADING_AI_COMPLETE_MASTER_ARCHIVE_THROUGH_15200.txt')).read_bytes()
    manifest=re.findall(rb'(?m)^(\d{2})\. (.*?) \| bytes=(\d+) \| sha256=([a-f0-9]{64})$',master)
    blocks=[]
    for number,name,size,digest in manifest:
        header=b'SOURCE DOCUMENT '+number+b': '+name+b'\n'+b'='*85+b'\n\n'
        start=master.index(header)+len(header);body=master[start:start+int(size)]
        blocks.append({'number':number.decode(),'name':name.decode(),'bytes':len(body),'matched':sha(body)==digest.decode()})
    result={'input_sha256':sha(raw),'archive_entries':len(files),'files':files,'manifest_checks':manifests,'master_sha256':sha(master),'source_blocks':blocks,'suites':suites,
            'limitations':['Source blocks verified against embedded manifest; separately supplied originals are not in this package.','Historical semantic and provenance exceptions remain open.','Hashes establish internal consistency, not independently authenticated origin.']}
    (destination/'inherited_audit.json').write_text(json.dumps(result,indent=2))
    print(json.dumps({'entries':len(files),'manifest_checks':len(manifests),'manifest_failures':[v for v in manifests if not v['matched']],'source_matches':sum(v['matched'] for v in blocks),'source_total':len(blocks),'suites':suites},indent=2))
    return result
if __name__=='__main__':audit(sys.argv[1],sys.argv[2])
